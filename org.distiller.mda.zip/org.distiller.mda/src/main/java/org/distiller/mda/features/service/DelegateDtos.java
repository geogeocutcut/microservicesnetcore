package org.distiller.mda.features.service;

import org.distiller.mda.features.javamodel.JavaModelObjFinder;
import org.distiller.mda.impl.DistillerMdaModule;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.distiller.mda.metamodelhelper.ServiceConst;
import org.levore.modeliotools.metamodelhelper.JavaConstants;
import org.levore.modeliotools.modelvisitor.HandlerAdapter;
import org.levore.modeliotools.modelvisitor.Visitor;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.ITransaction;
import org.modelio.api.modelio.model.IUmlModel;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.infrastructure.NoteType;
import org.modelio.metamodel.uml.infrastructure.Stereotype;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.Association;
import org.modelio.metamodel.uml.statik.AssociationEnd;
import org.modelio.metamodel.uml.statik.Attribute;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Classifier;
import org.modelio.metamodel.uml.statik.NameSpace;
import org.modelio.metamodel.uml.statik.Operation;
import org.modelio.metamodel.uml.statik.Package;
import org.modelio.metamodel.uml.statik.Parameter;
import org.modelio.metamodel.uml.statik.VisibilityMode;

public class DelegateDtos {
	public void createDtos(Class pimEntity) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		//Dtos without association
		try(ITransaction t = session.createTransaction("CreateConf")){
			DelegateDtosHandler createDtosHandler = new DelegateDtosHandler(pimEntity);
			Visitor visitor = new Visitor(createDtosHandler);
			visitor.process(pimEntity);
			t.commit();
		}
		//DtoAssociation
		try(ITransaction t = session.createTransaction("CreateConf")){
			DelegateEndDtosHandler createEndsHandler = new DelegateEndDtosHandler(pimEntity);
			Visitor visitor = new Visitor(createEndsHandler);
			visitor.process(pimEntity);
			t.commit();
		}
	}
	
	public class DelegateDtosHandler extends HandlerAdapter {

		

		private DistillerMdaModule module;
		private IModelingSession session;
		private IUmlModel model;
		private Package dtoPackage;
		private Stereotype eventDependencySt;
		private Stereotype javaDtoSt;
		private TagType javaDtoGuidTag;
		private Stereotype javaDesignerClassSt;
		private Stereotype javaDesignerAttributeSt;
		private Stereotype javaDtoAttributeSt;
		private Stereotype javaDtoAgregateSt;

		private boolean isDtoAgregateInitialized;

		private Stereotype javaDtoHeaderSt;

		private Class pimAggregate;

		public DelegateDtosHandler(Class pimAggregate) {

			this.module = DistillerMdaModule.getInstance();
			this.session = module.getModuleContext().getModelingSession();
			this.model = this.session.getModel();
			this.dtoPackage = ServiceObjFinder.FindServiceDtoPack(pimAggregate);
			this.pimAggregate = pimAggregate;
			eventDependencySt = DistillerConst.DependencySt();
			javaDtoSt = ServiceConst.DtoSt();
			javaDtoGuidTag = ServiceConst.DtoSt_DtoGuidTag();
			javaDesignerClassSt = JavaConstants.GetJavaClassStereotype(module);
			javaDesignerAttributeSt = JavaConstants.GetJavaAttributePropertyStereotype(module);
			javaDtoAttributeSt = ServiceConst.DtoAttributeSt(module);
			javaDtoAgregateSt = ServiceConst.DtoAgregateSt();
			javaDtoHeaderSt = ServiceConst.DtoHeaderSt();
			isDtoAgregateInitialized = false;
		}

		@Override
		public void beginVistingClassifier(Classifier visited) {
			createDtoClass(visited);

		}

		@Override
		public void beginVistingAggregationEnd(AssociationEnd assocEnd) {
			createDtoClass(assocEnd.getTarget());

		}

		private void createDtoClass(Classifier visited) {
			Class pimEntity = (Class)visited;
			Class javaDto = ServiceObjFinder.FindDtoFromPim(pimAggregate, pimEntity);
			String dtoName = ServicePrototypeName.getDtoName(pimEntity);
			if (javaDto==null) {
				javaDto = model.createClass(dtoName, (NameSpace) dtoPackage);
				javaDto.getExtension().add(javaDtoSt);
				javaDto.getExtension().add(javaDesignerClassSt);
				javaDto.putTagValue(javaDtoGuidTag, pimAggregate.getUuid());
				if (!isDtoAgregateInitialized) {
					javaDto.getExtension().add(javaDtoAgregateSt);
					createHeaderDto(pimEntity, javaDto, dtoName);
					isDtoAgregateInitialized = true;
				}
				model.createDependency(javaDto, pimEntity ,eventDependencySt);
				

				//create id
				 Attribute id = model.createAttribute("id", model.getUmlTypes().getSTRING(), javaDto);
				 id.getExtension().add(javaDesignerAttributeSt);

				//create attributes
				for (Attribute pimAttribute : pimEntity.getOwnedAttribute()) {
					Attribute javaAttribute = model.createAttribute(pimAttribute.getName(), pimAttribute.getType(), javaDto);
					javaAttribute.setVisibility(VisibilityMode.PUBLIC);
					javaAttribute.setMultiplicityMax(pimAttribute.getMultiplicityMax());
					model.createDependency(javaAttribute, pimAttribute ,eventDependencySt);
					javaAttribute.getExtension().add(javaDesignerAttributeSt);
					javaAttribute.getExtension().add(javaDtoAttributeSt);

				}
				
				NoteType javaCodeNoteType = JavaConstants.GetJavaCodeType(module);
				Class jEntity = ServiceObjFinder.FindJEntityFromDto(javaDto);
				createFindEntityFromDtoOperation(javaDto, javaCodeNoteType, jEntity);
				createIsDtoPresentOperation(javaDto, javaCodeNoteType, jEntity);
				createIsEntityPresentOperation(javaDto, javaCodeNoteType, jEntity);
			}


		}

		private void createIsEntityPresentOperation(Class javaDto, NoteType javaCodeNoteType, Class jEntity) {
			Operation IsEntityPresent = model.createOperation("IsEntityPresent", javaDto);
			IsEntityPresent.setIsClass(true);
			
			Parameter out = model.createParameter();
			out.setType(model.getUmlTypes().getBOOLEAN());
			out.setMultiplicityMax("1");
			IsEntityPresent.setReturn(out);;
			
			Parameter dto = model.createParameter();
			dto.setName("entity");
			dto.setType(jEntity);
			IsEntityPresent.getIO().add(dto);
			
			Parameter entities = model.createParameter();
			entities.setName("dtos");
			entities.setType(javaDto);
			entities.setMultiplicityMax("*");
			IsEntityPresent.getIO().add(entities);
			
			String code = ServiceCodeTemplate.GetDto_IsEntityPresentOperation(javaDto, jEntity);		
			model.createNote(javaCodeNoteType, IsEntityPresent, code);
		}
		
		private void createIsDtoPresentOperation(Class javaDto, NoteType javaCodeNoteType, Class jEntity) {
			Operation IsDtoPresent = model.createOperation("IsDtoPresent", javaDto);
			IsDtoPresent.setIsClass(true);
			
			Parameter out = model.createParameter();
			out.setType(model.getUmlTypes().getBOOLEAN());
			out.setMultiplicityMax("1");
			IsDtoPresent.setReturn(out);;
			
			Parameter dto = model.createParameter();
			dto.setName("dto");
			dto.setType(javaDto);
			IsDtoPresent.getIO().add(dto);
			
			Parameter entities = model.createParameter();
			entities.setName("entities");
			entities.setType(jEntity);
			entities.setMultiplicityMax("*");
			IsDtoPresent.getIO().add(entities);
			
			String code = ServiceCodeTemplate.GetDto_IsDtoPresentOperation(javaDto, jEntity);		
			model.createNote(javaCodeNoteType, IsDtoPresent, code);
		}

		private void createFindEntityFromDtoOperation(Class javaDto, NoteType javaCodeNoteType, Class jEntity) {
			Operation FindEntityFromDtoOperation = model.createOperation("FindEntityFromDtoOperation", javaDto);
			FindEntityFromDtoOperation.setIsClass(true);
			
			Parameter out = model.createParameter();
			out.setType(jEntity);
			out.setMultiplicityMax("1");
			FindEntityFromDtoOperation.setReturn(out);;
			
			Parameter dto = model.createParameter();
			dto.setName("dto");
			dto.setType(javaDto);
			FindEntityFromDtoOperation.getIO().add(dto);
			
			Parameter entities = model.createParameter();
			entities.setName("entities");
			entities.setType(jEntity);
			entities.setMultiplicityMax("*");
			FindEntityFromDtoOperation.getIO().add(entities);
			
			String code = ServiceCodeTemplate.GetDto_FindEntityFromDtoOperation(jEntity);		
			model.createNote(javaCodeNoteType, FindEntityFromDtoOperation, code);
		}

		private void createHeaderDto(Class pimEntity, Class javaDto, String dtoName) {
			Class javaHeaderDto = ServiceObjFinder.FindJHeaderFromPim(pimEntity);
			if (javaHeaderDto == null) {
				javaHeaderDto = model.createClass("Header" + dtoName, (NameSpace) dtoPackage);
				javaHeaderDto.getExtension().add(javaDesignerClassSt);
				javaHeaderDto.getExtension().add(javaDtoSt);
				javaHeaderDto.getExtension().add(javaDtoHeaderSt);
				javaHeaderDto.putTagValue(javaDtoGuidTag, pimAggregate.getUuid());
				
				model.createDependency(javaHeaderDto, pimEntity ,eventDependencySt);

				//create id
				Attribute id = model.createAttribute("id", model.getUmlTypes().getSTRING(), javaHeaderDto);
				id.getExtension().add(javaDesignerAttributeSt);

				//create attributes
				for (Attribute pimAttribute : pimEntity.getOwnedAttribute()) {
					Attribute javaAttribute = model.createAttribute(pimAttribute.getName(), pimAttribute.getType(), javaHeaderDto);
					javaAttribute.setVisibility(VisibilityMode.PUBLIC);
					javaAttribute.setMultiplicityMax(pimAttribute.getMultiplicityMax());
					model.createDependency(javaAttribute, pimAttribute ,eventDependencySt);
					javaAttribute.getExtension().add(javaDesignerAttributeSt);
					javaAttribute.getExtension().add(javaDtoAttributeSt);

				}
			}
		}



		

		

//		private Class getJavaDto(Class pimEntity) {
//			Class result = null;
//			String dtoName = ServicePrototypeName.getDtoName(pimEntity);
//			for (Class clazz : dtoPackage.getOwnedElement(Class.class)) {
//				if(clazz.getName().equals(dtoName)) {
//					result = clazz;
//					break;
//				}
//			}
//			return result;
//		}
		

		
		


	}

	public class DelegateEndDtosHandler extends HandlerAdapter {

		
		private DistillerMdaModule module;
		private IModelingSession session;
		private IUmlModel model;
		private Stereotype eventDependencySt;
		private Stereotype javaDesignerAssociationEndSt;
		private Stereotype javaDtoAssociationEndSt;
		private Class pimAggregate;

		public DelegateEndDtosHandler(Class pimAggregate) {

			this.module = DistillerMdaModule.getInstance();
			this.session = module.getModuleContext().getModelingSession();
			this.model = this.session.getModel();
			this.pimAggregate = pimAggregate;
			eventDependencySt = DistillerConst.DependencySt();
			javaDesignerAssociationEndSt = JavaConstants.GetJavaAssociationEndPropertyStereotype(module);
			javaDtoAssociationEndSt = ServiceConst.DtoAssociationEndSt(module);
		}

		@Override
		public void beginVistingCompositionEnd(AssociationEnd pimTargetAssociationEnd) {
			CreateAssociationEnd(pimTargetAssociationEnd);
			
		}

		@Override
		public void beginVistingAggregationEnd(AssociationEnd assocEnd) {
			CreateAssociationEnd(assocEnd);
			
		}
		private void CreateAssociationEnd(AssociationEnd pimTargetAssociationEnd) {
			Class pimSrc = (Class)pimTargetAssociationEnd.getSource();
			Class pimTarget = (Class)pimTargetAssociationEnd.getTarget();
			Class javaSrc = ServiceObjFinder.FindDtoFromPim(pimAggregate, pimSrc);
			Class javaTarget = ServiceObjFinder.FindDtoFromPim(pimAggregate, pimTarget);
			
			Association javaAssociation = JavaModelObjFinder.FindJAssociationFromJEntity(pimTargetAssociationEnd.getName(), javaSrc);
			if (javaAssociation == null) {
				javaAssociation = model.createAssociation(javaSrc, javaTarget, pimTargetAssociationEnd.getName());
				AssociationEnd javaAssociationTargetEnd = javaAssociation.getEnd().get(1);
				javaAssociationTargetEnd.getExtension().add(javaDesignerAssociationEndSt);
				javaAssociationTargetEnd.getExtension().add(javaDtoAssociationEndSt);
				javaAssociationTargetEnd.setVisibility(VisibilityMode.PUBLIC);
				javaAssociationTargetEnd.setMultiplicityMax(pimTargetAssociationEnd.getMultiplicityMax());
				javaAssociationTargetEnd.getOpposite().setMultiplicityMax(pimTargetAssociationEnd.getOpposite().getMultiplicityMax());
				javaAssociationTargetEnd.setAggregation(pimTargetAssociationEnd.getAggregation());

				model.createDependency(javaAssociationTargetEnd, pimTargetAssociationEnd,eventDependencySt);
			}
		}

		
		
		
		
		

	}
}
