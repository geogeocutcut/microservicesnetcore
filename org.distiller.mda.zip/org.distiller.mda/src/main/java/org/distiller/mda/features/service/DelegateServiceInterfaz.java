package org.distiller.mda.features.service;

import org.distiller.mda.features.datadomain.DataDomainObjFinder;
import org.distiller.mda.impl.DistillerMdaModule;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.distiller.mda.metamodelhelper.ServiceConst;
import org.levore.modeliotools.metamodelhelper.JavaConstants;
import org.levore.modeliotools.metamodelhelper.ModelerModuleConstants;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.ITransaction;
import org.modelio.api.modelio.model.IUmlModel;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.infrastructure.NoteType;
import org.modelio.metamodel.uml.infrastructure.Stereotype;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.Interface;
import org.modelio.metamodel.uml.statik.Operation;
import org.modelio.metamodel.uml.statik.Package;
import org.modelio.metamodel.uml.statik.Parameter;
import org.modelio.metamodel.uml.statik.VisibilityMode;

public class DelegateServiceInterfaz {
	private static String serviceInterfaceProtoName = "com.levore.%s.service.%s.interface";
	private static String serviceDtoProtoName = "com.levore.%s.service.%s.dto";
	private static String serviceTransformerProtoName = "com.levore.%s.service.%s.transformer";
	private static String entityNotFoundExceptionProtoName = "%sNotFoundException";
	private static String invalidEntitydExceptionProtoName = "Invalid%sException";
	private static String iEntityServiceProtoName = "I%sService";
	
	
	public void actionPerformed(Class pimEntity,Package serviceInterfacePack, IModule module) {
		
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		Stereotype javaDesignerClassSt = JavaConstants.GetJavaClassStereotype(module);
		Stereotype javaDesignerInterfaceSt = JavaConstants.GetJavaInterfaceStereotype(module);
		Stereotype eventDependencySt = DistillerConst.DependencySt();
		TagType javaExtendsType = JavaConstants.GetJavaExtendsClassType(module);
		
		
		
		
		
		try(ITransaction t = session.createTransaction("CreateConf")){
			Class entityNotFoundException = ServiceObjFinder.FindEntityNotFoundExceptionFromEntity(pimEntity);
			Class invalidEntityException = ServiceObjFinder.FindInvalidEntityExceptionFromPim(pimEntity);
			Interface iEntityService = ServiceObjFinder.FindIServiceFrom(pimEntity);
			Stereotype constructorSt = ModelerModuleConstants.GetConstructorSt(module);
			Stereotype EntityNotFoundExceptionSt = ServiceConst.EntityNotFoundExceptionSt();
			Stereotype InvalidEntityExceptionSt =  ServiceConst.InvalidEntityExceptionSt();
			Stereotype IEntityServiceSt = ServiceConst.IEntityServiceSt();
			
			NoteType javaCodeNoteType = JavaConstants.GetJavaCodeType(module);
			
			if(entityNotFoundException == null) {
				String entityNotFoundExName = getEntityNotFoundExceptionName(pimEntity);
				entityNotFoundException = model.createClass(entityNotFoundExName, serviceInterfacePack, javaDesignerClassSt);
				entityNotFoundException.getExtension().add(EntityNotFoundExceptionSt);
				entityNotFoundException.putTagValue(javaExtendsType, "java.lang.RuntimeException");
				model.createDependency(entityNotFoundException, pimEntity,eventDependencySt);
				
				Operation create = model.createOperation("create", entityNotFoundException, constructorSt);
				//Création des paramètres d'entrée
				Parameter dataParam = model.createParameter();
				dataParam.setName("message");
				dataParam.setType(model.getUmlTypes().getSTRING());
				create.getIO().add(dataParam);
				model.createNote(javaCodeNoteType, create, "super(message);");
				
			}
			
			if (invalidEntityException==null) {
				String invalidEntityName = getinvalidEntitydExceptionName(pimEntity);
				invalidEntityException = model.createClass(invalidEntityName, serviceInterfacePack, javaDesignerClassSt);
				invalidEntityException.getExtension().add(InvalidEntityExceptionSt);
				invalidEntityException.putTagValue(javaExtendsType, "java.lang.RuntimeException");
				model.createDependency(invalidEntityException, pimEntity,eventDependencySt);
				
				Operation create = model.createOperation("create", invalidEntityException, constructorSt);
				//Création des paramètres d'entrée
				Parameter dataParam = model.createParameter();
				dataParam.setName("message");
				dataParam.setType(model.getUmlTypes().getSTRING());
				create.getIO().add(dataParam);
				model.createNote(javaCodeNoteType, create, "super(message);");
			}
			
			if (iEntityService==null) {
				Component dataDomain = DataDomainObjFinder.FindDataDomain(pimEntity);
				Class dtoAgregate = ServiceObjFinder.FindDtoAggregateFromPim(pimEntity);
				Class dtoHeader = ServiceObjFinder.FindJHeaderFromPim(pimEntity); 
				Interface closeable = DataDomainObjFinder.FindCloseable(dataDomain);
				String iEntityServiceName = getiEntityServiceName(pimEntity);
				iEntityService = model.createInterface(iEntityServiceName, serviceInterfacePack, javaDesignerInterfaceSt);
				iEntityService.getExtension().add(IEntityServiceSt);
				iEntityService.putTagValue(JavaConstants.GetJavaExtendsInterfaceType(module), "java.io.Closeable");
				model.createDependency(iEntityService, pimEntity,eventDependencySt);
				//model.createInterfaceRealization(iEntityService, closeable);
				
				addCreateMethod(dtoAgregate, iEntityService);
				addUpdateMethod(dtoAgregate, iEntityService);
				addDeleteMethod(dtoAgregate, iEntityService);
				addGetMethod(dtoAgregate, iEntityService);
				addGetAllMethod(dtoHeader, iEntityService);
				
			}
			t.commit();
		}
	}

	

	
	
	

	public static String getServiceDtoName(Class pimEntity, Component domainData) {
		String lcPimEntityName = pimEntity.getName().toLowerCase();
		String lcDomainData = domainData.getName().toLowerCase();
		String serviceDtoName = String.format(serviceDtoProtoName, lcDomainData, lcPimEntityName);
		return serviceDtoName;
	}
	
	public static String getServiceInterfaceName(Class pimEntity, Component domainData) {
		String lcPimEntityName = pimEntity.getName().toLowerCase();
		String lcDomainData = domainData.getName().toLowerCase();
		String serviceInterfaceName = String.format(serviceInterfaceProtoName, lcDomainData, lcPimEntityName);
		return serviceInterfaceName;
	}
	public static  String getserviceTransformerName(Class pimEntity, Component domainData) {
		String lcPimEntityName = pimEntity.getName().toLowerCase();
		String lcDomainData = domainData.getName().toLowerCase();
		String serviceTransformerName = String.format(serviceTransformerProtoName, lcDomainData, lcPimEntityName);
		return serviceTransformerName;
	}
	public static  String getEntityNotFoundExceptionName(Class pimEntity) {
		return String.format(entityNotFoundExceptionProtoName, pimEntity.getName());
	}
	public static  String getinvalidEntitydExceptionName(Class pimEntity) {
		return String.format(invalidEntitydExceptionProtoName, pimEntity.getName());
	}
	public static  String getiEntityServiceName(Class pimEntity) {
		return String.format(iEntityServiceProtoName, pimEntity.getName());
	}
	
	
	
	
	
	
	private void addCreateMethod(Class dtoAgregate, Interface iEntityService) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		//add create method
		Operation createOperation = model.createOperation("create", iEntityService);
			createOperation.setVisibility(VisibilityMode.PUBLIC);
			//Création du paramètre de retour
			Parameter outParam = model.createParameter();
			outParam.setType(dtoAgregate);
			createOperation.setReturn(outParam);
			createOperation.getReturn().setMultiplicityMax("1");

			//Création des paramètres d'entrée
			Parameter dataParam = model.createParameter();
			dataParam.setName("dto");
			dataParam.setType(dtoAgregate);
			createOperation.getIO().add(dataParam);
		
	}

	private void addUpdateMethod(Class dtoAgregate, Interface iEntityService) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		//add create method
		Operation createOperation = model.createOperation("update", iEntityService);
			createOperation.setVisibility(VisibilityMode.PUBLIC);
			//Création du paramètre de retour
			Parameter outParam = model.createParameter();
			outParam.setType(dtoAgregate);
			createOperation.setReturn(outParam);
			createOperation.getReturn().setMultiplicityMax("1");

			//Création des paramètres d'entrée
			Parameter dataParam = model.createParameter();
			dataParam.setName("dto");
			dataParam.setType(dtoAgregate);
			createOperation.getIO().add(dataParam);
			
		

	}

	private void addDeleteMethod(Class dtoAgregate, Interface iEntityService) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		Operation createOperation = model.createOperation("delete", iEntityService);
			createOperation.setVisibility(VisibilityMode.PUBLIC);

			//Création des paramètres d'entrée
			Parameter dataParam = model.createParameter();
			dataParam.setName("id");
			dataParam.setType(model.getUmlTypes().getSTRING());
			createOperation.getIO().add(dataParam);
		
	}

	private void addGetMethod(Class dtoAgregate, Interface iEntityService) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		Operation createOperation = model.createOperation("get", iEntityService);
			createOperation.setVisibility(VisibilityMode.PUBLIC);

			//Création du paramètre de retour
			Parameter outParam = model.createParameter();
			outParam.setType(dtoAgregate);
			createOperation.setReturn(outParam);
			createOperation.getReturn().setMultiplicityMax("1");


			//Création des paramètres d'entrée
			Parameter dataParam = model.createParameter();
			dataParam.setName("id");
			dataParam.setType(model.getUmlTypes().getSTRING());
			createOperation.getIO().add(dataParam);
		
	}

	private void addGetAllMethod(Class javaEntity, Interface iEntityService) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		Operation createOperation = model.createOperation("getAll", iEntityService);
			createOperation.setVisibility(VisibilityMode.PUBLIC);

			//Création du paramètre de retour
			Parameter outParam = model.createParameter();
			outParam.setType(javaEntity);
			createOperation.setReturn(outParam);
			createOperation.getReturn().setMultiplicityMax("*");


			//Création des paramètres d'entrée
			Parameter pageNumber = model.createParameter();
			pageNumber.setName("pageNumber");
			pageNumber.setType(model.getUmlTypes().getINTEGER());
			createOperation.getIO().add(pageNumber);
			
			Parameter pageSize = model.createParameter();
			pageSize.setName("pageSize");
			pageSize.setType(model.getUmlTypes().getINTEGER());
			createOperation.getIO().add(pageSize);
			
			
	}
	
}
