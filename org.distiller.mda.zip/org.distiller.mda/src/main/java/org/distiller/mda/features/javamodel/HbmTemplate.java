package org.distiller.mda.features.javamodel;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

import org.distiller.mda.features.service.ServiceCodeTemplate;
import org.distiller.mda.impl.DistillerMdaModule;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.IUMLTypes;
import org.modelio.api.modelio.model.IUmlModel;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.statik.AssociationEnd;
import org.modelio.metamodel.uml.statik.Attribute;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.GeneralClass;
import org.modelio.metamodel.uml.statik.Package;

public class HbmTemplate {
	private String header= "org/distiller/mda/HbmTemplate/header.txt";
	private String end = "org/distiller/mda/HbmTemplate/end.txt";
	private String attribute = "org/distiller/mda/HbmTemplate/attribute.txt";
	private String onetoone = "org/distiller/mda/HbmTemplate/onetoone.txt";
	private String onetomany = "org/distiller/mda/HbmTemplate/onetomany.txt";
	private String manytoone = "org/distiller/mda/HbmTemplate/manytoone.txt";
	private String manytomany = "org/distiller/mda/HbmTemplate/manytomany.txt";
	private Package jModelPack;
	private IUMLTypes umlType;
	
	
	public HbmTemplate(Package jModelPack) {
		this.jModelPack = jModelPack;
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		umlType = model.getUmlTypes();
	}
	
	public String getHeader(Class jEntity) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(header);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String result = tmpl.toString();
		result = result.replaceAll("@@JEntity", jEntity.getName());
		result = result.replaceAll("@@JavaModelPack", jModelPack.getName());
		
		return result;
	}
	public String getEnd() {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(end);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		return tmpl.toString();
	}
	public String getAttribute(Attribute attr) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(attribute);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		String result = tmpl.toString();
		result = result.replaceAll("@@name", attr.getName());
		result = result.replaceAll("@@NAME", attr.getName().toUpperCase());
		result = result.replaceAll("@@type", getHbmTypeFromUmlType(attr.getType()));
		return result;
	}
	
	public String getOnetoone(AssociationEnd end) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(onetoone);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		String result = formatEndCode(end, tmpl);
		return result;
	}
	public String getOnetomany(AssociationEnd end) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(onetomany);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		String result = formatEndCode(end, tmpl);
		return result;
	}

	
	public String getManytoone(AssociationEnd end) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(manytoone);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		String result = formatEndCode(end, tmpl);
		return result;
	}
	public String getManytomany(AssociationEnd end) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(manytomany);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		String result = formatEndCode(end, tmpl);
		return result;
	}
	private String formatEndCode(AssociationEnd end, StringBuilder tmpl) {
		String result = tmpl.toString();
		Class jEntity = (Class)end.getSource();
		result = result.replaceAll("@@name", end.getName());
		result = result.replaceAll("@@NAME", end.getName().toUpperCase());
		result = result.replaceAll("@@targetJavaModelPack", jModelPack.getName());
		result = result.replaceAll("@@JENTITY", jEntity.getName().toLowerCase());
		result = result.replaceAll("@@targetJEntity", end.getTarget().getName());
		return result;
	}
	private String getHbmTypeFromUmlType(GeneralClass type) {
		String result = null;
		if (type.getUuid().equals(umlType.getSTRING().getUuid()))
			result = "string";
		else if (type.getUuid().equals(umlType.getDOUBLE().getUuid()))
			result = "double";
		else if (type.getUuid().equals(umlType.getINTEGER().getUuid()))
			result = "int";
		else if (type.getUuid().equals(umlType.getBOOLEAN().getUuid()))
			result = "boolean";
		else if (type.getUuid().equals(umlType.getDATE().getUuid()))
			result = "date";
//		else if (type.getUuid().equals(umlType.getSTRING().getUuid()))
//			result = "string";
//		else if (type.getUuid().equals(umlType.getSTRING().getUuid()))
//			result = "string";
//		else if (type.getUuid().equals(umlType.getSTRING().getUuid()))
//			result = "string";
//		else if (type.getUuid().equals(umlType.getSTRING().getUuid()))
//			result = "string";
//		else if (type.getUuid().equals(umlType.getSTRING().getUuid()))
//			result = "string";
		else
			result = "string";
		
		return result;
	}

}
