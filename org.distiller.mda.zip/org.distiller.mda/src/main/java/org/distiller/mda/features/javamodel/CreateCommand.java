package org.distiller.mda.features.javamodel;

import java.util.List;

import org.distiller.mda.features.datadomain.DataDomainObjFinder;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.levore.modeliotools.treevisitor.Visitor;
import org.modelio.api.module.IModule;
import org.modelio.api.module.command.DefaultModuleCommandHandler;
import org.modelio.api.module.context.log.ILogService;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.Package;
import org.modelio.vcore.smkernel.mapi.MObject;

/**
 * Implementation of the IModuleContextualCommand interface.
 * <br>The module contextual commands are displayed in the contextual menu and in the specific toolbar of each module property page.
 * <br>The developer may inherit the DefaultModuleContextualCommand class which contains a default standard contextual command implementation.
 *
 */
public class CreateCommand extends DefaultModuleCommandHandler {
	/**
	 * Constructor.
	 */
	public CreateCommand() {
		super();
	}

	/**
	 * @see org.modelio.api.module.commands.DefaultModuleContextualCommand#accept(java.util.List,
	 *      org.modelio.api.module.IModule)
	 */
	@Override
	public boolean accept(List<MObject> selectedElements, IModule module) {
		boolean result = false;
		if (selectedElements.size() == 1 && selectedElements.get(0) instanceof Package) {
			Package selectedElement = (Package)selectedElements.get(0);
			result = selectedElement.isStereotyped(DistillerConst.IndependantModelSt());
		}
		return result;
	}

	/**
	 * @see org.modelio.api.module.commands.DefaultModuleContextualCommand#actionPerformed(java.util.List,
	 *      org.modelio.api.module.IModule)
	 */
	@Override
	public void actionPerformed(List<MObject> selectedElements, IModule module) {
		ILogService logService = module.getModuleContext().getLogService();
		logService.info("CreateDomainMapCommand - actionPerformed(...)");
		Package independantModel = (Package)selectedElements.get(0);

		DelegateJEntity jEntityDelegate = new DelegateJEntity();
		jEntityDelegate.createJentities(independantModel);

		DelegateRepository iRepositoryDelegate = new DelegateRepository();
		iRepositoryDelegate.createIRepositories(independantModel);
		iRepositoryDelegate.createRepositories(independantModel);

		DelegateRepositoryBuilder builderDelegate = new DelegateRepositoryBuilder();
		builderDelegate.createIBuiolder(independantModel);
		builderDelegate.createBuilder(independantModel);
		
		
//		IModule module = DistillerMdaModule.getInstance();
//		IModelingSession session = module.getModuleContext().getModelingSession();
		Component dataDomain = DataDomainObjFinder.FindDataDomain(independantModel);
		
		HbmHandler handler = new HbmHandler(dataDomain);
		Visitor visitor = new Visitor(handler);
		visitor.process(independantModel);


	}


}
