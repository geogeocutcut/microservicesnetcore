package org.distiller.mda.features.service;

import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Component;

public class ServicePrototypeName {
	public static String serviceInterfacePackProtoName = "com.levore.%s.service.interfaz";
	public static String dtoPackProtoName = "com.levore.%s.service.%s.dto";
	public static String transformerPackProtoName = "com.levore.%s.service.transformer";
	public static String transformerProtoName = "%sTransformer";
	public static String headerTransformerProtoName = "Header%sTransformer";
	public static String entityNotFoundExceptionProtoName = "%sNotFoundException";
	public static String invalidEntitydExceptionProtoName = "Invalid%sException";
	public static String iServiceProtoName = "I%sService";
	private static String dtoProtoName = "%sDto";
	
	private static String ServiceImplPackProtoName = "com.levore.%s.service.impl";
	private static String ServiceImplProtoName = "%sService";
	
	
	
	public static String getServiceImplPackName(Component dataDomain) {
		return String.format(ServiceImplPackProtoName, dataDomain.getName()).toLowerCase();
	}

	public static String getServiceImplName(Class pimAggregate) {
		return String.format(ServiceImplProtoName, pimAggregate.getName());
	}
	
	public static String getTransformerName(Class pimAggregate) {
		return String.format(ServicePrototypeName.transformerProtoName, pimAggregate.getName());
	}
	
	public static String getHeaderTransformerName(Class pimAggregate) {
		return String.format(ServicePrototypeName.headerTransformerProtoName, pimAggregate.getName());
	}
	
	public static String getDtoPackName(Class pimEntity, Component domainData) {
		String lcPimEntityName = pimEntity.getName().toLowerCase();
		String lcDomainData = domainData.getName().toLowerCase();
		String serviceDtoName = String.format(ServicePrototypeName.dtoPackProtoName, lcDomainData, lcPimEntityName);
		return serviceDtoName;
	}
	
	public static String getServiceInterfacePackName(Class pimEntity, Component domainData) {
		String lcDomainData = domainData.getName().toLowerCase();
		String serviceInterfaceName = String.format(ServicePrototypeName.serviceInterfacePackProtoName, lcDomainData);
		return serviceInterfaceName;
	}
	public static  String getTransformerName(Class pimEntity, Component domainData) {
		String lcDomainData = domainData.getName().toLowerCase();
		String serviceTransformerName = String.format(ServicePrototypeName.transformerPackProtoName, lcDomainData);
		return serviceTransformerName;
	}
	public static  String getEntityNotFoundExceptionName(Class pimEntity) {
		return String.format(ServicePrototypeName.entityNotFoundExceptionProtoName, pimEntity.getName());
	}
	public static  String getinvalidEntitydExceptionName(Class pimEntity) {
		return String.format(ServicePrototypeName.invalidEntitydExceptionProtoName, pimEntity.getName());
	}
	public static  String getIServiceName(Class pimEntity) {
		return String.format(ServicePrototypeName.iServiceProtoName, pimEntity.getName());
	}
	
	public static String getDtoName(Class pimEntity) {
		return String.format(dtoProtoName , pimEntity.getName());
	}

	
}
