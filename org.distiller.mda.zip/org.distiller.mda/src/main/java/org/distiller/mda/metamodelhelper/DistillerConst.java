package org.distiller.mda.metamodelhelper;

import org.distiller.mda.impl.DistillerMdaModule;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.diagrams.ClassDiagram;
import org.modelio.metamodel.uml.infrastructure.Dependency;
import org.modelio.metamodel.uml.infrastructure.ModelTree;
import org.modelio.metamodel.uml.infrastructure.Stereotype;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.Package;
import org.modelio.vcore.smkernel.mapi.MClass;
import org.modelio.vcore.smkernel.mapi.MMetamodel;

public class DistillerConst {
	public static final String _ModuleName = "DistillerMda";
	
	public static final String _DomainMapSt = "DomainMapSt";
	public static final String _DataDomainSt = "DataDomainSt";
	public static final String _DataDomainSt_DirectoryTag = "DataDomainSt_DirectoryTag";
	public static final String _IndependantModelSt = "IndependantModelSt";
	public static final String _EntitySt = "EntitySt";
	public static final String _StructureSt = "StructureSt";
	public static final String _EventDependencySt = "EventDependencySt";
	public static final String _DataDomain_ModelDiagramSt="DataDomain_ModelDiagramSt";

	public static Stereotype DomainMapSt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Package.class);
		result = session.getMetamodelExtensions().getStereotype(_ModuleName,_DomainMapSt,mClass);
		return result;
	}
	public static Stereotype DataDomainSt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Component.class);
		result = session.getMetamodelExtensions().getStereotype(_ModuleName,_DataDomainSt,mClass);
		return result;
	}
	public static TagType DataDomainSt_DirectoryTag() {
		IModule module = DistillerMdaModule.getInstance();
		TagType result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Component.class);
		result = session.getMetamodelExtensions().getTagType(_ModuleName, _DataDomainSt_DirectoryTag, mClass);
		return result;
	}
	public static Stereotype IndependantModelSt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Package.class);
		result = session.getMetamodelExtensions().getStereotype(_ModuleName,_IndependantModelSt,mClass);
		return result;
	}
	public static Stereotype EntitySt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Class.class);
		result = session.getMetamodelExtensions().getStereotype(_ModuleName,_EntitySt,mClass);
		return result;
	}
	public static Stereotype DataStructureSt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Component.class);
		result = session.getMetamodelExtensions().getStereotype(_ModuleName,_StructureSt,mClass);
		return result;
	}
	public static Stereotype DependencySt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Dependency.class);
		result = session.getMetamodelExtensions().getStereotype(_ModuleName,_EventDependencySt,mClass);
		return result;
	}
	public static Stereotype DataDomain_ModelDiagramSt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(ClassDiagram.class);
		result = session.getMetamodelExtensions().getStereotype(_ModuleName,_DataDomain_ModelDiagramSt,mClass);
		return result;
	}
	
	
	public static Component DataDomain (ModelTree element) {
		Component result = null;
		ModelTree owner = element.getOwner();
		if (owner != null 
				&& owner instanceof Component
				&& owner.isStereotyped(DistillerConst.DataDomainSt())) {
			result = (Component)owner;
		} else if(owner != null) {
			result = DataDomain(owner);
		} 
		return result;
	}
	
		
	
}
