package org.distiller.mda.features.service;

import org.distiller.mda.features.javamodel.JavaModelObjFinder;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.distiller.mda.metamodelhelper.JavaModelConst;
import org.distiller.mda.metamodelhelper.ServiceConst;
import org.modelio.metamodel.uml.infrastructure.Dependency;
import org.modelio.metamodel.uml.infrastructure.ModelElement;
import org.modelio.metamodel.uml.infrastructure.Stereotype;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.Interface;
import org.modelio.metamodel.uml.statik.Package;

public class ServiceObjFinder {
	public static Stereotype javaDtoHeaderSt = ServiceConst.DtoHeaderSt();
	public static Stereotype javaDtoSt = ServiceConst.DtoSt();
	public static Stereotype javaDtoAgregateSt = ServiceConst.DtoAgregateSt();
	public static Stereotype JavaDtoHeaderSt = ServiceConst.DtoHeaderSt();
	public static Stereotype EntityNotFoundExceptionSt = ServiceConst.EntityNotFoundExceptionSt();
	public static Stereotype InvalidEntityExceptionSt =  ServiceConst.InvalidEntityExceptionSt();
	public static Stereotype IEntityServiceSt = ServiceConst.IEntityServiceSt();
	public static TagType JavaDtoSt_DtoGuidTag = ServiceConst.DtoSt_DtoGuidTag();

	public static Class FindPimEntityFromImpactedPack(Package pack) {
		Class result = null;
		for (Dependency dep : pack.getDependsOnDependency()) {
			ModelElement dependsOn = dep.getDependsOn();
			if (dependsOn instanceof Class && dependsOn.isStereotyped(DistillerConst.EntitySt())) {
				result = (Class)dependsOn;
			}
		}
		return result;
	}

	public static Package FindServiceDtoPack(Class pimEntity) {
		Stereotype javaServiceDtoSt = ServiceConst.ServiceDTOPackageSt();
		Package result = null;
		for (Dependency dep : pimEntity.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();
			if (impacted instanceof Package 
					&& impacted.isStereotyped(javaServiceDtoSt)) {
				result = (Package)impacted;
				break;
			}
		}
		return result;
	}

	public static Package FindServiceInterfacePack(Component dataDomain) {
		Stereotype javaServiceInterfaceSt = ServiceConst.ServiceInterfacePackageSt();
		Package result = null;
		for (Dependency dep : dataDomain.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Package 
					&& impacted.isStereotyped(javaServiceInterfaceSt)) {
				result = (Package)impacted;
				break;
			}
		}
		return result;
	}


	public static Package FindserviceTransformerPack(Component dataDomain) {
		Stereotype javaServiceTransformerSt = ServiceConst.ServiceTransformerPackageSt();
		Package result = null;
		for (Dependency dep : dataDomain.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();
			if (impacted instanceof Package 
					&& impacted.isStereotyped(javaServiceTransformerSt)) {
				result = (Package)impacted;
				break;
			}
		}
		return result;
	}

	public static Class FindDtoAggregateFromPim(Class pimEntity) {
		Class result = null;
		for (Dependency dep : pimEntity.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Class 
					&& impacted.isStereotyped(javaDtoAgregateSt)) {
				result = (Class)impacted;
				break;
			}
		}
		return result;
	}

	public static Class FindDtoFromPim(Class pimAggregate, Class pimSrc) {
		Class result = null;
		for (Dependency dep : pimSrc.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Class 
					&& impacted.isStereotyped(javaDtoSt)
					&& !impacted.isStereotyped(JavaDtoHeaderSt)
					&& impacted.getTagValue(JavaDtoSt_DtoGuidTag).equals(pimAggregate.getUuid())) {

				result = (Class)impacted;

				break;
			}
		}
		return result;
	}

	public static Class FindJHeaderFromPim(Class pimEntity) {
		Class result = null;
		for (Dependency dep : pimEntity.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Class 
					&& impacted.isStereotyped(javaDtoHeaderSt)) {
				result = (Class)impacted;
				break;
			}
		}
		return result;
	}

	public static Class FindEntityNotFoundExceptionFromEntity(Class pimEntity) {
		Class result = null;
		for (Dependency dep : pimEntity.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Class 
					&& impacted.isStereotyped(EntityNotFoundExceptionSt)) {
				result = (Class)impacted;
				break;
			}
		}
		return result;
	}

	public static  Class FindInvalidEntityExceptionFromPim(Class pimEntity) {
		Class result = null;
		for (Dependency dep : pimEntity.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Class 
					&& impacted.isStereotyped(InvalidEntityExceptionSt)) {
				result = (Class)impacted;
				break;
			}
		}
		return result;
	}

	public static Interface FindIServiceFrom(Class pimEntity) {
		Interface result = null;
		for (Dependency dep : pimEntity.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Interface 
					&& impacted.isStereotyped(IEntityServiceSt)) {
				result = (Interface)impacted;
				break;
			}
		}
		return result;
	}

	public static Class FindJEntityFromDto(Class javaDto) {
		Class result = null;
		for (Dependency dep1 : javaDto.getDependsOnDependency()) {
			ModelElement dependsOn = dep1.getDependsOn();
			if (dependsOn instanceof Class && dependsOn.isStereotyped(DistillerConst.EntitySt())) {
				for (Dependency dep2 : dependsOn.getImpactedDependency()) {
					ModelElement impacted = dep2.getImpacted();
					if (impacted instanceof Class
							&& impacted.isStereotyped(JavaModelConst.JavaEntitySt())) {
						result = (Class)impacted;
						break;
					}
				}
				break;
			}

		}
		return result;
	}

	public static Class FindDtoFromJEntity(Class pimAggregate, Class target) {
		Class result = null;
		Class pim = JavaModelObjFinder.FindPimEnityFromJEnity(target);
		result = FindDtoFromPim(pimAggregate, pim);
		return result;
	}

	public static Class FindDepperTransformer(Class pimEntity) {
		Class result = null;
		for (Dependency dep : pimEntity.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();
			if (impacted instanceof Class 
					&& impacted.isStereotyped(ServiceConst.DeeperTransformerSt())) {
				result = (Class)impacted;
				break;
			}

		}
		return result;
	}
	
	public static Class FindHeaderTransformer(Class pimEntity) {
		Class result = null;
		for (Dependency dep : pimEntity.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();
			if (impacted instanceof Class 
					&& impacted.isStereotyped(ServiceConst.HeaderTransformerSt())) {
				result = (Class)impacted;
				break;
			}

		}
		return result;
	}

	
	
	public static Package FindServiceImplPack(Component dataDomain) {
		Package result = null;
		for (Dependency dep : dataDomain.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();
			if (impacted instanceof Package 
					&& impacted.isStereotyped(ServiceConst.ServiceImplPackSt())) {
				result = (Package)impacted;
				break;
			}

		}
		return result;
	}
	
	public static Class FindServiceImpl(Class pimAggregate) {
		Class result = null;
		for (Dependency dep : pimAggregate.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();
			if (impacted instanceof Class 
					&& impacted.isStereotyped(ServiceConst.ServiceImplSt())) {
				result = (Class)impacted;
				break;
			}

		}
		return result;
	}

	public static Class FindHeaderDtoAggregateFromPim(Class pimAggregate) {
		Class result = null;
		for (Dependency dep : pimAggregate.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Class 
					&& impacted.isStereotyped(JavaDtoHeaderSt)) {
				result = (Class)impacted;
				break;
			}
		}
		return result;
	}
	
}
