package org.distiller.mda.features.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

import org.modelio.metamodel.uml.statik.AssociationEnd;
import org.modelio.metamodel.uml.statik.Attribute;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Interface;

public class ServiceCodeTemplate {

	public static String Dto_FindEntityFromDtoOperation = "org/distiller/mda/JavaServiceCodeTemplate/Dto_FindEntityFromDtoOperation.txt";
	public static String Tran_ToDto_SetOneAttribute = "org/distiller/mda/JavaServiceCodeTemplate/Tran_ToDto_SetOneAttribute.txt";
	public static String Tran_ToDto_SetXToOne = "org/distiller/mda/JavaServiceCodeTemplate/Tran_ToDto_SetXToOne.txt";
	public static String Tran_ToDtoSetXToMany = "org/distiller/mda/JavaServiceCodeTemplate/Tran_ToDtoSetXToMany.txt";
	
	public static String HTran_ToDto_SetOneAttribute = "org/distiller/mda/JavaServiceCodeTemplate/HTran_ToDto_SetOneAttribute.txt";
	public static String HTran_ToDto_Header = "org/distiller/mda/JavaServiceCodeTemplate/HTran_ToDto_Header.txt";
	public static String HTran_ToDto_End = "org/distiller/mda/JavaServiceCodeTemplate/HTran_ToDto_End.txt";
	
	public static String HTran_ToEntity_SetOneAttribute = "org/distiller/mda/JavaServiceCodeTemplate/HTran_ToEntity_SetOneAttribute.txt";
	public static String HTran_ToEntity_Header = "org/distiller/mda/JavaServiceCodeTemplate/HTran_ToEntity_Header.txt";
	public static String HTran_ToEntity_End = "org/distiller/mda/JavaServiceCodeTemplate/HTran_ToEntity_End.txt";
	
	public static String Tran_ToEntity_SetOneAttribute 	= "org/distiller/mda/JavaServiceCodeTemplate/Tran_ToEntity_SetOneAttribute.txt";
	public static String Tran_ToEntity_SetXToMany 		= "org/distiller/mda/JavaServiceCodeTemplate/Tran_ToEntity_SetXToMany.txt";
	public static String Tran_ToEntity_SetXToOne 		= "org/distiller/mda/JavaServiceCodeTemplate/Tran_ToEntity_SetXToOne.txt";
	private static String Dto_IsEntityPresentOperation 	= "org/distiller/mda/JavaServiceCodeTemplate/Dto_IsEntityPresentOperation.txt";
	private static String Dto_IsDtoPresentOperation 	= "org/distiller/mda/JavaServiceCodeTemplate/Dto_IsDtoPresentOperation.txt";


	private static String ServImpl_AddOperation        	= "org/distiller/mda/JavaServiceCodeTemplate/ServImpl_AddOperation.txt";
	private static String ServImpl_Constructor         	= "org/distiller/mda/JavaServiceCodeTemplate/ServImpl_Constructor.txt";
	private static String ServImpl_DeleteOperation     	= "org/distiller/mda/JavaServiceCodeTemplate/ServImpl_DeleteOperation.txt";
	private static String ServImpl_GetAllOperation     	= "org/distiller/mda/JavaServiceCodeTemplate/ServImpl_GetAllOperation.txt";
	private static String ServImpl_GetOperation        	= "org/distiller/mda/JavaServiceCodeTemplate/ServImpl_GetOperation.txt";
	private static String ServImpl_UpdateOperation     	= "org/distiller/mda/JavaServiceCodeTemplate/ServImpl_UpdateOperation.txt";

	public static String getServImpl_AddOperation(Class headerDto, Class dto, Interface iRepository, Class jEntity) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(ServImpl_AddOperation);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String result = tmpl.toString();
		result = result.replace("@@headerDto", headerDto.getName());
		result = result.replace("@@dto", dto.getName());
		result = result.replace("@@iRepository", iRepository.getName());
		result = result.replace("@@jEntity", jEntity.getName());
		//result = result.replace("@@", .getName());
		return result;
	}
	public static String getServImpl_Constructor(Class jAggregate) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(ServImpl_Constructor);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String result = tmpl.toString();
		result = result.replaceAll("@@jAggregate", jAggregate.getName());
		return result;
	}
	public static String getServImpl_DeleteOperation(Class headerDto, Class dto, Interface iRepository, Class jEntity) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(ServImpl_DeleteOperation);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String result = tmpl.toString();
		result = result.replace("@@headerDto", headerDto.getName());
		result = result.replace("@@dto", dto.getName());
		result = result.replace("@@iRepository", iRepository.getName());
		result = result.replace("@@jEntity", jEntity.getName());
		return result;
	}
	public static String getServImpl_GetAllOperation(Class headerDto, Class dto, Interface iRepository, Class jEntity) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(ServImpl_GetAllOperation);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String result = tmpl.toString();
		result = result.replace("@@headerDto", headerDto.getName());
		result = result.replace("@@dto", dto.getName());
		result = result.replace("@@iRepository", iRepository.getName());
		result = result.replace("@@jEntity", jEntity.getName());
		return result;
	}
	public static String getServImpl_GetOperation(Class headerDto, Class dto, Interface iRepository, Class jEntity) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(ServImpl_GetOperation);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String result = tmpl.toString();
		result = result.replace("@@headerDto", headerDto.getName());
		result = result.replace("@@dto", dto.getName());
		result = result.replace("@@iRepository", iRepository.getName());
		result = result.replace("@@jEntity", jEntity.getName());
		return result;
	}
	public static String getServImpl_UpdateOperation(Class headerDto, Class dto, Interface iRepository, Class jEntity) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(ServImpl_UpdateOperation);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		String result = tmpl.toString();
		result = result.replace("@@headerDto", headerDto.getName());
		result = result.replace("@@dto", dto.getName());
		result = result.replace("@@iRepository", iRepository.getName());
		result = result.replace("@@jEntity", jEntity.getName());
		return result;
	}


	public static String GetTran_ToEntity_SetOneAttribute(Attribute attr) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(Tran_ToEntity_SetOneAttribute);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String sAttributeName = ToUpperFirst(attr.getName());
		String result = tmpl.toString().replace("@@Attribute", sAttributeName);
		return result;
	}
	public static String GetTran_ToEntity_SetXToOne(AssociationEnd end) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(Tran_ToEntity_SetXToOne);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String targetClass = end.getTarget().getName();
		String role = end.getName();
		String Role = ToUpperFirst(role);
		String result = tmpl.toString().replace("@@targetClass", targetClass);
		result = result.replace("@@role", role);
		result = result.replace("@@Role", Role);
		return result;
	}

	public static String GetTran_ToEntity_SetXToMany(AssociationEnd end, Class pimAggregate, Class pimEntity) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(Tran_ToEntity_SetXToMany);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		Class targetDto = ServiceObjFinder.FindDtoFromJEntity(pimAggregate, (Class)end.getTarget());

		String targetJEntityClass = end.getTarget().getName();
		String Role = ToUpperFirst(end.getName());
		String result = tmpl.toString().replace("@@targetJEntityClass", targetJEntityClass);
		result = result.replace("@@Role", Role);
		result = result.replace("@@targetDtoClass", targetDto.getName());
		return result;
	}



	public static String GetDto_FindEntityFromDtoOperation(Class jEntity) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(Dto_FindEntityFromDtoOperation);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		String result = tmpl.toString().replace("@@JEntityClass", jEntity.getName());
		return result;
	}

	public static String GetTran_ToDto_SetOneAttribute(Attribute attrDto) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(Tran_ToDto_SetOneAttribute);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		String sAttributeName = ToUpperFirst(attrDto.getName());
		String result = tmpl.toString().replace("@@Attribute", sAttributeName);
		return result;
	}
	public static String GetTran_ToDto_SetXToOne(AssociationEnd endDto) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(Tran_ToDto_SetXToOne);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String result = ReplaceEndDtoTokens(endDto, tmpl);
		return result;
	}

	public static String GetTran_ToDtoSetXToMany(AssociationEnd endDto, Class pimAggregate) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(Tran_ToDtoSetXToMany);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		String result = ReplaceEndDtoTokens(endDto, tmpl);
		return result;
	}

	public static String GetDto_IsEntityPresentOperation(Class javaDto, Class jEntity) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(Dto_IsEntityPresentOperation);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String result = tmpl.toString();
		result = result.replaceAll("@@jEntity", jEntity.getName());
		result = result.replaceAll("@@javaDto", javaDto.getName());
		return result;
	}
	public static String GetDto_IsDtoPresentOperation(Class javaDto, Class jEntity) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(Dto_IsDtoPresentOperation);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String result = tmpl.toString();
		result = result.replaceAll("@@jEntity", jEntity.getName());
		result = result.replaceAll("@@javaDto", javaDto.getName());
		return result;
	}
	
	public static String getHTran_ToDto_SetOneAttribute(Attribute attr) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(HTran_ToDto_SetOneAttribute);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String sAttributeName = ToUpperFirst(attr.getName());
		String result = tmpl.toString().replace("@@Attribute", sAttributeName);
		return result;
	}
	public static String getHTran_ToDto_Header(Class dtoHeader, Class jEntity) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(HTran_ToDto_Header);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String result = tmpl.toString();
		result = result.replaceAll("@@dtoHeader", dtoHeader.getName());
		result = result.replaceAll("@@jEntity", jEntity.getName());
		return result;
	}
	public static String getHTran_ToDto_End() {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(HTran_ToDto_End);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String result = tmpl.toString();
		return result;
	}
	public static String getHTran_ToEntity_SetOneAttribute(Attribute attr) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(HTran_ToEntity_SetOneAttribute);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String sAttributeName = ToUpperFirst(attr.getName());
		String result = tmpl.toString().replace("@@Attribute", sAttributeName);
		return result;
	}
	public static String getHTran_ToEntity_Header(Class dtoHeader, Class jEntity) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(HTran_ToEntity_Header);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String result = tmpl.toString();
		result = result.replaceAll("@@dtoHeader", dtoHeader.getName());
		result = result.replaceAll("@@jEntity", jEntity.getName());
		return result;
	}
	public static String getHTran_ToEntity_End() {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(HTran_ToEntity_End);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}


		String result = tmpl.toString();
		return result;
	}

	

	private static String ReplaceEndDtoTokens(AssociationEnd endDto, StringBuilder tmpl) {
		Class targetDto = (Class)endDto.getTarget();
		Class targetJEntity = ServiceObjFinder.FindJEntityFromDto(targetDto);
		String result = tmpl.toString().replace("@@targetJEntity", targetJEntity.getName());
		result = result.replace("@@role", endDto.getName());
		result = result.replace("@@Role", ToUpperFirst(endDto.getName()));
		result = result.replace("@@targetDto", targetDto.getName());
		return result;
	}



	private static String ToUpperFirst(String str) {
		String firstLetter = str.substring(0, 1);
		String firstLetterUpperCase = firstLetter.toUpperCase();

		return str.replaceFirst(firstLetter, firstLetterUpperCase);
	}

}


