package org.distiller.mda.features.service;

import java.util.List;

import org.distiller.mda.features.datadomain.DataDomainObjFinder;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.distiller.mda.metamodelhelper.ServiceConst;
import org.levore.modeliotools.metamodelhelper.JavaConstants;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.ITransaction;
import org.modelio.api.modelio.model.IUmlModel;
import org.modelio.api.module.IModule;
import org.modelio.api.module.command.DefaultModuleCommandHandler;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.Package;
import org.modelio.vcore.smkernel.mapi.MObject;

public class CreateServiceCommand extends DefaultModuleCommandHandler {


	/**
	 * Constructor.
	 */
	public CreateServiceCommand() {
		super();
	}

	/**
	 * @see org.modelio.api.module.commands.DefaultModuleContextualCommand#accept(java.util.List,
	 *      org.modelio.api.module.IModule)
	 */
	@Override
	public boolean accept(List<MObject> selectedElements, IModule module) {
		boolean result = false;
		if (selectedElements.size() == 1 && selectedElements.get(0) instanceof Class) {
			Class selectedElement = (Class)selectedElements.get(0);
			result = selectedElement.isStereotyped(DistillerConst.EntitySt());
		}
		return result;
	}

	/**
	 * @see org.modelio.api.module.commands.DefaultModuleContextualCommand#actionPerformed(java.util.List,
	 *      org.modelio.api.module.IModule)
	 */
	@Override
	public void actionPerformed(List<MObject> selectedElements, IModule module) {
		Class pimAggregate = (Class)selectedElements.get(0);
		
//		Stereotype eventDependencySt = DistillerConst.DependencySt();
//		Stereotype deeperTransformerSt = JavaServiceConst.getDeeperTransformerSt();
//		TagType javaImportsType = JavaConstants.GetJavaImportClassType(module);

		Component domainData = DistillerConst.DataDomain(pimAggregate);
		String serviceDtoName = ServicePrototypeName.getDtoPackName(pimAggregate, domainData);
		String serviceInterfaceName = ServicePrototypeName.getServiceInterfacePackName(pimAggregate, domainData);
		String serviceTransformerName = ServicePrototypeName.getTransformerName(pimAggregate, domainData);

		//Structure
		DelegateService delegateService = new DelegateService();
		delegateService.delegateCreateDtoPack(serviceDtoName, pimAggregate);
		Package serviceInterfacePack = delegateService.delegateCreateInterfacePack(serviceInterfaceName, pimAggregate);
		Package serviceTransformerPack = delegateService.delegateCreateTransformerPack(serviceTransformerName, pimAggregate);

		DelegateDtos delegateDtos = new DelegateDtos();
		delegateDtos.createDtos(pimAggregate);

		//IEntityService
		DelegateServiceInterfaz delegateCreateInterface = new DelegateServiceInterfaz();
		delegateCreateInterface.actionPerformed(pimAggregate, serviceInterfacePack, module);

		//Transformers
		DelegateTransformer transformer = new DelegateTransformer();
		transformer.createTransformer(pimAggregate, serviceTransformerPack);
		DelegateHeaderTransformer hTransformer = new DelegateHeaderTransformer();
		hTransformer.createTransformer(pimAggregate, serviceTransformerPack);

		//create ServiceImpl
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		try(ITransaction t = session.createTransaction("CreateConf")) {
			Component dataDomain = DataDomainObjFinder.FindDataDomain(pimAggregate);
			Component ServiceImplPrj = DataDomainObjFinder.FindServiceImplPrj(dataDomain);
			Package serviceImplPack = ServiceObjFinder.FindServiceImplPack(dataDomain);
			if (serviceImplPack  == null) {
				String name = ServicePrototypeName.getServiceImplPackName(dataDomain);
				serviceImplPack = model.createPackage(name, ServiceImplPrj,JavaConstants.GetJavaPackageStereotype(module));
				model.createDependency(serviceImplPack, dataDomain, DistillerConst.DependencySt());
				serviceImplPack.getExtension().add( ServiceConst.ServiceImplPackSt());
			}
			
			DelegateServiceImpl delegateServiceImpl = new DelegateServiceImpl(pimAggregate);
			delegateServiceImpl.createServiceImpl();
			
			t.commit();
		}
		
	}



}
