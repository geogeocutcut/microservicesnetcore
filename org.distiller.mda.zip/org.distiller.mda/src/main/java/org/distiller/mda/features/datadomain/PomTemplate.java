package org.distiller.mda.features.datadomain;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

import org.distiller.mda.features.javamodel.JavaModelObjFinder;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.Interface;
import org.modelio.metamodel.uml.statik.Package;

public class PomTemplate {

	public String structure_pom = "org/distiller/mda/PomTemplate/structure_pom.xml";
	public String repository_ioc = "org/distiller/mda/PomTemplate/repository_ioc.xml";
	public String repositoryimpl_pom = "org/distiller/mda/PomTemplate/repositoryimpl_pom.xml";
	
	public String serv_ioc_header = "org/distiller/mda/PomTemplate/serv_ioc_header.xml";
	public String serv_ioc_services = "org/distiller/mda/PomTemplate/serv_ioc_services.xml";
	public String serv_ioc_end = "org/distiller/mda/PomTemplate/serv_ioc_end.xml";
	
	public String serv_pom = "org/distiller/mda/PomTemplate/serv_pom.xml";
	
	private Component dataDomain;
	
	
	public PomTemplate(Component dataDomain) {
		this.dataDomain = dataDomain;
	}
	
	public String Getstructure_pom() {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = PomTemplate.class.getClassLoader().getResourceAsStream(structure_pom);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String result = tmpl.toString().replace("@@datadomain", dataDomain.getName().toLowerCase());
		return result;
	}
	
	public String GetService_pom() {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = PomTemplate.class.getClassLoader().getResourceAsStream(serv_pom);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String result = tmpl.toString().replace("@@dataDomain", dataDomain.getName().toLowerCase());
		return result;
	}
	
	public String Getrepository_ioc() {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = PomTemplate.class.getClassLoader().getResourceAsStream(repository_ioc);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Package reposImplPack = JavaModelObjFinder.FindRepositoryPack(dataDomain);
		Class repositoryBuilder = JavaModelObjFinder.FindRepositoryBuilder(dataDomain);
		
		String result = tmpl.toString();
		result = result.replace("@@repositoryImplPack", reposImplPack.getName());
		result = result.replace("@@repositoryBuilder", repositoryBuilder.getName());
		return result;
	}

	public String getRepositoryimpl_pom() {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = PomTemplate.class.getClassLoader().getResourceAsStream(repositoryimpl_pom);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		
		String result = tmpl.toString();
		result = result.replace("@@dataDomain", dataDomain.getName().toLowerCase());
		return result;
	}
	

	public String getServ_ioc_header() {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = PomTemplate.class.getClassLoader().getResourceAsStream(serv_ioc_header);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String result = tmpl.toString().replace("@@dataDomain", dataDomain.getName());
		return result;
	}

	public String getServ_ioc_services(String serviceImplJavaPack, Interface iService, Class serviceImpl) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = PomTemplate.class.getClassLoader().getResourceAsStream(serv_ioc_services);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String result = tmpl.toString().replace("@@serviceImplJavaPack", serviceImplJavaPack);
		result = result.replace("@@serviceImpl", serviceImpl.getName());
		result = result.replace("@@iService", iService.getName());
		return result;
	}

	public String getServ_ioc_end() {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = PomTemplate.class.getClassLoader().getResourceAsStream(serv_ioc_end);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		String result = tmpl.toString();
		return result;
	}

}


