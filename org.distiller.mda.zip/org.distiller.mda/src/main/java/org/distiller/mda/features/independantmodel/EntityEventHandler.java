package org.distiller.mda.features.independantmodel;

import java.util.ArrayList;
import java.util.List;

import org.distiller.mda.features.javamodel.JavaModelProtoName;
import org.distiller.mda.features.service.ServicePrototypeName;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.distiller.mda.metamodelhelper.JavaModelConst;
import org.distiller.mda.metamodelhelper.ServiceConst;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.infrastructure.Dependency;
import org.modelio.metamodel.uml.infrastructure.ModelElement;
import org.modelio.metamodel.uml.infrastructure.ModelTree;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.Interface;
import org.modelio.metamodel.uml.statik.Package;

public class EntityEventHandler {
	
	
	
	@SuppressWarnings("unused")
	private IModule module;
	private Class pimEntity;
	private Class javaEntity;
	private Interface javaIRepository;
	private List<Class> dtos;
	private List<Package> serviceDtoPacks;
	private List<Package> serviceInterfacePacks;
	private List<Package> serviceTransformerPacks;
	private Interface iEntityService;
	private Class EntityNotFoundException;
	private Class InvalidEntityException;


	public EntityEventHandler(Class pimEntity, IModule module) {
		this.module = module;
		this.pimEntity = pimEntity;
		initializeVars();
	}
	
	public  void Changed() {
		
		if(javaEntity != null) {
			//Change model package name
			String javaEntityName = pimEntity.getName();
			javaEntity.setName(javaEntityName);
		}
		
		if(javaIRepository != null) {
			String javaIRepositoryName = JavaModelProtoName.getiRepositoryProtoName(pimEntity);
			javaIRepository.setName(javaIRepositoryName);
		}
		
		for (Class dto : dtos) {
			String dtoName = ServicePrototypeName.getDtoName(pimEntity);
			if(dto.isStereotyped(ServiceConst.DtoHeaderSt()))
				dto.setName("Header" + dtoName);
			else
				dto.setName(dtoName);
		}
		Component dataDomain = DistillerConst.DataDomain((ModelTree)pimEntity);
		for (Package pack : serviceDtoPacks) {
			String packName = ServicePrototypeName.getDtoPackName(pimEntity, dataDomain);
			pack.setName(packName);
		}
		for (Package pack : serviceInterfacePacks) {
			String packName = ServicePrototypeName.getServiceInterfacePackName(pimEntity, dataDomain);
			pack.setName(packName);
		}
		for (Package pack : serviceTransformerPacks) {
			String packName = ServicePrototypeName.getTransformerName(pimEntity, dataDomain);
			pack.setName(packName);
		}
		
		if(iEntityService != null) {
			String name = ServicePrototypeName.getIServiceName(pimEntity);
			iEntityService.setName(name);
		}
		if(EntityNotFoundException != null) {
			String name = ServicePrototypeName.getEntityNotFoundExceptionName(pimEntity);
			EntityNotFoundException.setName(name);
		}
		if(InvalidEntityException != null) {
			String name = ServicePrototypeName.getinvalidEntitydExceptionName(pimEntity);
			InvalidEntityException.setName(name);
		}
	}
	
	
	

	private  void initializeVars() {
		dtos = new ArrayList<>();
		serviceDtoPacks = new ArrayList<Package>();
		serviceInterfacePacks = new ArrayList<Package>();
		serviceTransformerPacks = new ArrayList<Package>();
		for (Dependency dep : pimEntity.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Class && impacted.isStereotyped(JavaModelConst.JavaEntitySt())) {
				this.javaEntity = (Class)impacted;
			}
			
			if (impacted instanceof Interface && impacted.isStereotyped(JavaModelConst.IRepositorySt())) {
				this.javaIRepository = (Interface)impacted;
			}
			
			if (impacted instanceof Class && impacted.isStereotyped(ServiceConst.DtoSt())) {
				dtos.add((Class)impacted);
			}
			if (impacted instanceof Package && impacted.isStereotyped(ServiceConst.ServiceDTOPackageSt())) {
				serviceDtoPacks.add((Package)impacted);
			}
			if (impacted instanceof Package && impacted.isStereotyped(ServiceConst.ServiceInterfacePackageSt())) {
				serviceInterfacePacks.add((Package)impacted);
			}
			if (impacted instanceof Package && impacted.isStereotyped(ServiceConst.ServiceTransformerPackageSt())) {
				serviceTransformerPacks.add((Package)impacted);
			}
			
			
			if (impacted instanceof Class && impacted.isStereotyped(ServiceConst.EntityNotFoundExceptionSt())){
				this.EntityNotFoundException = (Class)impacted;
			}
			
			if (impacted instanceof Class && impacted.isStereotyped(ServiceConst.InvalidEntityExceptionSt())) {
				this.InvalidEntityException = (Class)impacted;
			}
			
			if (impacted instanceof Interface && impacted.isStereotyped(ServiceConst.IEntityServiceSt())) {
				this.iEntityService = (Interface)impacted;
			}
			
		}
	}
	
}
