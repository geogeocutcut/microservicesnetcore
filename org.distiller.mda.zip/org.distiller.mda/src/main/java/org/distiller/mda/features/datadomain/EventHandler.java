package org.distiller.mda.features.datadomain;

import java.util.ArrayList;
import java.util.List;

import org.distiller.mda.features.service.ServiceObjFinder;
import org.distiller.mda.features.service.ServicePrototypeName;
import org.distiller.mda.impl.DistillerMdaModule;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.distiller.mda.metamodelhelper.JavaModelConst;
import org.distiller.mda.metamodelhelper.ServiceConst;
import org.levore.modeliotools.metamodelhelper.JavaConstants;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.infrastructure.Dependency;
import org.modelio.metamodel.uml.infrastructure.ModelElement;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.Package;

public class EventHandler {

	private Component dataDomain;
	private  Package javaModel;
	private  Package iRepsositoryPackage;
	private Component structure;
	private List<Package> serviceDtoPacks;
	private ArrayList<Package> serviceInterfacePacks;
	private ArrayList<Package> serviceTransformerPacks;
	private Package repositoryImplPackage;
	private Component repositoryImpl;
	private Package serviceImplPack;
	private Component serviceImplPrj;

	public EventHandler(Component dataDomain) {
		this.dataDomain = dataDomain;
		initializeVars(dataDomain);
	}

	public  void Changed() {
		IModule module = DistillerMdaModule.getInstance();
		if(javaModel!=null) {
			String packageModelName = String.format(DataDomainPrototypeName.ModelPackageName, dataDomain.getName()).toLowerCase();
			javaModel.setName(packageModelName);
		}

		if(iRepsositoryPackage != null) {
			iRepsositoryPackage.setName(DataDomainPrototypeName.getIRepositoryPackageName(dataDomain));
		}
		if(structure != null) {
			String name = DataDomainPrototypeName.getStructureProjectName(dataDomain);
			structure.setName(name);
		}
		for (Package pack : serviceDtoPacks) {
			Class pimEntity = ServiceObjFinder.FindPimEntityFromImpactedPack(pack);
			String packName = ServicePrototypeName.getDtoPackName(pimEntity, dataDomain);
			pack.setName(packName);
		}
		for (Package pack : serviceInterfacePacks) {
			Class pimEntity = ServiceObjFinder.FindPimEntityFromImpactedPack(pack);
			String packName = ServicePrototypeName.getServiceInterfacePackName(pimEntity, dataDomain);
			pack.setName(packName);
		}
		for (Package pack : serviceTransformerPacks) {
			Class pimEntity = ServiceObjFinder.FindPimEntityFromImpactedPack(pack);
			String packName = ServicePrototypeName.getTransformerName(pimEntity, dataDomain);
			pack.setName(packName);
		}
		if (repositoryImpl != null) {
			repositoryImpl.setName(DataDomainPrototypeName.getRepositoryName(dataDomain));
			TagType generatePathType = JavaConstants.GetJavaComponentGenerationPath(module);
			repositoryImpl.putTagValue(generatePathType, DataDomainPrototypeName.getRepositoryImplPath(dataDomain));
		}
		if(repositoryImplPackage != null) {
			repositoryImplPackage.setName(DataDomainPrototypeName.getRepositoryImplPackageName(dataDomain));
		}
		if(serviceImplPrj != null) {
			serviceImplPrj.setName(DataDomainPrototypeName.getServiceImplPrjName(dataDomain));;
		}
		if(serviceImplPack != null) {
			serviceImplPack.setName(ServicePrototypeName.getServiceImplPackName(dataDomain));;
		}
		

	}


	

	private  void initializeVars(Component dataDomain) {
		serviceDtoPacks = new ArrayList<Package>();
		serviceInterfacePacks = new ArrayList<Package>();
		serviceTransformerPacks = new ArrayList<Package>();
		for (Dependency dep : dataDomain.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();
			if (impacted instanceof Package && impacted.isStereotyped(JavaModelConst.JavaEntityPackSt())) {
				this.javaModel = (Package)impacted;
			}

			if (impacted instanceof Package && impacted.isStereotyped(JavaModelConst.IRepositoryPackageSt())) {
				this.iRepsositoryPackage = (Package)impacted;
			}

			if (impacted instanceof Component && impacted.isStereotyped(DistillerConst.DataStructureSt())) {
				this.structure = (Component)impacted;
			}
			
			if (impacted instanceof Package && impacted.isStereotyped(ServiceConst.ServiceDTOPackageSt())) {
				serviceDtoPacks.add((Package)impacted);
			}
			if (impacted instanceof Package && impacted.isStereotyped(ServiceConst.ServiceInterfacePackageSt())) {
				serviceInterfacePacks.add((Package)impacted);
			}
			if (impacted instanceof Package && impacted.isStereotyped(ServiceConst.ServiceTransformerPackageSt())) {
				serviceTransformerPacks.add((Package)impacted);
			}
			if (impacted instanceof Component && impacted.isStereotyped(JavaModelConst.RepositoryImplPrjSt())) {
				this.repositoryImpl = (Component)impacted;
			}
			if (impacted instanceof Package && impacted.isStereotyped(JavaModelConst.RepositoryImplPackageSt())) {
				this.repositoryImplPackage = (Package)impacted;
			}
			if (impacted instanceof Component && impacted.isStereotyped(ServiceConst.ServiceImplPrjSt())) {
				this.serviceImplPrj = (Component)impacted;
			}
			if (impacted instanceof Package && impacted.isStereotyped(ServiceConst.ServiceImplPackSt())) {
				this.serviceImplPack = (Package)impacted;
			}
		}


	}



}
