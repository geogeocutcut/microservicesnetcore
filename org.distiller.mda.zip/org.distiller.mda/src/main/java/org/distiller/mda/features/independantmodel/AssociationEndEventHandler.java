package org.distiller.mda.features.independantmodel;

import java.util.ArrayList;
import java.util.List;

import org.distiller.mda.metamodelhelper.JavaModelConst;
import org.distiller.mda.metamodelhelper.ServiceConst;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.infrastructure.Dependency;
import org.modelio.metamodel.uml.infrastructure.ModelElement;
import org.modelio.metamodel.uml.statik.AssociationEnd;
import org.modelio.metamodel.uml.statik.VisibilityMode;

public class AssociationEndEventHandler {

	private IModule module;
	private AssociationEnd pimEnd;
	private AssociationEnd javaEnd;
	private List<AssociationEnd> dtoEnds;

	public AssociationEndEventHandler(AssociationEnd pimEnd, IModule module) {
		this.module = module;
		this.pimEnd = pimEnd;
		initializeVars();
	}

	public  void Changed() {
		if(javaEnd != null) {
			String javaEndName = pimEnd.getName();
			javaEnd.setName(javaEndName);
			javaEnd.setVisibility(VisibilityMode.PUBLIC);
			javaEnd.setMultiplicityMax(pimEnd.getMultiplicityMax());
			javaEnd.getOpposite().setMultiplicityMax(pimEnd.getOpposite().getMultiplicityMax());
			javaEnd.setAggregation(pimEnd.getAggregation());
		}
		for (AssociationEnd end : dtoEnds) {
			String javaEndName = pimEnd.getName();
			end.setName(javaEndName);
			end.setVisibility(VisibilityMode.PUBLIC);
			end.setMultiplicityMax(pimEnd.getMultiplicityMax());
			end.getOpposite().setMultiplicityMax(pimEnd.getOpposite().getMultiplicityMax());
			end.setAggregation(pimEnd.getAggregation());
		}
	}


	private  void initializeVars() {
		dtoEnds = new ArrayList<AssociationEnd>();
		for (Dependency dep : pimEnd.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof AssociationEnd && impacted.isStereotyped(JavaModelConst.JavaAssociationEndSt(module))) {
				this.javaEnd = (AssociationEnd)impacted;
			}
			if (impacted instanceof AssociationEnd && impacted.isStereotyped(ServiceConst.DtoAssociationEndSt(module))) {
				dtoEnds.add((AssociationEnd)impacted);
			}
		}

	}
}
