package org.distiller.mda.features.datadomain;

import java.util.List;

import org.distiller.mda.metamodelhelper.DistillerConst;
import org.levore.modeliotools.metamodelhelper.JavaConstants;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.ITransaction;
import org.modelio.api.module.IModule;
import org.modelio.api.module.command.DefaultModuleCommandHandler;
import org.modelio.api.module.context.log.ILogService;
import org.modelio.metamodel.uml.infrastructure.Dependency;
import org.modelio.metamodel.uml.infrastructure.ModelElement;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.vcore.smkernel.mapi.MObject;

/**
 * Implementation of the IModuleContextualCommand interface.
 * <br>The module contextual commands are displayed in the contextual menu and in the specific toolbar of each module property page.
 * <br>The developer may inherit the DefaultModuleContextualCommand class which contains a default standard contextual command implementation.
 *
 */
public class UpdateGeneratePathCommand extends DefaultModuleCommandHandler {


	/**
	 * Constructor.
	 */
	public UpdateGeneratePathCommand() {
		super();
	}

	/**
	 * @see org.modelio.api.module.commands.DefaultModuleContextualCommand#accept(java.util.List,
	 *      org.modelio.api.module.IModule)
	 */
	@Override
	public boolean accept(List<MObject> selectedElements, IModule module) {
		boolean result = false;
		if (selectedElements.size() == 1 && selectedElements.get(0) instanceof Component) {
			Component selectedElement = (Component)selectedElements.get(0);
			result = selectedElement.isStereotyped(DistillerConst._ModuleName,  DistillerConst._DataDomainSt);
		}
		return result;
	}

	/**
	 * @see org.modelio.api.module.commands.DefaultModuleContextualCommand#actionPerformed(java.util.List,
	 *      org.modelio.api.module.IModule)
	 */
	@Override
	public void actionPerformed(List<MObject> selectedElements, IModule module) {
		ILogService logService = module.getModuleContext().getLogService();
		logService.info("CreateDomainMapCommand - actionPerformed(...)");

		IModelingSession session = module.getModuleContext().getModelingSession();
		//        List<MObject> root = session.getModel().getModelRoots();
		//IModuleUserConfiguration configuration = module.getModuleContext().getConfiguration();

		Component dataDomain = (Component)selectedElements.get(0);
		//MessageDialog.openInformation(null, "Hello", modelelt.getName());
		try(ITransaction t = session.createTransaction("CreateConf")){
			TagType generateDomainPathType = DistillerConst.DataDomainSt_DirectoryTag();
			TagType generateStructurePathType = JavaConstants.GetJavaComponentGenerationPath(module);
			
			for (Dependency dep : dataDomain.getImpactedDependency()) {
				ModelElement impacted = dep.getImpacted();;
				

				if (impacted instanceof Component && impacted.isStereotyped(DistillerConst._ModuleName, DistillerConst._StructureSt)) {
					Component dataDomain_Structure = (Component)impacted;
					//Change structure java project generate directory
					String dataDomainGeneratePath = dataDomain.getTagValue(generateDomainPathType);
					String structureGeneratePath = String.format(DataDomainPrototypeName.StructurePath, dataDomainGeneratePath, dataDomain.getName());
					dataDomain_Structure.putTagValue(generateStructurePathType, structureGeneratePath);
					break;
				}
				
			}

			t.commit();
		}
	}


}
