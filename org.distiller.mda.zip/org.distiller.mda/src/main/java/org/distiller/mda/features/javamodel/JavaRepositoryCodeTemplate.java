package org.distiller.mda.features.javamodel;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

import org.distiller.mda.features.service.ServiceCodeTemplate;
import org.modelio.metamodel.uml.statik.Class;

public class JavaRepositoryCodeTemplate {
	private static String create = "org/distiller/mda/JavaRepositoryCodeTemplate/create.txt";
	private static String update = "org/distiller/mda/JavaRepositoryCodeTemplate/update.txt";
	private static String delete = "org/distiller/mda/JavaRepositoryCodeTemplate/delete.txt";
	private static String get = "org/distiller/mda/JavaRepositoryCodeTemplate/get.txt";
	private static String getall = "org/distiller/mda/JavaRepositoryCodeTemplate/getall.txt";
	
	
	public static String getCreate() {
		StringBuilder tmpl = getTxt(create);
		String result = tmpl.toString();
		return result;
	}
	public static String getUpdate() {
		StringBuilder tmpl = getTxt(update);
		String result = tmpl.toString();
		return result;
	}

	public static String getDelete() {
		StringBuilder tmpl = getTxt(delete);
		String result = tmpl.toString();
		return result;
	}
	

	public static String getGet(Class jEntity) {
		StringBuilder tmpl = getTxt(get);
		String result = tmpl.toString();
		result = result.replaceAll("@@jEntity", jEntity.getName());
		return result;
	}
	public static String getGetall(Class jEntity) {
		StringBuilder tmpl = getTxt(getall);
		String result = tmpl.toString();
		result = result.replaceAll("@@jEntity", jEntity.getName());
		return result;
	}
	
	
	
	private static StringBuilder getTxt(String tokenFile) {
		StringBuilder tmpl = new StringBuilder();
		try {
			InputStream stream = ServiceCodeTemplate.class.getClassLoader().getResourceAsStream(tokenFile);
			BufferedReader  reader = new BufferedReader (new InputStreamReader(stream, Charset.forName("UTF-8")));
			while (reader.ready()) {
				tmpl.append(reader.readLine()).append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return tmpl;
	}
	
}
