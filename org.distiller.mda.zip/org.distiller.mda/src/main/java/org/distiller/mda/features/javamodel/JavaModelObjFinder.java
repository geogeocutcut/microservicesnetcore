package org.distiller.mda.features.javamodel;

import org.distiller.mda.metamodelhelper.DistillerConst;
import org.distiller.mda.metamodelhelper.JavaModelConst;
import org.modelio.metamodel.uml.infrastructure.Dependency;
import org.modelio.metamodel.uml.infrastructure.ModelElement;
import org.modelio.metamodel.uml.infrastructure.Stereotype;
import org.modelio.metamodel.uml.statik.Association;
import org.modelio.metamodel.uml.statik.AssociationEnd;
import org.modelio.metamodel.uml.statik.Attribute;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Classifier;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.Interface;
import org.modelio.metamodel.uml.statik.Package;

public class JavaModelObjFinder {
	
	public static Component FindRepositoryImplPrj(Component dataDomain) {
		Stereotype stereotype = JavaModelConst.RepositoryImplPrjSt();
		Component result = null;
		for (Dependency dep : dataDomain.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Component 
					&& impacted.isStereotyped(stereotype)) {
				result = (Component)impacted;
				break;
			}
		}
		return result;
	}
	
	public static Class FindJEntityFromPimEntity(Class pimEntity) {
		Stereotype javaEntitySt = JavaModelConst.JavaEntitySt();
		Class result = null;
		for (Dependency dep : pimEntity.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Class 
					&& impacted.isStereotyped(javaEntitySt)) {
				result = (Class)impacted;
				break;
			}
		}
		return result;
	}
	public static Attribute FindJAttributeFromPimAttribute(Attribute pimAttribute) {
		Attribute result = null;
		Stereotype javaAttributeSt = JavaModelConst.JavaAttributeSt();
		for (Dependency dep : pimAttribute.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Attribute 
					&& impacted.isStereotyped(javaAttributeSt)) {
				result = (Attribute)impacted;
				break;
			}
		}
		return result;
	}

	public static Interface FindIRepositoryFromPimEnity(Classifier pimEntity) {
		Interface result = null;
		Stereotype iRepositorySt = JavaModelConst.IRepositorySt();
		for (Dependency dep : pimEntity.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Interface 
					&& impacted.isStereotyped(iRepositorySt)) {
				result = (Interface)impacted;
				break;
			}
		}
		return result;
	}
	
	public static Association FindJAssociationFromJEntity(String associationEndName, Class javaSrc) {
		Association result = null;
		for (AssociationEnd end : javaSrc.getOwnedEnd()) {
			if(end.getName().equals(associationEndName)) {
				result = end.getAssociation();
			}
		}
		return result;
	}
	
	public static Attribute FindJIdentifier(Class javaEntity) {
		Attribute result = null;
		for (Attribute attribute : javaEntity.getOwnedAttribute()) {
			if(attribute.getName().equals("id")) {
				result = attribute;
				break;
			}
		}
		return result;
	}
	public static Class FindPimEnityFromJEnity(Class jEntity) {
		Class result = null;
		for (Dependency item : jEntity.getDependsOnDependency()) {
			ModelElement depends = item.getDependsOn();
			if(depends instanceof Class
					&& depends.isStereotyped(DistillerConst.EntitySt())) {
				result = (Class)depends;
				break;
			}
		}
		return result;
	}
	
	public static Package FindRepositoryPack(Component dataDomain) {
		Package result = null;
		for (Dependency dep : dataDomain.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Package 
					&& impacted.isStereotyped(JavaModelConst.RepositoryImplPackageSt())) {
				result = (Package)impacted;
			}

		}
		return result;
	}
	
	public static Class FindRepositoryFromPim(Classifier pimEntity) {
		Class result = null;
		for (Dependency dep : pimEntity.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Class 
					&& impacted.isStereotyped(JavaModelConst.RepositoryImplSt())) {
				result = (Class)impacted;
				break;
			}
		}
		return result;
	}
	public static Package FindIRepositoryPack(Component dataDomain) {
		Package result = null;
		for (Dependency dep : dataDomain.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Package 
					&& impacted.isStereotyped(JavaModelConst.IRepositoryPackageSt())) {
				result = (Package)impacted;
				break;
			}
		}
		return result;
	}
	public static Interface FindIRepositoryBuilderOfDataDomain(Component dataDomain) {
		Interface result = null;
		for (Dependency dep : dataDomain.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Interface 
					&& impacted.isStereotyped(JavaModelConst.IRepositoryBuilderSt())) {
				result = (Interface)impacted;
				break;
			}
		}
		return result;
	}

	public static Interface FindIRepositoryFromPim(Class pimEntity) {
		Interface result = null;
		for (Dependency dep : pimEntity.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Interface 
					&& impacted.isStereotyped(JavaModelConst.IRepositorySt())) {
				result = (Interface)impacted;
				break;
			}
		}
		return result;
	}

	public static Package FindJavaModelPack(Component dataDomain) {
		Package result = null;
		for (Dependency dep : dataDomain.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Package 
					&& impacted.isStereotyped(JavaModelConst.JavaEntityPackSt())) {
				result = (Package)impacted;
				break;
			}
		}
		return result;
	}
	
	public static Class FindRepositoryBuilder(Component dataDomain) {
		Class result = null;
		for (Dependency dep : dataDomain.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Class 
					&& impacted.isStereotyped(JavaModelConst.RepositoryBuilderSt())) {
				result = (Class)impacted;
				break;
			}
		}
		return result;
	}
	
}
