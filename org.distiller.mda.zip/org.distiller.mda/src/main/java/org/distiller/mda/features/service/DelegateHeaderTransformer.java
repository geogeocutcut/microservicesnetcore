package org.distiller.mda.features.service;

import org.distiller.mda.features.javamodel.JavaModelObjFinder;
import org.distiller.mda.impl.DistillerMdaModule;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.distiller.mda.metamodelhelper.ServiceConst;
import org.levore.modeliotools.metamodelhelper.JavaConstants;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.ITransaction;
import org.modelio.api.modelio.model.IUmlModel;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.infrastructure.NoteType;
import org.modelio.metamodel.uml.infrastructure.Stereotype;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.Attribute;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Operation;
import org.modelio.metamodel.uml.statik.Package;
import org.modelio.metamodel.uml.statik.Parameter;

public class DelegateHeaderTransformer {
	public  void createTransformer(Class pimEntity,	Package serviceTransformerPack) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		Stereotype eventDependencySt = DistillerConst.DependencySt();
		Stereotype HeaderTransformerSt = ServiceConst.HeaderTransformerSt();
		TagType javaImportsType = JavaConstants.GetJavaImportClassType(module);
		
		try(ITransaction t = session.createTransaction("CreateConf")) {
			
			Class javaEntity = JavaModelObjFinder.FindJEntityFromPimEntity(pimEntity);
			Class headerTransformer = ServiceObjFinder.FindHeaderTransformer(pimEntity);
				
			if(headerTransformer==null) {
				String headerTransformerName = ServicePrototypeName.getHeaderTransformerName(javaEntity);
				headerTransformer = model.createClass(headerTransformerName, serviceTransformerPack, HeaderTransformerSt);

				headerTransformer.putTagValue(javaImportsType, "java.util.ArrayList");
				model.createDependency(headerTransformer, pimEntity, eventDependencySt);
				
				createToDtoOperation(pimEntity);
				createToEntityOperation(pimEntity);
			}
			t.commit();
		}
	}

	private void createToDtoOperation(Class pimEntity) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		
		Class javaEntity = JavaModelObjFinder.FindJEntityFromPimEntity(pimEntity);
		Class headerTransformer = ServiceObjFinder.FindHeaderTransformer(pimEntity);
		Class javaDto = ServiceObjFinder.FindJHeaderFromPim(pimEntity);
		NoteType javaCodeNoteType = JavaConstants.GetJavaCodeType(module);
		
		Operation transformToDto = model.createOperation("transformToDto", headerTransformer);
		Parameter out = model.createParameter();
		out.setType(javaDto);
		out.setMultiplicityMax("*");
		transformToDto.setReturn(out);
		
		Parameter entityTodtoParam = model.createParameter();
		entityTodtoParam.setName("entities");
		entityTodtoParam.setType(javaEntity);
		entityTodtoParam.setMultiplicityMax("*");
		transformToDto.getIO().add(entityTodtoParam);
		
		StringBuffer toDtCodeBuffer = new StringBuffer("");
		toDtCodeBuffer.append(ServiceCodeTemplate.getHTran_ToDto_Header(javaDto, javaEntity));
		for (Attribute attributeDto : javaDto.getOwnedAttribute()) {
			toDtCodeBuffer.append(ServiceCodeTemplate.getHTran_ToDto_SetOneAttribute(attributeDto)).append("\n");
		}
		toDtCodeBuffer.append(ServiceCodeTemplate.getHTran_ToDto_End());
		model.createNote(javaCodeNoteType, transformToDto, toDtCodeBuffer.toString());
	}

	private void createToEntityOperation(Class pimEntity) {
		
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		
		Class javaEntity = JavaModelObjFinder.FindJEntityFromPimEntity(pimEntity);
		Class headerTransformer = ServiceObjFinder.FindHeaderTransformer(pimEntity);
		Class javaDto = ServiceObjFinder.FindHeaderDtoAggregateFromPim(pimEntity);
		NoteType javaCodeNoteType = JavaConstants.GetJavaCodeType(module);
		
		
		Operation transformToEntity = model.createOperation("transformToEntity", headerTransformer);
		Parameter out = model.createParameter();
		out.setType(javaEntity);
		out.setMultiplicityMax("*");
		transformToEntity.setReturn(out);
		
		Parameter dtoParam = model.createParameter();
		dtoParam.setName("dtos");
		dtoParam.setType(javaDto);
		dtoParam.setMultiplicityMax("*");
		transformToEntity.getIO().add(dtoParam);
		
//		Parameter entityParam = model.createParameter();
//		entityParam.setName("entity");
//		entityParam.setType(javaEntity);
//		transformToEntity.getIO().add(entityParam);
		
		StringBuffer codeBuffer = new StringBuffer();
		codeBuffer.append(ServiceCodeTemplate.getHTran_ToEntity_Header(javaDto, javaEntity));
		for (Attribute attribute : javaEntity.getOwnedAttribute()) {
			codeBuffer.append(ServiceCodeTemplate.getHTran_ToEntity_SetOneAttribute(attribute)).append("\n");
		}
		codeBuffer.append(ServiceCodeTemplate.getHTran_ToEntity_End());
		model.createNote(javaCodeNoteType, transformToEntity, codeBuffer.toString());
	}
	
	
	
	
}
