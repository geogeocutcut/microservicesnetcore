package org.distiller.mda.features.javamodel;

import org.distiller.mda.features.datadomain.DataDomainObjFinder;
import org.distiller.mda.impl.DistillerMdaModule;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.distiller.mda.metamodelhelper.JavaModelConst;
import org.levore.modeliotools.metamodelhelper.JavaConstants;
import org.levore.modeliotools.metamodelhelper.ModelerModuleConstants;
import org.levore.modeliotools.treevisitor.HandlerAdapter;
import org.levore.modeliotools.treevisitor.Visitor;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.ITransaction;
import org.modelio.api.modelio.model.IUmlModel;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.infrastructure.Dependency;
import org.modelio.metamodel.uml.infrastructure.ModelElement;
import org.modelio.metamodel.uml.infrastructure.NoteType;
import org.modelio.metamodel.uml.infrastructure.Stereotype;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Classifier;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.DataType;
import org.modelio.metamodel.uml.statik.Interface;
import org.modelio.metamodel.uml.statik.Operation;
import org.modelio.metamodel.uml.statik.Package;
import org.modelio.metamodel.uml.statik.Parameter;
import org.modelio.metamodel.uml.statik.VisibilityMode;

public class DelegateRepository {

	public void createIRepositories(Package independantModel) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		try(ITransaction t = session.createTransaction("CreateConf")){
			IRepositoryHandler handler = new IRepositoryHandler(independantModel, module);
			Visitor visitor = new Visitor(handler);
			visitor.process(independantModel);
			t.commit();
		}
	}
	
	public void createRepositories(Package independantModel) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		try(ITransaction t = session.createTransaction("CreateConf")){
        	RepositoryHandler handler = new RepositoryHandler(independantModel, module);
        	Visitor visitor = new Visitor(handler);
        	visitor.process(independantModel);
        	t.commit();
        }
	}

	public class IRepositoryHandler extends HandlerAdapter {



		private Package independantModel;
		private Package iRepositoryPackage;
		private IModule module;
		private IModelingSession session;
		private IUmlModel model;


		private Stereotype javaIRepositoryPackageSt;
		private Stereotype JavaDesignerInterfaceSt;
		private Stereotype iRepositorySt;
		private Stereotype eventDependencySt;
		private TagType javaImportType;

		public IRepositoryHandler(Package independantModel, IModule module) {
			this.independantModel = independantModel;
			this.module = module;
			this.session = module.getModuleContext().getModelingSession();
			model = this.session.getModel();
			this.initializeVars();
		}


		@Override
		protected void beginVisitingClassifier(Classifier pimEntity) {
			Class javaEntity = JavaModelObjFinder.FindJEntityFromPimEntity((Class)pimEntity);

			//create IRepository
			String iRepositoryName = JavaModelProtoName.getiRepositoryProtoName((Class)pimEntity);
			Interface iRepository = JavaModelObjFinder.FindIRepositoryFromPimEnity(pimEntity);
			if(iRepository==null) {
				iRepository = model.createInterface(iRepositoryName, iRepositoryPackage);
				iRepository.getExtension().add(JavaDesignerInterfaceSt);
				iRepository.getExtension().add(iRepositorySt);
				model.createDependency(iRepository, pimEntity ,eventDependencySt);
//				iRepository.putTagValue(javaImportType, "java.util.List");
				iRepository.putTagValue(javaImportType, "java.util.List");
//				model.createTagParameter("ddd.dddd", iRepository.getTag(javaImportType));

				addCreateMethod(javaEntity, iRepository);
				addUpdateMethod(javaEntity, iRepository);
				addDeleteMethod(javaEntity, iRepository);
				addGetMethod(javaEntity, iRepository);
				addGetAllMethod(javaEntity, iRepository);
			}



		}




		private  void initializeVars() {
			javaIRepositoryPackageSt = JavaModelConst.IRepositoryPackageSt();
			JavaDesignerInterfaceSt = JavaConstants.GetJavaInterfaceStereotype(module);
			iRepositorySt = JavaModelConst.IRepositorySt();
			eventDependencySt = DistillerConst.DependencySt();
			javaImportType = JavaConstants.GetJavaImportInterfaceType(module);


			for (Dependency dep : independantModel.getImpactedDependency()) {
				ModelElement impacted = dep.getImpacted();;
				if (impacted instanceof Package 
						&& impacted.isStereotyped(javaIRepositoryPackageSt)) {
					this.iRepositoryPackage = (Package)impacted;
				}

			}
		}



		private void addCreateMethod(Class javaEntity, Interface iRepository) {
			//add create method
			Operation createOperation = model.createOperation("create", iRepository);
			createOperation.setVisibility(VisibilityMode.PUBLIC);
			//Création du paramètre de retour
			Parameter outParam = model.createParameter();
			outParam.setType(javaEntity);
			createOperation.setReturn(outParam);
			createOperation.getReturn().setMultiplicityMax("1");

			//Création des paramètres d'entrée
			Parameter dataParam = model.createParameter();
			dataParam.setName("entity");
			dataParam.setType(javaEntity);
			createOperation.getIO().add(dataParam);

		}

		private void addUpdateMethod(Class javaEntity, Interface iRepository) {
			//add create method
			Operation createOperation = model.createOperation("update", iRepository);
			createOperation.setVisibility(VisibilityMode.PUBLIC);
			//Création du paramètre de retour
			Parameter outParam = model.createParameter();
			outParam.setType(javaEntity);
			createOperation.setReturn(outParam);
			createOperation.getReturn().setMultiplicityMax("1");

			//Création des paramètres d'entrée
			Parameter dataParam = model.createParameter();
			dataParam.setName("entity");
			dataParam.setType(javaEntity);
			createOperation.getIO().add(dataParam);



		}

		private void addDeleteMethod(Class javaEntity, Interface iRepository) {
			Operation createOperation = model.createOperation("delete", iRepository);
			createOperation.setVisibility(VisibilityMode.PUBLIC);

			//Création des paramètres d'entrée
			Parameter dataParam = model.createParameter();
			dataParam.setName("id");
			dataParam.setType(model.getUmlTypes().getSTRING());
			createOperation.getIO().add(dataParam);

		}

		private void addGetMethod(Class javaEntity, Interface iRepository) {
			Operation createOperation = model.createOperation("get", iRepository);
			createOperation.setVisibility(VisibilityMode.PUBLIC);

			//Création du paramètre de retour
			Parameter outParam = model.createParameter();
			outParam.setType(javaEntity);
			createOperation.setReturn(outParam);
			createOperation.getReturn().setMultiplicityMax("1");


			//Création des paramètres d'entrée
			Parameter dataParam = model.createParameter();
			dataParam.setName("id");
			dataParam.setType(model.getUmlTypes().getSTRING());
			createOperation.getIO().add(dataParam);

		}

		private void addGetAllMethod(Class javaEntity, Interface iRepository) {
			Operation createOperation = model.createOperation("getAll", iRepository);
			createOperation.setVisibility(VisibilityMode.PUBLIC);

			//Création du paramètre de retour
			Parameter outParam = model.createParameter();
			outParam.setType(javaEntity);
			createOperation.setReturn(outParam);
			createOperation.getReturn().setMultiplicityMax("*");


			//Création des paramètres d'entrée
			Parameter pageNumber = model.createParameter();
			pageNumber.setName("pageNumber");
			pageNumber.setType(model.getUmlTypes().getINTEGER());
			createOperation.getIO().add(pageNumber);
			Parameter pageSize = model.createParameter();
			pageSize.setName("pageSize");
			pageSize.setType(model.getUmlTypes().getINTEGER());
			createOperation.getIO().add(pageSize);
			

		}

	}

	public class RepositoryHandler extends HandlerAdapter {

		

		@SuppressWarnings("unused")
		private Package independantModel;
		private Component dataDomain;
		private DataType hibernateSession;
		private Package repositoryPackage;
		private IModule module;
		private IModelingSession session;
		private IUmlModel model;


		private Stereotype JavaClassInterfaceSt;
		private Stereotype repositorySt;
		private Stereotype eventDependencySt;
		private TagType javaImportType;

		public RepositoryHandler(Package independantModel, IModule module) {
			this.independantModel = independantModel;
			this.dataDomain = DataDomainObjFinder.FindDataDomain(independantModel);
			this.hibernateSession = DataDomainObjFinder.FindHibernateSession(dataDomain);
			this.module = module;
			this.session = module.getModuleContext().getModelingSession();
			model = this.session.getModel();
			this.initializeVars();
		}


		@Override
		protected void beginVisitingClassifier(Classifier pimEntity) {
			Class javaEntity = JavaModelObjFinder.FindJEntityFromPimEntity((Class)pimEntity);
			
			

			//create IRepository
			String repositoryName = JavaModelProtoName.getRepositoryName((Class)pimEntity);
			Class repository = JavaModelObjFinder.FindRepositoryFromPim(pimEntity);
			Interface iRepository = JavaModelObjFinder.FindIRepositoryFromPim((Class)pimEntity) ;
			if(repository==null) {
				repository = model.createClass(repositoryName, repositoryPackage);
				repository.getExtension().add(JavaClassInterfaceSt);
				repository.getExtension().add(repositorySt);
				model.createDependency(repository, pimEntity ,eventDependencySt);
				repository.putTagValue(javaImportType, "java.util.List");
				model.createTagParameter("java.util.ArrayList", repository.getTag(javaImportType));
				model.createTagParameter("org.hibernate.Session", repository.getTag(javaImportType));
				model.createTagParameter("org.hibernate.query.Query", repository.getTag(javaImportType));
				
				model.createInterfaceRealization(repository, iRepository);
				
				model.createAttribute("session", hibernateSession, repository);
				
				addConstructor(repository);
				addCreateMethod(javaEntity, repository);
				addUpdateMethod(javaEntity, repository);
				addDeleteMethod(javaEntity, repository);
				addGetMethod(javaEntity, repository);
				addGetAllMethod(javaEntity, repository);
			}



		}




		private void addConstructor(Class repository) {
			Stereotype constructorSt = ModelerModuleConstants.GetConstructorSt(module);
			NoteType javaCodeNoteType = JavaConstants.GetJavaCodeType(module);
			Operation create = model.createOperation("create", repository, constructorSt);
			//Création des paramètres d'entrée
			Parameter dataParam = model.createParameter();
			dataParam.setName("session");
			dataParam.setType(hibernateSession);
			create.getIO().add(dataParam);
			model.createNote(javaCodeNoteType, create, "\t\tthis.session = session;");
			
		}


		private  void initializeVars() {
			JavaClassInterfaceSt = JavaConstants.GetJavaClassStereotype(module);
			repositorySt = JavaModelConst.RepositoryImplSt();
			eventDependencySt = DistillerConst.DependencySt();
			javaImportType = JavaConstants.GetJavaImportClassType(module);
			
			this.repositoryPackage = JavaModelObjFinder.FindRepositoryPack(dataDomain);


		}
		

		
		private void addCreateMethod(Class javaEntity, Class repository) {
			//add create method
			Operation createOperation = model.createOperation("create", repository);
			createOperation.setVisibility(VisibilityMode.PUBLIC);
			//Création du paramètre de retour
			Parameter outParam = model.createParameter();
			outParam.setType(javaEntity);
			createOperation.setReturn(outParam);
			createOperation.getReturn().setMultiplicityMax("1");

			//Création des paramètres d'entrée
			Parameter dataParam = model.createParameter();
			dataParam.setName("entity");
			dataParam.setType(javaEntity);
			createOperation.getIO().add(dataParam);
			
			NoteType javaNoteType = JavaConstants.GetJavaCodeType(module);
			createOperation.putNoteContent(javaNoteType, JavaRepositoryCodeTemplate.getCreate());
			
			

		}

		private void addUpdateMethod(Class javaEntity, Class repository) {
			//add create method
			Operation createOperation = model.createOperation("update", repository);
			createOperation.setVisibility(VisibilityMode.PUBLIC);
			//Création du paramètre de retour
			Parameter outParam = model.createParameter();
			outParam.setType(javaEntity);
			createOperation.setReturn(outParam);
			createOperation.getReturn().setMultiplicityMax("1");

			//Création des paramètres d'entrée
			Parameter dataParam = model.createParameter();
			dataParam.setName("entity");
			dataParam.setType(javaEntity);
			createOperation.getIO().add(dataParam);

			NoteType javaNoteType = JavaConstants.GetJavaCodeType(module);
			createOperation.putNoteContent(javaNoteType, JavaRepositoryCodeTemplate.getUpdate());

		}

		private void addDeleteMethod(Class javaEntity, Class repository) {
			Operation createOperation = model.createOperation("delete", repository);
			createOperation.setVisibility(VisibilityMode.PUBLIC);

			//Création des paramètres d'entrée
			Parameter dataParam = model.createParameter();
			dataParam.setName("id");
			dataParam.setType(model.getUmlTypes().getSTRING());
			createOperation.getIO().add(dataParam);
			
			NoteType javaNoteType = JavaConstants.GetJavaCodeType(module);
			createOperation.putNoteContent(javaNoteType, JavaRepositoryCodeTemplate.getDelete());

		}

		private void addGetMethod(Class javaEntity, Class repository) {
			Operation createOperation = model.createOperation("get", repository);
			createOperation.setVisibility(VisibilityMode.PUBLIC);

			//Création du paramètre de retour
			Parameter outParam = model.createParameter();
			outParam.setType(javaEntity);
			createOperation.setReturn(outParam);
			createOperation.getReturn().setMultiplicityMax("1");


			//Création des paramètres d'entrée
			Parameter dataParam = model.createParameter();
			dataParam.setName("id");
			dataParam.setType(model.getUmlTypes().getSTRING());
			createOperation.getIO().add(dataParam);
			
			NoteType javaNoteType = JavaConstants.GetJavaCodeType(module);
			createOperation.putNoteContent(javaNoteType, JavaRepositoryCodeTemplate.getGet(javaEntity));

		}

		private void addGetAllMethod(Class javaEntity, Class repository) {
			Operation createOperation = model.createOperation("getAll", repository);
			createOperation.setVisibility(VisibilityMode.PUBLIC);

			//Création du paramètre de retour
			Parameter outParam = model.createParameter();
			outParam.setType(javaEntity);
			createOperation.setReturn(outParam);
			createOperation.getReturn().setMultiplicityMax("*");


			//Création des paramètres d'entrée
			//Création des paramètres d'entrée
			Parameter pageNumber = model.createParameter();
			pageNumber.setName("pageNumber");
			pageNumber.setType(model.getUmlTypes().getINTEGER());
			createOperation.getIO().add(pageNumber);
			
			Parameter pageSize = model.createParameter();
			pageSize.setName("pageSize");
			pageSize.setType(model.getUmlTypes().getINTEGER());
			createOperation.getIO().add(pageSize);
			
			NoteType javaNoteType = JavaConstants.GetJavaCodeType(module);
			createOperation.putNoteContent(javaNoteType, JavaRepositoryCodeTemplate.getGetall(javaEntity));

		}

	}

}
