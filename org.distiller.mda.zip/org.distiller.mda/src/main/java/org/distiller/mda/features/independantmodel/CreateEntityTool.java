package org.distiller.mda.features.independantmodel;

import java.util.List;

import org.distiller.mda.i18n.I18nMessageService;
import org.distiller.mda.impl.DistillerMdaModule;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.eclipse.draw2d.geometry.Rectangle;
import org.modelio.api.modelio.diagram.IDiagramGraphic;
import org.modelio.api.modelio.diagram.IDiagramHandle;
import org.modelio.api.modelio.diagram.IDiagramNode;
import org.modelio.api.modelio.diagram.tools.DefaultBoxTool;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.ITransaction;
import org.modelio.api.modelio.model.IUmlModel;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.diagrams.AbstractDiagram;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.NameSpace;
import org.modelio.metamodel.uml.statik.Package;
import org.modelio.vcore.smkernel.mapi.MObject;

public class CreateEntityTool extends DefaultBoxTool {

	@Override
	public boolean acceptElement(IDiagramHandle representation, IDiagramGraphic target) {
		boolean result = false;
		MObject element = target.getElement();
		if (element instanceof AbstractDiagram 
				&& ((AbstractDiagram)element).isStereotyped(DistillerConst.DataDomain_ModelDiagramSt())) {
			result = true;        
		}
		return result;
	}

	@Override
	public void actionPerformed(IDiagramHandle representation, IDiagramGraphic target, Rectangle rect) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();   
		try( ITransaction transaction = session.createTransaction (I18nMessageService.getString ("Info.Session.Create", "UML Aggregation"))){
			AbstractDiagram diagram = (AbstractDiagram)target.getElement();
			Package pimPack = PimObjFinder.FindPimPackFromPimDagram(diagram);
			Class pimEntity = model.createClass("Entity", (NameSpace)pimPack, DistillerConst.EntitySt());
			

			List<IDiagramGraphic> graph = representation.unmask(pimEntity, rect.x, rect.y);
			
			if((graph != null) &&  (graph.size() > 0) && (graph.get(0) instanceof IDiagramNode)) {
				((IDiagramNode)graph.get(0)).setBounds(rect);
				((IDiagramNode)graph.get(0)).setRepresentationMode(2);
			}

			representation.save();
			representation.close();

			transaction.commit();
		}

	}

	

}
