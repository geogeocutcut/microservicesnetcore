package org.distiller.mda.api;

import org.modelio.api.module.IPeerModule;

/**
 * @see com.modeliosoft.modelio.api.module.IPeerModule
 */
public interface IDistillerMdaPeerModule extends IPeerModule {

}
