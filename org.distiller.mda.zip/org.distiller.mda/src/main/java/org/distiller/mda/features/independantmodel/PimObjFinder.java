package org.distiller.mda.features.independantmodel;

import org.distiller.mda.metamodelhelper.DistillerConst;
import org.modelio.metamodel.diagrams.AbstractDiagram;
import org.modelio.metamodel.uml.infrastructure.Dependency;
import org.modelio.metamodel.uml.infrastructure.ModelElement;
import org.modelio.metamodel.uml.statik.Package;

public class PimObjFinder {
	
	public static Package FindPimPackFromPimDagram(AbstractDiagram diagram) {
		Package result = null;
		for (Dependency dep : diagram.getDependsOnDependency()) {
			ModelElement impacted = dep.getDependsOn();
			if (impacted instanceof Package 
					&& impacted.isStereotyped(DistillerConst.IndependantModelSt())) {
				result = (Package)impacted;
				break;
			}
		}
		return result;
	}
}
