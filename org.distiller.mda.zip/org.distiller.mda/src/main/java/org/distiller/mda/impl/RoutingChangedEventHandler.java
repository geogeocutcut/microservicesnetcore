package org.distiller.mda.impl;

import org.distiller.mda.metamodelhelper.DistillerConst;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.event.IModelChangeEvent;
import org.modelio.api.modelio.model.event.IModelChangeHandler;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.statik.AssociationEnd;
import org.modelio.metamodel.uml.statik.Attribute;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.vcore.smkernel.mapi.MObject;

public class RoutingChangedEventHandler implements IModelChangeHandler{
	
	private IModule module;

	public RoutingChangedEventHandler(IModule module) {
		this.module = module;
	}

	@Override
	public void handleModelChange(IModelingSession session, IModelChangeEvent event) {
		for (MObject updateElement : event.getUpdateEvents()) {
			if (updateElement instanceof Component 
					&& ((Component) updateElement).isStereotyped(DistillerConst._ModuleName,DistillerConst._DataDomainSt)) {
				org.distiller.mda.features.datadomain.EventHandler eventHandler = new org.distiller.mda.features.datadomain.EventHandler((Component)updateElement);
				eventHandler.Changed();
			}
			if (updateElement instanceof Class 
					&& ((Class) updateElement).isStereotyped(DistillerConst.EntitySt())) {
				org.distiller.mda.features.independantmodel.EntityEventHandler handler = new org.distiller.mda.features.independantmodel.EntityEventHandler((Class)updateElement, module);
				handler.Changed();
			}
			if (updateElement instanceof Attribute 
					&& ((Attribute) updateElement).getOwner().isStereotyped(DistillerConst.EntitySt())) {
				org.distiller.mda.features.independantmodel.AttributeEventHandler handler = new org.distiller.mda.features.independantmodel.AttributeEventHandler((Attribute)updateElement, module);
				handler.Changed();
			}
			if (updateElement instanceof AssociationEnd 
					&& ((AssociationEnd) updateElement).getOwner().isStereotyped(DistillerConst.EntitySt())) {
				org.distiller.mda.features.independantmodel.AssociationEndEventHandler handler = new org.distiller.mda.features.independantmodel.AssociationEndEventHandler((AssociationEnd)updateElement, module);
				handler.Changed();
			}
			
		}
		
	}

	

}
