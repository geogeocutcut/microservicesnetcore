package org.distiller.mda.features.datadomain;

import org.distiller.mda.metamodelhelper.DistillerConst;
import org.distiller.mda.metamodelhelper.ServiceConst;
import org.modelio.metamodel.uml.infrastructure.Dependency;
import org.modelio.metamodel.uml.infrastructure.ModelElement;
import org.modelio.metamodel.uml.infrastructure.ModelTree;
import org.modelio.metamodel.uml.infrastructure.Stereotype;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.DataType;
import org.modelio.metamodel.uml.statik.Interface;
import org.modelio.metamodel.uml.statik.Package;

public class DataDomainObjFinder {
	
	
	public static Component FindDataDomain(ModelTree element) {
		Component result = null;
		ModelTree owner = element.getOwner();
		if(owner != null 
				&& owner instanceof Component
				&& owner.isStereotyped(DistillerConst.DataDomainSt())) {
			result = (Component)owner;
		} else if (owner != null ) {
			result = FindDataDomain(owner);
		}
		return result;
		
	}
	
	public static Component FindStructure(Component domainData) {
		Stereotype structureSt = DistillerConst.DataStructureSt();
		Component result = null;
		for (Dependency dep : domainData.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Component 
					&& impacted.isStereotyped(structureSt)) {
				result = (Component)impacted;
				break;
			}
		}
		return result;
	}
	
	
	
	public static Package FindProjectsPack(Component dataDomain) {
		Package result = null;
		for (Package owned : dataDomain.getOwnedElement(Package.class)) {
			if(owned.getName().equals(DataDomainPrototypeName.getJavaProjectsName())) {
				result = owned;
				break;
			}
		}
		return result;
	}
	
	public static Package FindHibernatePackage(Component dataDomain) {
		Package result = null;
		Package projects = FindProjectsPack(dataDomain);
		if(projects != null)
			result = FindHibernatePackage(projects);
		return result;
	}
	
	public static DataType FindHibernateSession(Component dataDomain) {
		DataType result = null;
		Package projects = FindProjectsPack(dataDomain);
		if(projects != null) {
			Package hibernate = FindHibernatePackage(projects);
			if(hibernate!=null)
				result = FindHibernateSession(hibernate);
		}
		return result;
	}

	

	private static Package FindHibernatePackage(Package projects) {
		Package result = null;
		for (Package owned : projects.getOwnedElement(Package.class)) {
			if(owned.getName().equals(DataDomainPrototypeName.getHibernatePackName())) {
				result = owned;
				break;
			}
		}
		return result;
	}
	private static DataType FindHibernateSession(Package hibernate) {
		DataType result = null;
		for (DataType owned : hibernate.getOwnedElement(DataType.class)) {
			if(owned.getName().equals(DataDomainPrototypeName.getHibernateSessionName())) {
				result = owned;
				break;
			}
		}
		return result;
	}
	
	public static Component FindServiceImplPrj(Component dataDomain) {
		Component result = null;
		for (Dependency dep : dataDomain.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();
			if (impacted instanceof Component 
					&& impacted.isStereotyped(ServiceConst.ServiceImplPrjSt())) {
				result = (Component)impacted;
				break;
			}

		}
		return result;
	}

	public static DataType FindOrmBuilder(Component dataDomain) {
		DataType result = null;
		Package projects = FindProjectsPack(dataDomain);
		if(projects != null) {
			Package hibernate = FindHibernatePackage(projects);
			if(hibernate!=null)
				result = FindOrmBuilder(hibernate);
		}
		return result;
	}

	

	private static DataType FindOrmBuilder(Package hibernate) {
		DataType result = null;
		for (DataType owned : hibernate.getOwnedElement(DataType.class)) {
			if(owned.getName().equals(DataDomainPrototypeName.getOrmBuilderName())) {
				result = owned;
				break;
			}
		}
		return result;
	}

	public static DataType FindLogger(Component dataDomain) {
		DataType result = null;
		Package projects = FindProjectsPack(dataDomain);
		if(projects != null) {
			Package hibernate = FindHibernatePackage(projects);
			if(hibernate!=null)
				result = FindLogger(hibernate);
		}
		return result;
	}
	
	private static DataType FindLogger(Package hibernate) {
		DataType result = null;
		for (DataType owned : hibernate.getOwnedElement(DataType.class)) {
			if(owned.getName().equals(DataDomainPrototypeName.getLoggerName())) {
				result = owned;
				break;
			}
		}
		return result;
	}

	public static Interface FindCloseable(Component dataDomain) {
		Interface result = null;
		Package projects = FindProjectsPack(dataDomain);
		if(projects != null) {
			Package hibernate = FindHibernatePackage(projects);
			if(hibernate!=null)
				result = FindCloseable(hibernate);
		}
		return result;
	}
	
	private static Interface FindCloseable(Package hibernate) {
		Interface result = null;
		for (Interface owned : hibernate.getOwnedElement(Interface.class)) {
			if(owned.getName().equals(DataDomainPrototypeName.getCloseableName())) {
				result = owned;
				break;
			}
		}
		return result;
	}
}
