package org.distiller.mda.metamodelhelper;

import org.distiller.mda.impl.DistillerMdaModule;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.infrastructure.Stereotype;
import org.modelio.metamodel.uml.statik.AssociationEnd;
import org.modelio.metamodel.uml.statik.Attribute;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.Interface;
import org.modelio.metamodel.uml.statik.Package;
import org.modelio.vcore.smkernel.mapi.MClass;
import org.modelio.vcore.smkernel.mapi.MMetamodel;

public class JavaModelConst {
	public static final String ModuleName = "DistillerMda";
	
	private static final String _JavaEntityPackSt = "JavaEntityPackSt";
	private static final String _JavaEntitySt = "JavaEntitySt";
	private static final String _JavaAttributeSt = "JavaAttributeSt";
	private static final String _JavaAssociationEndSt = "JavaAssociationEndSt";
	
	private static final String _IRepositoryPackageSt = "IRepositoryPackageSt";
	private static final String _IRepositorySt = "IRepositorySt";
	private static final String _IRepositoryBuilderSt = "IRepositoryBuilderSt";
	
	private static final String _RepositoryImplPrjSt = "RepositoryImplPrjSt";
	private static final String _RepositoryImplPackageSt = "RepositoryImplPackageSt";
	private static final String _RepositoryImplSt = "RepositoryImplSt";
	private static final String _RepositoryBuilderSt = "RepositoryBuilderSt";
	
	
	public static Stereotype JavaEntityPackSt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Package.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_JavaEntityPackSt,mClass);
		return result;
	}
	
	public static Stereotype JavaEntitySt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Class.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_JavaEntitySt,mClass);
		return result;
	}
	public static Stereotype JavaAttributeSt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Attribute.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_JavaAttributeSt,mClass);
		return result;
	}
	public static Stereotype JavaAssociationEndSt(IModule module) {
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(AssociationEnd.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_JavaAssociationEndSt,mClass);
		return result;
	}

	public static Stereotype IRepositoryPackageSt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Package.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_IRepositoryPackageSt ,mClass);
		return result;
	}

	public static Stereotype IRepositoryBuilderSt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Interface.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_IRepositoryBuilderSt  ,mClass);
		return result;
	}

	


	public static Stereotype IRepositorySt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(org.modelio.metamodel.uml.statik.Interface.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_IRepositorySt  ,mClass);
		return result;
	}

	public static Stereotype RepositoryImplPackageSt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Package.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_RepositoryImplPackageSt ,mClass);
		return result;
	}

	public static Stereotype RepositoryImplPrjSt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Component.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_RepositoryImplPrjSt ,mClass);
		return result;
	}

	public static Stereotype RepositoryImplSt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(org.modelio.metamodel.uml.statik.Class.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_RepositoryImplSt ,mClass);
		return result;
	}

	public static Stereotype RepositoryBuilderSt() {
		IModule module = DistillerMdaModule.getInstance();
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(org.modelio.metamodel.uml.statik.Class.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_RepositoryBuilderSt  ,mClass);
		return result;
	}

	
	
	
	
	
}
