package org.distiller.mda.impl;

import java.util.List;

import org.distiller.mda.features.datadomain.DataDomainObjFinder;
import org.distiller.mda.features.datadomain.DataDomainPrototypeName;
import org.distiller.mda.features.javamodel.JavaModelObjFinder;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.levore.modeliotools.metamodelhelper.JavaConstants;
import org.modelio.api.module.IModule;
import org.modelio.api.module.propertiesPage.AbstractModulePropertyPage;
import org.modelio.api.module.propertiesPage.IModulePropertyTable;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.vcore.smkernel.mapi.MObject;

public class PropertyPage extends AbstractModulePropertyPage {

	public PropertyPage(IModule module, String name, String label, String bitmap) {
		super(module, name, label, bitmap);
	}

	/**
	 * This method is called when the current selection 
	 * changes and that the property box contents requires
	 * an update.
	 * In this example, simply add one property (the Name of
	 * the currently selected element)
	 */

	@Override
	public void update(List<MObject> elements, IModulePropertyTable table) {
		//		IModelingSession session = module.getModuleContext().getModelingSession();

		if (elements.size() == 1) {
			table.addProperty ("%name", elements.get(0).getName());
		}

		if (elements.size() == 1 && elements.get(0) instanceof Component) {
			Component selectedElement = (Component)elements.get(0);
			boolean isDataDomain = selectedElement.isStereotyped(DistillerConst._ModuleName,  DistillerConst._DataDomainSt);
			if(isDataDomain) {

				TagType generateDomainPathType = DistillerConst.DataDomainSt_DirectoryTag();

				String generatePath = selectedElement.getTagValue(generateDomainPathType);
				if (generatePath == null) {
					generatePath = "";
				}
				table.addProperty ("%DataDomain.directory", generatePath);
			}
		}

	}

	/**
	 * This method is called when a value has been edited
	 * in the property box in the row.
	 * Here we simply have to update the currently selected
	 * element name.
	 * Note: One transaction is already open. So it is not 
	 * necessary to create another one. 
	 */

	@Override
	public void changeProperty(List<MObject> elements, int row, String value) {
		
		if (row==1 && elements.size() == 1) {
			elements.get(0).setName(value);
		} else if (row==2 
				&& elements.size() == 1 
				&& elements.get(0) instanceof Component
				&& ((Component)elements.get(0)).isStereotyped(DistillerConst.DataDomainSt()) ) {
			Component dataDomain = (Component)elements.get(0);
			TagType javaGenPathType = JavaConstants.GetJavaComponentGenerationPath(module);
			TagType distillerGenPath = DistillerConst.DataDomainSt_DirectoryTag();
			dataDomain.putTagValue(distillerGenPath, value);

			Component structure = DataDomainObjFinder.FindStructure(dataDomain);
			structure.putTagValue(javaGenPathType, DataDomainPrototypeName.getStructureGenPath(dataDomain));

			Component repoImpl = JavaModelObjFinder.FindRepositoryImplPrj(dataDomain);
			repoImpl.putTagValue(javaGenPathType, DataDomainPrototypeName.getRepositoryImplPath(dataDomain));

			Component serviceImplPrj = DataDomainObjFinder.FindServiceImplPrj(dataDomain);
			serviceImplPrj.putTagValue(javaGenPathType, DataDomainPrototypeName.getServiceImplPrjPath(dataDomain));

		}
	}
}
