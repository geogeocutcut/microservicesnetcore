package org.distiller.mda.features.javamodel;

import org.distiller.mda.features.datadomain.DataDomainObjFinder;
import org.distiller.mda.impl.DistillerMdaModule;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.distiller.mda.metamodelhelper.JavaModelConst;
import org.levore.modeliotools.metamodelhelper.JavaConstants;
import org.levore.modeliotools.treevisitor.HandlerAdapter;
import org.levore.modeliotools.treevisitor.Visitor;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.ITransaction;
import org.modelio.api.modelio.model.IUmlModel;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.infrastructure.NoteType;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Classifier;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.DataType;
import org.modelio.metamodel.uml.statik.Interface;
import org.modelio.metamodel.uml.statik.Operation;
import org.modelio.metamodel.uml.statik.Package;
import org.modelio.metamodel.uml.statik.Parameter;

public class DelegateRepositoryBuilder {
	
	public void createIBuiolder(Package independantModel) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		try(ITransaction t = session.createTransaction("CreateConf")){
			Component dataDomain = DataDomainObjFinder.FindDataDomain(independantModel);
			Package iRepositoryPack = JavaModelObjFinder.FindIRepositoryPack(dataDomain);
			Interface iRepositoryBuilder = JavaModelObjFinder.FindIRepositoryBuilderOfDataDomain(dataDomain); 
			if (iRepositoryBuilder == null) {
				iRepositoryBuilder = model.createInterface(JavaModelProtoName.getIRepositoryBuilderName(), iRepositoryPack, JavaModelConst.IRepositoryBuilderSt());
				TagType javaImportType = JavaConstants.GetJavaImportInterfaceType(module);
				iRepositoryBuilder.putTagValue(javaImportType, "org.hibernate.Session");
				model.createDependency(iRepositoryBuilder, dataDomain, DistillerConst.DependencySt());
				
				CreateIRepositoryBuilderOperationHandler handler = new CreateIRepositoryBuilderOperationHandler(iRepositoryBuilder, dataDomain);
				Visitor visitor = new Visitor(handler);
				visitor.process(independantModel);
			}
			
			
			t.commit();
		}
	}
	
	public void createBuilder(Package independantModel) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		try(ITransaction t = session.createTransaction("CreateConf")){
			Component dataDomain = DataDomainObjFinder.FindDataDomain(independantModel);
			Package repositoryPack = JavaModelObjFinder.FindRepositoryPack(dataDomain);
			Interface iRepositoryBuilder = JavaModelObjFinder.FindIRepositoryBuilderOfDataDomain(dataDomain);
			Class repositoryBuilder = JavaModelObjFinder.FindRepositoryBuilder(dataDomain); 
			if (repositoryBuilder == null) {
				repositoryBuilder = model.createClass(JavaModelProtoName.getRepositoryBuilderName(), repositoryPack, JavaModelConst.RepositoryBuilderSt());
				TagType javaImportType = JavaConstants.GetJavaImportClassType(module);
				repositoryBuilder.putTagValue(javaImportType, "org.hibernate.Session");
				model.createDependency(repositoryBuilder, dataDomain, DistillerConst.DependencySt());
				model.createInterfaceRealization(repositoryBuilder, iRepositoryBuilder);
				CreateRepositoryBuilderOperationHandler handler = new CreateRepositoryBuilderOperationHandler(repositoryBuilder, dataDomain);
				Visitor visitor = new Visitor(handler);
				visitor.process(independantModel);
			}
			
			
			t.commit();
		}
	}
	
	private class CreateIRepositoryBuilderOperationHandler extends HandlerAdapter {
		
		private Interface iRepositoryBuilder;
		private IModule module;
		private IModelingSession session;
		private IUmlModel model;
		@SuppressWarnings("unused")
		private Component dataDomain;
		private DataType hibernateSession;
		
		public CreateIRepositoryBuilderOperationHandler(Interface iRepositoryBuilder, Component dataDomain) {
			this.module = DistillerMdaModule.getInstance();
			this.session = module.getModuleContext().getModelingSession();
			this.model = session.getModel();
			this.iRepositoryBuilder = iRepositoryBuilder;
			this.dataDomain = dataDomain;
			this.hibernateSession = DataDomainObjFinder.FindHibernateSession(dataDomain);
		}
		@Override
		protected void beginVisitingClassifier(Classifier visited) {
			Class pimEntity = (Class)visited;
			Interface iRepository = JavaModelObjFinder.FindIRepositoryFromPim(pimEntity);
			//NoteType javaCodeNoteType = JavaConstants.GetJavaCodeType(module);
			
			Operation buildEntityRepository = model.createOperation(JavaModelProtoName.getBuildEntityRepositoryOpeName(pimEntity), iRepositoryBuilder);
			Parameter outParam = model.createParameter();
			outParam.setType(iRepository);
			buildEntityRepository.setReturn(outParam);;
			
			Parameter dataParam = model.createParameter();
			dataParam.setName("session");
			dataParam.setType(hibernateSession);
			buildEntityRepository.getIO().add(dataParam);
			//model.createNote(javaCodeNoteType, create, "\treturn new ;");
			
		}

	}
	
	private class CreateRepositoryBuilderOperationHandler extends HandlerAdapter {
		
		private Class repositoryBuilder;
		private IModule module;
		private IModelingSession session;
		private IUmlModel model;
		@SuppressWarnings("unused")
		private Component dataDomain;
		private DataType hibernateSession;

		public CreateRepositoryBuilderOperationHandler(Class repositoryBuilder, Component dataDomain) {
			this.module = DistillerMdaModule.getInstance();
			this.session = module.getModuleContext().getModelingSession();
			this.model = session.getModel();
			this.repositoryBuilder = repositoryBuilder;
			this.dataDomain = dataDomain;
			this.hibernateSession = DataDomainObjFinder.FindHibernateSession(dataDomain);
		}
		
		@Override
		protected void beginVisitingClassifier(Classifier visited) {
			Class pimEntity = (Class)visited;
			Class repository = JavaModelObjFinder.FindRepositoryFromPim(pimEntity);
			Interface iRepository = JavaModelObjFinder.FindIRepositoryFromPim(pimEntity);
			NoteType javaCodeNoteType = JavaConstants.GetJavaCodeType(module);
			model.createElementImport(repositoryBuilder, repository);
			
			Operation buildEntityRepository = model.createOperation(JavaModelProtoName.getBuildEntityRepositoryOpeName(pimEntity), repositoryBuilder);
			Parameter outParam = model.createParameter();
			outParam.setType(iRepository);
			buildEntityRepository.setReturn(outParam);;
			
			Parameter dataParam = model.createParameter();
			dataParam.setName("session");
			dataParam.setType(hibernateSession);
			buildEntityRepository.getIO().add(dataParam);
			String code = String.format("\treturn new %s(session);", repository.getName());
			model.createNote(javaCodeNoteType, buildEntityRepository, code);
			
		}

	}

}
