package org.distiller.mda.features.service;

import org.distiller.mda.features.datadomain.DataDomainObjFinder;
import org.distiller.mda.features.javamodel.JavaModelObjFinder;
import org.distiller.mda.impl.DistillerMdaModule;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.distiller.mda.metamodelhelper.ServiceConst;
import org.levore.modeliotools.metamodelhelper.JavaConstants;
import org.levore.modeliotools.metamodelhelper.ModelerModuleConstants;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.IUmlModel;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.infrastructure.NoteType;
import org.modelio.metamodel.uml.infrastructure.Stereotype;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.DataType;
import org.modelio.metamodel.uml.statik.Interface;
import org.modelio.metamodel.uml.statik.Operation;
import org.modelio.metamodel.uml.statik.Package;
import org.modelio.metamodel.uml.statik.Parameter;
import org.modelio.metamodel.uml.statik.VisibilityMode;


public class DelegateServiceImpl {//extends HandlerAdapter{

	private IModule module;
	private IModelingSession session;
	private IUmlModel model;
	private Class pimAggregate;
	private NoteType javaCodeNoteType;

	public DelegateServiceImpl(Class pimAggregate) {
		module = DistillerMdaModule.getInstance();
		session = module.getModuleContext().getModelingSession();
		model = session.getModel();
		this.pimAggregate = pimAggregate;
		this.javaCodeNoteType = JavaConstants.GetJavaCodeType(module);

	}

	public void createServiceImpl() {
		Class serviceImpl = ServiceObjFinder.FindServiceImpl(pimAggregate);
		Component dataDomain = DataDomainObjFinder.FindDataDomain(pimAggregate);
		Package serviceImplPack = ServiceObjFinder.FindServiceImplPack(dataDomain);
		if (serviceImpl == null) {
			Class dtoAgregate = ServiceObjFinder.FindDtoAggregateFromPim(pimAggregate);
			Class dtoHeader = ServiceObjFinder.FindJHeaderFromPim(pimAggregate); 
			Class jAggregate = JavaModelObjFinder.FindJEntityFromPimEntity(pimAggregate);
			Interface iService = ServiceObjFinder.FindIServiceFrom(pimAggregate);

			DataType ormBuilder = DataDomainObjFinder.FindOrmBuilder(dataDomain);
			DataType logger = DataDomainObjFinder.FindLogger(dataDomain);
			Interface iRpositoryBuilder = JavaModelObjFinder.FindIRepositoryBuilderOfDataDomain(dataDomain);
			Interface iRepository = JavaModelObjFinder.FindIRepositoryFromPim(pimAggregate); 
			Class entityNotFoundException = ServiceObjFinder.FindEntityNotFoundExceptionFromEntity(pimAggregate);
			Class invalidEntityException = ServiceObjFinder.FindInvalidEntityExceptionFromPim(pimAggregate);

			TagType javaImportType = JavaConstants.GetJavaImportClassType(module);
			serviceImpl = model.createClass(ServicePrototypeName.getServiceImplName(pimAggregate), serviceImplPack, JavaConstants.GetJavaClassStereotype(module));
			serviceImpl.getExtension().add(ServiceConst.ServiceImplSt());
			serviceImpl.putTagValue(javaImportType, "java.io.IOException");
			model.createTagParameter("java.util.ArrayList", serviceImpl.getTag(javaImportType));
			model.createTagParameter("java.util.List", serviceImpl.getTag(javaImportType));
			model.createTagParameter("org.hibernate.Session", serviceImpl.getTag(javaImportType));
			model.createTagParameter("org.hibernate.Transaction", serviceImpl.getTag(javaImportType));
			model.createTagParameter("org.slf4j.Logger", serviceImpl.getTag(javaImportType));
			model.createTagParameter("org.slf4j.LoggerFactory", serviceImpl.getTag(javaImportType));
			model.createTagParameter("com.levore.gnl.OrmBuilder", serviceImpl.getTag(javaImportType));
			
			model.createInterfaceRealization(serviceImpl, iService);
			model.createDependency(serviceImpl, pimAggregate, DistillerConst.DependencySt());
			model.createElementImport(serviceImpl, jAggregate);
			model.createElementImport(serviceImpl, iRepository);
			model.createElementImport(serviceImpl, entityNotFoundException);
			model.createElementImport(serviceImpl, invalidEntityException);
			
			model.createAttribute("ormBuilder", ormBuilder, serviceImpl);
			model.createAttribute("iRepositoryBuilder", iRpositoryBuilder, serviceImpl);
			model.createAttribute("deeperTransformer", ServiceObjFinder.FindDepperTransformer(pimAggregate), serviceImpl);
			model.createAttribute("headerTransformer", ServiceObjFinder.FindHeaderTransformer(pimAggregate), serviceImpl);
			model.createAttribute("log", logger, serviceImpl);
			
			addConstructor(ormBuilder, iRpositoryBuilder, serviceImpl, jAggregate);
			addCreateMethod(dtoAgregate, serviceImpl);
			addUpdateMethod(dtoAgregate, serviceImpl);
			addDeleteMethod(dtoAgregate, serviceImpl);
			addGetMethod(dtoAgregate, serviceImpl);
			addGetAllMethod(dtoHeader, serviceImpl);
			addCloseMethod(serviceImpl);


		}
	}


	private void addCloseMethod(Class serviceImpl) {
		NoteType javaCodeNoteType = JavaConstants.GetJavaCodeType(module);
		Operation create = model.createOperation("close", serviceImpl);
		
		String code = "//ormBuilder.close();";
		model.createNote(javaCodeNoteType, create, code);
		
	}

	private void addConstructor(DataType ormBuilder, Interface iRepositoryBuilder, Class serviceImpl, Class jAggregate) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();

		Stereotype constructorSt = ModelerModuleConstants.GetConstructorSt(module);
		NoteType javaCodeNoteType = JavaConstants.GetJavaCodeType(module);
		Operation create = model.createOperation("create", serviceImpl, constructorSt);

		Parameter ormBuilderParm = model.createParameter();
		ormBuilderParm.setName("ormBuilder");
		ormBuilderParm.setType(ormBuilder);
		create.getIO().add(ormBuilderParm);

		Parameter iRepositoryBuilderParm = model.createParameter();
		iRepositoryBuilderParm.setName("iRepositoryBuilder");
		iRepositoryBuilderParm.setType(iRepositoryBuilder);
		create.getIO().add(iRepositoryBuilderParm);

		String code = ServiceCodeTemplate.getServImpl_Constructor(jAggregate);
		model.createNote(javaCodeNoteType, create, code);

	}

	private void addCreateMethod(Class dtoAgregate, Class serviceImpl) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		//add create method
		Operation operat = model.createOperation("create", serviceImpl);
		operat.setVisibility(VisibilityMode.PUBLIC);
		//Création du paramètre de retour
		Parameter outParam = model.createParameter();
		outParam.setType(dtoAgregate);
		operat.setReturn(outParam);
		operat.getReturn().setMultiplicityMax("1");

		//Création des paramètres d'entrée
		Parameter dataParam = model.createParameter();
		dataParam.setName("dto");
		dataParam.setType(dtoAgregate);
		operat.getIO().add(dataParam);

		Class dto = ServiceObjFinder.FindDtoAggregateFromPim(pimAggregate);
		Class headerDto = ServiceObjFinder.FindJHeaderFromPim(pimAggregate); 
		Class jEntity = JavaModelObjFinder.FindJEntityFromPimEntity(pimAggregate);
		Interface iRepository = JavaModelObjFinder.FindIRepositoryFromPim(pimAggregate); 
		String code = ServiceCodeTemplate.getServImpl_AddOperation(headerDto, dto, iRepository, jEntity);
		model.createNote(javaCodeNoteType, operat, code);

	}

	private void addUpdateMethod(Class dtoAgregate, Class serviceImpl) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		//add create method
		Operation operat = model.createOperation("update", serviceImpl);
		operat.setVisibility(VisibilityMode.PUBLIC);
		//Création du paramètre de retour
		Parameter outParam = model.createParameter();
		outParam.setType(dtoAgregate);
		operat.setReturn(outParam);
		operat.getReturn().setMultiplicityMax("1");

		//Création des paramètres d'entrée
		Parameter dataParam = model.createParameter();
		dataParam.setName("dto");
		dataParam.setType(dtoAgregate);
		operat.getIO().add(dataParam);

		Class dto = ServiceObjFinder.FindDtoAggregateFromPim(pimAggregate);
		Class headerDto = ServiceObjFinder.FindJHeaderFromPim(pimAggregate); 
		Class jEntity = JavaModelObjFinder.FindJEntityFromPimEntity(pimAggregate);
		Interface iRepository = JavaModelObjFinder.FindIRepositoryFromPim(pimAggregate); 
		String code = ServiceCodeTemplate.getServImpl_UpdateOperation(headerDto, dto, iRepository, jEntity);
		model.createNote(javaCodeNoteType, operat, code);

	}

	private void addDeleteMethod(Class dtoAgregate, Class serviceImpl) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		Operation operat = model.createOperation("delete", serviceImpl);
		operat.setVisibility(VisibilityMode.PUBLIC);

		//Création des paramètres d'entrée
		Parameter dataParam = model.createParameter();
		dataParam.setName("id");
		dataParam.setType(model.getUmlTypes().getSTRING());
		operat.getIO().add(dataParam);

		Class dto = ServiceObjFinder.FindDtoAggregateFromPim(pimAggregate);
		Class headerDto = ServiceObjFinder.FindJHeaderFromPim(pimAggregate); 
		Class jEntity = JavaModelObjFinder.FindJEntityFromPimEntity(pimAggregate);
		Interface iRepository = JavaModelObjFinder.FindIRepositoryFromPim(pimAggregate); 
		String code = ServiceCodeTemplate.getServImpl_DeleteOperation(headerDto, dto, iRepository, jEntity);
		model.createNote(javaCodeNoteType, operat, code);

	}

	private void addGetMethod(Class dtoAgregate, Class serviceImpl) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		Operation operat = model.createOperation("get", serviceImpl);
		operat.setVisibility(VisibilityMode.PUBLIC);

		//Création du paramètre de retour
		Parameter outParam = model.createParameter();
		outParam.setType(dtoAgregate);
		operat.setReturn(outParam);
		operat.getReturn().setMultiplicityMax("1");


		//Création des paramètres d'entrée
		Parameter dataParam = model.createParameter();
		dataParam.setName("id");
		dataParam.setType(model.getUmlTypes().getSTRING());
		operat.getIO().add(dataParam);

		Class dto = ServiceObjFinder.FindDtoAggregateFromPim(pimAggregate);
		Class headerDto = ServiceObjFinder.FindJHeaderFromPim(pimAggregate); 
		Class jEntity = JavaModelObjFinder.FindJEntityFromPimEntity(pimAggregate);
		Interface iRepository = JavaModelObjFinder.FindIRepositoryFromPim(pimAggregate); 
		String code = ServiceCodeTemplate.getServImpl_GetOperation(headerDto, dto, iRepository, jEntity);
		model.createNote(javaCodeNoteType, operat, code);

	}

	private void addGetAllMethod(Class dtoHeader, Class serviceImpl) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();
		Operation operat = model.createOperation("getAll", serviceImpl);
		operat.setVisibility(VisibilityMode.PUBLIC);

		//Création du paramètre de retour
		Parameter outParam = model.createParameter();
		outParam.setType(dtoHeader);
		operat.setReturn(outParam);
		operat.getReturn().setMultiplicityMax("*");


		//Création des paramètres d'entrée
		Parameter pageNumber = model.createParameter();
		pageNumber.setName("pageNumber");
		pageNumber.setType(model.getUmlTypes().getINTEGER());
		operat.getIO().add(pageNumber);
		
		Parameter pageSize = model.createParameter();
		pageSize.setName("pageSize");
		pageSize.setType(model.getUmlTypes().getINTEGER());
		operat.getIO().add(pageSize);
		
		Class dto = ServiceObjFinder.FindDtoAggregateFromPim(pimAggregate);
		Class headerDto = ServiceObjFinder.FindJHeaderFromPim(pimAggregate); 
		Class jEntity = JavaModelObjFinder.FindJEntityFromPimEntity(pimAggregate);
		Interface iRepository = JavaModelObjFinder.FindIRepositoryFromPim(pimAggregate); 
		String code = ServiceCodeTemplate.getServImpl_GetAllOperation(headerDto, dto, iRepository, jEntity);
		model.createNote(javaCodeNoteType, operat, code);

	}

}
