package org.distiller.mda.features.datadomain;

import org.distiller.mda.metamodelhelper.DistillerConst;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.Component;

public class DataDomainPrototypeName {
	private static final String ServiveIocFileProtoName = "com.levore.%s.services.xml";
	private static String StructureProjectProtoName = "%sStructure";
	private static String JavaProjectsProtoName = "Projects";
	public static String ModelPackageName = "com.levore.%s.model";
	private static String IRepositoryPackageProtoName = "com.levore.%s.repository.interfaz";
	public static String StructurePath = "%s\\%sStructure\\src\\main\\java";
	private static String RepositoryProtoName = "%sRepositoryImpl";
	private static String RepositoryPackageProtoName = "com.levore.%s.repository";
	private static String RepositoryImplPath = "%s\\%sRepositoryImpl\\src\\main\\java";
	private static String HibernatePackProtoName = "Hibernate";
	private static String HibernateSessionProtoName = "Session";
	private static String OrmBuilderProtoName = "OrmBuilder";
	private static String ServiceImplPrjProtoName = "%sServiceImpl";
	private static String ServiceImplPath = "%s\\%sServiceImpl\\src\\main\\java";
	private static String LoggerProtoName = "Logger";
	private static String CloseableProtoName = "Closeable";
	
	
	public static String getServiceImplPrjName(Component dataDomain) {
		return String.format(ServiceImplPrjProtoName, dataDomain.getName());
	}
	
	
	public static String getStructureProjectName(Component dataDomain) {
		return String.format(StructureProjectProtoName, dataDomain.getName());
	}

	public static String getJavaProjectsName() {
		return JavaProjectsProtoName;
	}

	public static String getRepositoryName(Component dataDomain) {
		return String.format(RepositoryProtoName, dataDomain.getName());
	}
	
	public static String getRepositoryImplPackageName(Component dataDomain) {
		return String.format(RepositoryPackageProtoName, dataDomain.getName()).toLowerCase();
	}
	
	public static String getRepositoryImplPath(Component dataDomain) {
		TagType genPathType = DistillerConst.DataDomainSt_DirectoryTag();
		String genPath = dataDomain.getTagValue(genPathType);
		return String.format(RepositoryImplPath, genPath, dataDomain.getName());
	}

	public static String getIRepositoryPackageName(Component dataDomain) {
		return String.format(IRepositoryPackageProtoName, dataDomain.getName()).toLowerCase();
	}

	public static String getHibernatePackName() {
		return HibernatePackProtoName;
	}

	public static String getHibernateSessionName() {
		return HibernateSessionProtoName;
	}

	public static Object getProjectsName() {
		// TODO Auto-generated method stub
		return null;
	}

	public static String getStructureGenPath(Component dataDomain) {
		TagType genPathType = DistillerConst.DataDomainSt_DirectoryTag();
		String genPath = dataDomain.getTagValue(genPathType);
		return String.format(StructurePath, genPath, dataDomain.getName());
	}


	public static String getServiceImplPrjPath(Component dataDomain) {
		TagType genPathType = DistillerConst.DataDomainSt_DirectoryTag();
		String genPath = dataDomain.getTagValue(genPathType);
		return String.format(ServiceImplPath, genPath, dataDomain.getName());
	}


	public static String getOrmBuilderName() {
		
		return OrmBuilderProtoName;
	}


	public static String getServiveIocFileName(Component dataDomain) {
		
		return String.format(ServiveIocFileProtoName, dataDomain.getName());
	}


	public static String getLoggerName() {
		// TODO Auto-generated method stub
		return LoggerProtoName ;
	}


	public static String getCloseableName() {
		return CloseableProtoName ;
	}

	
	
}
