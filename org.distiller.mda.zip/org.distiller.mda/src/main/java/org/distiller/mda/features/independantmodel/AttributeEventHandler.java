package org.distiller.mda.features.independantmodel;

import java.util.ArrayList;
import java.util.List;

import org.distiller.mda.metamodelhelper.JavaModelConst;
import org.distiller.mda.metamodelhelper.ServiceConst;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.infrastructure.Dependency;
import org.modelio.metamodel.uml.infrastructure.ModelElement;
import org.modelio.metamodel.uml.statik.Attribute;
import org.modelio.metamodel.uml.statik.VisibilityMode;

public class AttributeEventHandler {

	private IModule module;
	private Attribute pimAttribute;
	private Attribute javaAttribute;
	private List<Attribute> dtoAttributes;

	public AttributeEventHandler(Attribute pimAttribute, IModule module) {
		this.module = module;
		this.pimAttribute = pimAttribute;
		initializeVars();
	}

	public  void Changed() {
		if(javaAttribute!=null) {
			String javaEntityName = pimAttribute.getName();
			javaAttribute.setName(javaEntityName);
			javaAttribute.setVisibility(VisibilityMode.PUBLIC);
			javaAttribute.setMultiplicityMax(pimAttribute.getMultiplicityMax());
			javaAttribute.setType(pimAttribute.getType());
		}
		
		for(Attribute dtoAttribute : dtoAttributes) {
			String javaEntityName = pimAttribute.getName();
			dtoAttribute.setName(javaEntityName);
			dtoAttribute.setVisibility(VisibilityMode.PUBLIC);
			dtoAttribute.setMultiplicityMax(pimAttribute.getMultiplicityMax());
			dtoAttribute.setType(pimAttribute.getType());
		}
	}


	private  void initializeVars() {
		dtoAttributes = new ArrayList<>();
		for (Dependency dep : pimAttribute.getImpactedDependency()) {
			ModelElement impacted = dep.getImpacted();;
			if (impacted instanceof Attribute && impacted.isStereotyped(JavaModelConst.JavaAttributeSt())) {
				this.javaAttribute = (Attribute)impacted;
			}
			if (impacted instanceof Attribute && impacted.isStereotyped(ServiceConst.DtoAttributeSt(module))) {
				dtoAttributes.add((Attribute)impacted);
			}
		}

	}
}
