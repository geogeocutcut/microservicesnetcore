package org.distiller.mda.features.javamodel;

import org.distiller.mda.impl.DistillerMdaModule;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.distiller.mda.metamodelhelper.JavaModelConst;
import org.levore.modeliotools.metamodelhelper.JavaConstants;
import org.levore.modeliotools.treevisitor.HandlerAdapter;
import org.levore.modeliotools.treevisitor.Visitor;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.ITransaction;
import org.modelio.api.modelio.model.IUmlModel;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.infrastructure.Dependency;
import org.modelio.metamodel.uml.infrastructure.ModelElement;
import org.modelio.metamodel.uml.infrastructure.Stereotype;
import org.modelio.metamodel.uml.statik.Association;
import org.modelio.metamodel.uml.statik.AssociationEnd;
import org.modelio.metamodel.uml.statik.Attribute;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Classifier;
import org.modelio.metamodel.uml.statik.NameSpace;
import org.modelio.metamodel.uml.statik.Package;
import org.modelio.metamodel.uml.statik.VisibilityMode;

public class DelegateJEntity {
	
	public  void createJentities (Package independantModel) {
		IModule module = DistillerMdaModule.getInstance();
		IModelingSession session = module.getModuleContext().getModelingSession();
		
		try(ITransaction t = session.createTransaction("CreateConf")){
			//EntitiesHandler handler = new EntitiesHandler(independantModel, module);
			
			EntitiesHandler handler = new EntitiesHandler(independantModel, module);
        	Visitor visitor = new Visitor(handler);
        	visitor.process(independantModel);
        	t.commit();
        }
        
        try(ITransaction t = session.createTransaction("CreateConf")){
        	AssociationsHandler handler = new AssociationsHandler(independantModel, module);
        	Visitor visitor = new Visitor(handler);
        	visitor.process(independantModel);
        	t.commit();
        }
	}

	private class EntitiesHandler extends HandlerAdapter {

//		public static String iRepositoryProtoName = "I%sRepository";

		private Package independantModel;
		private Package javaModel;
		private IModule module;
		private IModelingSession session;
		private IUmlModel model;


		private Stereotype javaModelSt;
		private Stereotype JavaDesignerClassSt;
		private Stereotype javaEntitySt;
		private Stereotype javaDesignerAttributeSt;
		private Stereotype javaAttributeSt;
		private Stereotype eventDependencySt;



		public EntitiesHandler(Package independantModel, IModule module) {
			this.independantModel = independantModel;
			this.module = module;
			this.session = module.getModuleContext().getModelingSession();
			model = this.session.getModel();
			this.initializeVars();
		}

		@Override
		protected void beginVisitingClassifier(Classifier pimEntity) {


			// create Java Class
			Class javaEntity = JavaModelObjFinder.FindJEntityFromPimEntity((Class)pimEntity);
			if (javaEntity==null) {
				javaEntity = model.createClass(pimEntity.getName(), (NameSpace) javaModel);
				javaEntity.getExtension().add(JavaDesignerClassSt);
				javaEntity.getExtension().add(javaEntitySt);
				model.createDependency(javaEntity, pimEntity ,eventDependencySt);
			}

			//create id
			Attribute id = JavaModelObjFinder.FindJIdentifier(javaEntity);
			if (id==null) {
				id = model.createAttribute("id", model.getUmlTypes().getSTRING(), javaEntity);
				id.getExtension().add(javaDesignerAttributeSt);
			}

			//create attributes
			for (Attribute pimAttribute : pimEntity.getOwnedAttribute()) {
				Attribute javaAttribute = JavaModelObjFinder.FindJAttributeFromPimAttribute(pimAttribute);
				if (javaAttribute == null) {
					javaAttribute = model.createAttribute(pimAttribute.getName(), pimAttribute.getType(), javaEntity);
					javaAttribute.setVisibility(VisibilityMode.PUBLIC);
					javaAttribute.setMultiplicityMax(pimAttribute.getMultiplicityMax());
					model.createDependency(javaAttribute, pimAttribute ,eventDependencySt);
					javaAttribute.getExtension().add(javaDesignerAttributeSt);
					javaAttribute.getExtension().add(javaAttributeSt);
				}
			}



		}

		



		
		

		private  void initializeVars() {
			javaModelSt = JavaModelConst.JavaEntityPackSt();
			JavaDesignerClassSt = JavaConstants.GetJavaClassStereotype(module);
			javaDesignerAttributeSt = JavaConstants.GetJavaAttributePropertyStereotype(module);
			javaEntitySt = JavaModelConst.JavaEntitySt();
			javaAttributeSt = JavaModelConst.JavaAttributeSt();
			eventDependencySt = DistillerConst.DependencySt();
			

			for (Dependency dep : independantModel.getImpactedDependency()) {
				ModelElement impacted = dep.getImpacted();;
				if (impacted instanceof Package 
						&& impacted.isStereotyped(javaModelSt)) {
					this.javaModel = (Package)impacted;
				}

			}


		}
	}

	private class AssociationsHandler extends HandlerAdapter {

		private IModule module;
		private IModelingSession session;
		private IUmlModel model;
		private Stereotype javaAssociationEndSt;
		private Stereotype eventDependencySt;
		private Stereotype javaDesignerAssociationEndSt;

		public AssociationsHandler(Package independantModel, IModule module) {
			this.module = module;
			this.session = module.getModuleContext().getModelingSession();
			model = this.session.getModel();
			this.initializeVars();
		}



		@Override
		protected void beginVisitingAssociationEnd(AssociationEnd pimTargetAssociationEnd) {

			//Stereotype pimImpactStereotype = DistillerConstants.GetSoftwareFactoryPimImpactStereotype(session);

			Class pimSrc = (Class)pimTargetAssociationEnd.getSource();
			Class pimTarget = (Class)pimTargetAssociationEnd.getTarget();
			Class javaSrc = JavaModelObjFinder.FindJEntityFromPimEntity(pimSrc);
			Class javaTarget = JavaModelObjFinder.FindJEntityFromPimEntity(pimTarget);

			Association javaAssociation = JavaModelObjFinder.FindJAssociationFromJEntity(pimTargetAssociationEnd.getName(), javaSrc);
			if (javaAssociation == null) {
				javaAssociation = model.createAssociation(javaSrc, javaTarget, pimTargetAssociationEnd.getName());
				AssociationEnd javaAssociationTargetEnd = javaAssociation.getEnd().get(1);
				javaAssociationTargetEnd.getExtension().add(javaDesignerAssociationEndSt);
				javaAssociationTargetEnd.getExtension().add(javaAssociationEndSt);
				javaAssociationTargetEnd.setVisibility(VisibilityMode.PUBLIC);
				javaAssociationTargetEnd.setMultiplicityMax(pimTargetAssociationEnd.getMultiplicityMax());
				javaAssociationTargetEnd.getOpposite().setMultiplicityMax(pimTargetAssociationEnd.getOpposite().getMultiplicityMax());
				javaAssociationTargetEnd.setAggregation(pimTargetAssociationEnd.getAggregation());

				model.createDependency(javaAssociationTargetEnd, pimTargetAssociationEnd,eventDependencySt);
			}

		}

		



		private void initializeVars() {
			javaAssociationEndSt = JavaModelConst.JavaAssociationEndSt(module);
			eventDependencySt = DistillerConst.DependencySt();
			javaDesignerAssociationEndSt = JavaConstants.GetJavaAssociationEndPropertyStereotype(module);
		}



		

		

	}
}
