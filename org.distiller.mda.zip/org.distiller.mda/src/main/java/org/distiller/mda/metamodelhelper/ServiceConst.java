package org.distiller.mda.metamodelhelper;

import org.distiller.mda.impl.DistillerMdaModule;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.infrastructure.Stereotype;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.AssociationEnd;
import org.modelio.metamodel.uml.statik.Attribute;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.Interface;
import org.modelio.metamodel.uml.statik.Package;
import org.modelio.vcore.smkernel.mapi.MClass;
import org.modelio.vcore.smkernel.mapi.MMetamodel;

public class ServiceConst {
	public static final String ModuleName = "DistillerMda";
	
	private static String _ServiceDTOPackageSt          = "ServiceDTOPackageSt";
	private static String _ServiceInterfacePackageSt    = "ServiceInterfacePackageSt";
	private static String _ServiceTransformerPackageSt  = "ServiceTransformerPackageSt";
	
	private static String _DtoSt = "DtoSt";
	private static String _DtoSt_DtoGuidTag = "DtoSt_DtoGuidTag";
	private static String _DtoAgregateSt = "DtoAgregateSt";
	private static String _DtoHeaderSt = "DtoHeaderSt";
	private static String _DtoAttributeSt = "DtoAttributeSt";
	private static String _DtoAssociationEndSt = "DtoAssociationEndSt";

	private static String _EntityNotFoundExceptionSt = "EntityNotFoundExceptionSt";
	private static String _InvalidEntityExceptionSt = "InvalidEntityExceptionSt";
	private static String _IEntityServiceSt = "IEntityServiceSt";
	
	private static String _DeeperTransformerSt = "DeeperTransformerSt";
	private static String _HeaderTransformerSt = "HeaderTransformerSt";

	private static String _ServiceImplPrjSt      = "ServiceImplPrjSt";
	private static String _ServiceImplPackSt     = "ServiceImplPackSt";
	private static String _ServiceImplSt         = "ServiceImplSt";
	
	
	public static Stereotype ServiceDTOPackageSt() {
		Stereotype result = null;
		IModule module = DistillerMdaModule.getInstance();
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Package.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_ServiceDTOPackageSt,mClass);
		return result;
	}
	
	public static Stereotype ServiceInterfacePackageSt() {
		Stereotype result = null;
		DistillerMdaModule module = DistillerMdaModule.getInstance();
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Package.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_ServiceInterfacePackageSt,mClass);
		return result;
	}
	
	public static Stereotype ServiceTransformerPackageSt() {
		Stereotype result = null;
		DistillerMdaModule module = DistillerMdaModule.getInstance();
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Package.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_ServiceTransformerPackageSt,mClass);
		return result;
	}
	
	public static Stereotype DtoSt() {
		Stereotype result = null;
		IModule module = DistillerMdaModule.getInstance();
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Class.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_DtoSt,mClass);
		return result;
	}
	public static TagType DtoSt_DtoGuidTag() {
		TagType result = null;
		IModule module = DistillerMdaModule.getInstance();
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Component.class);
		result = session.getMetamodelExtensions().getTagType(ModuleName, _DtoSt_DtoGuidTag, mClass);
		return result;
	}
	public static Stereotype DtoAgregateSt() {
		Stereotype result = null;
		IModule module = DistillerMdaModule.getInstance();
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Class.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_DtoAgregateSt,mClass);
		return result;
	}
	public static Stereotype DtoHeaderSt() {
		Stereotype result = null;
		IModule module = DistillerMdaModule.getInstance();
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Class.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_DtoHeaderSt,mClass);
		return result;
	}
	
	public static Stereotype DtoAttributeSt(IModule module) {
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Attribute.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_DtoAttributeSt,mClass);
		return result;
	}
	public static Stereotype DtoAssociationEndSt(IModule module) {
		Stereotype result = null;
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(AssociationEnd.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_DtoAssociationEndSt,mClass);
		return result;
	}

	public static Stereotype EntityNotFoundExceptionSt() {
		Stereotype result = null;
		IModule module = DistillerMdaModule.getInstance();
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Class.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_EntityNotFoundExceptionSt,mClass);
		return result;
	}

	public static Stereotype InvalidEntityExceptionSt() {
		Stereotype result = null;
		IModule module = DistillerMdaModule.getInstance();
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Class.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_InvalidEntityExceptionSt,mClass);
		return result;
	}

	public static Stereotype IEntityServiceSt() {
		Stereotype result = null;
		IModule module = DistillerMdaModule.getInstance();
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Interface.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_IEntityServiceSt,mClass);
		return result;
	}
	
	public static Stereotype DeeperTransformerSt() {
		Stereotype result = null;
		IModule module = DistillerMdaModule.getInstance();
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Class.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_DeeperTransformerSt,mClass);
		return result;
	}
	public static Stereotype HeaderTransformerSt() {
		Stereotype result = null;
		IModule module = DistillerMdaModule.getInstance();
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Class.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_HeaderTransformerSt,mClass);
		return result;
	}
	
	public static Stereotype ServiceImplPrjSt      () {
		Stereotype result = null;
		IModule module = DistillerMdaModule.getInstance();
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Component.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_ServiceImplPrjSt,mClass);
		return result;
	}
	public static Stereotype ServiceImplPackSt     () {
		Stereotype result = null;
		IModule module = DistillerMdaModule.getInstance();
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Package.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_ServiceImplPackSt,mClass);
		return result;
	}
	public static Stereotype ServiceImplSt         () {
		Stereotype result = null;
		IModule module = DistillerMdaModule.getInstance();
		MMetamodel metamodel = module.getModuleContext().getModelioServices().getMetamodelService().getMetamodel();
		IModelingSession session = module.getModuleContext().getModelingSession();
		MClass mClass = metamodel.getMClass(Class.class);
		result = session.getMetamodelExtensions().getStereotype(ModuleName,_ServiceImplSt,mClass);
		return result;
	}
}
