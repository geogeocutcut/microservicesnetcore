package org.distiller.mda.features.datadomain;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.distiller.mda.features.service.ServiceObjFinder;
import org.distiller.mda.impl.DistillerMdaModule;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.levore.modeliotools.metamodelhelper.JavaConstants;
import org.levore.modeliotools.treevisitor.HandlerAdapter;
import org.levore.modeliotools.treevisitor.Visitor;
import org.modelio.api.module.IModule;
import org.modelio.metamodel.uml.infrastructure.ModelTree;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Classifier;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.Interface;
import org.modelio.metamodel.uml.statik.Package;

public class DelegateServiceIoC {

	public void GenServicesIocXml(Component dataDomain){

		PomTemplate tmpl = new PomTemplate(dataDomain);
		StringBuffer strBuffer = new StringBuffer();
		strBuffer.append(tmpl.getServ_ioc_header());

		ServicesIocXmlHandler handler = new ServicesIocXmlHandler(tmpl, strBuffer);
		Visitor visitor = new Visitor(handler);
		for (Package element : dataDomain.getOwnedElement(Package.class)) {
			visitor.process(element);
		}
		strBuffer.append(tmpl.getServ_ioc_end());
		
		TagType generateStructurePathType = DistillerConst.DataDomainSt_DirectoryTag();
		String genDirPath = dataDomain.getTagValue(generateStructurePathType) + "\\" + DataDomainPrototypeName.getServiceImplPrjName(dataDomain) + "\\src\\main\\resources";
		String content = strBuffer.toString();
		try {
			File fileDir = new File(genDirPath );
			fileDir.mkdirs();
			File file = new File(genDirPath + "\\" + DataDomainPrototypeName.getServiveIocFileName(dataDomain));
			FileWriter writer = new FileWriter(file);
			writer.write(content);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private class ServicesIocXmlHandler extends HandlerAdapter {

		private StringBuffer strBuffer;
		private PomTemplate tmpl;

		//private List<Class> repositories;

		public ServicesIocXmlHandler(PomTemplate tmpl, StringBuffer strBuffer){
			this.strBuffer = strBuffer;
			this.tmpl = tmpl;

		}

		@Override
		protected void beginVisitingClassifier(Classifier visited) {
			if(visited.isStereotyped(DistillerConst.EntitySt())) {
				Interface iService = ServiceObjFinder.FindIServiceFrom((Class)visited);
				Class serviceImpl = ServiceObjFinder.FindServiceImpl((Class)visited);
				if (iService != null && serviceImpl != null) {
					String stringJavaPackage = getStringJavaPackage(serviceImpl);
					strBuffer.append(tmpl.getServ_ioc_services(stringJavaPackage, iService, serviceImpl));
				}
			}
			
		}

		private String getStringJavaPackage(ModelTree item) {
			IModule module = DistillerMdaModule.getInstance();
			String result = null;
			ModelTree owner = item.getOwner();
			if (owner instanceof Package && owner.isStereotyped(JavaConstants.GetJavaPackageStereotype(module))) {
				String prefix = getStringJavaPackage(owner);
				if (prefix.equals(""))
					result = owner.getName();
				else
					result = prefix  + "." + owner.getName();
			} else {
				result = "";
			}
			return result;
		}

		public StringBuffer getStrBuffer() {
			return strBuffer;
		}


	}
}
