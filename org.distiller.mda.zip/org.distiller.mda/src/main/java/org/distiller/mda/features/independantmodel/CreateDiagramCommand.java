package org.distiller.mda.features.independantmodel;

import java.util.List;

import org.distiller.mda.metamodelhelper.DistillerConst;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.ITransaction;
import org.modelio.api.modelio.model.IUmlModel;
import org.modelio.api.module.IModule;
import org.modelio.api.module.command.DefaultModuleCommandHandler;
import org.modelio.api.module.context.log.ILogService;
import org.modelio.metamodel.diagrams.AbstractDiagram;
import org.modelio.metamodel.uml.statik.Package;
import org.modelio.vcore.smkernel.mapi.MObject;

/**
 * Implementation of the IModuleContextualCommand interface.
 * <br>The module contextual commands are displayed in the contextual menu and in the specific toolbar of each module property page.
 * <br>The developer may inherit the DefaultModuleContextualCommand class which contains a default standard contextual command implementation.
 *
 */
public class CreateDiagramCommand extends DefaultModuleCommandHandler {
    /**
     * Constructor.
     */
    public CreateDiagramCommand() {
        super();
    }

    /**
     * @see org.modelio.api.module.commands.DefaultModuleContextualCommand#accept(java.util.List,
     *      org.modelio.api.module.IModule)
     */
    @Override
    public boolean accept(List<MObject> selectedElements, IModule module) {
    	boolean result = false;
		if (selectedElements.size() == 1 && selectedElements.get(0) instanceof Package) {
			Package selectedElement = (Package)selectedElements.get(0);
			result = selectedElement.isStereotyped(DistillerConst.IndependantModelSt());
		}
		return result;
    }

    /**
     * @see org.modelio.api.module.commands.DefaultModuleContextualCommand#actionPerformed(java.util.List,
     *      org.modelio.api.module.IModule)
     */
    @Override
    public void actionPerformed(List<MObject> selectedElements, IModule module) {
        ILogService logService = module.getModuleContext().getLogService();
        logService.info("CreateDomainMapCommand - actionPerformed(...)");

        IModelingSession session = module.getModuleContext().getModelingSession();
//        List<MObject> root = session.getModel().getModelRoots();
        //IModuleUserConfiguration configuration = module.getModuleContext().getConfiguration();

        Package pim = (Package)selectedElements.get(0);
        //MessageDialog.openInformation(null, "Hello", modelelt.getName());
        try(ITransaction t = session.createTransaction("CreateConf")){
        	IUmlModel model = session.getModel();
    		AbstractDiagram diag = model.createClassDiagram(DistillerConst._DataDomain_ModelDiagramSt, pim, DistillerConst.DataDomain_ModelDiagramSt());
    		model.createDependency(diag, pim,DistillerConst.DependencySt());
        	t.commit();
        }
    }


}
