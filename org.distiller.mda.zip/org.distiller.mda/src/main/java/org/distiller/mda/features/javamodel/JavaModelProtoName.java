package org.distiller.mda.features.javamodel;
import org.modelio.metamodel.uml.statik.Class;

public class JavaModelProtoName {
	private static final String IRepositoryBuilderProtoName = "IRepositoryBuilder";
	private static final String RepositoryBuilderProtoName = "RepositoryBuilder";
	private static final String iRepositoryProtoName = "I%sRepository";
	private static final String repositoryProtoName = "%sRepository";
	private static final String buildEntityRepositoryOpeProtoName = "build%sRepository";

	public static String getRepositoryName(Class pim) {
		return String.format(repositoryProtoName, pim.getName());
	}

	public static String getiRepositoryProtoName(Class pim) {
		return String.format(iRepositoryProtoName, pim.getName());
	}

	public static String getIRepositoryBuilderName() {
		return IRepositoryBuilderProtoName;
	}

	public static String getBuildEntityRepositoryOpeName(Class pim) {
		return String.format(buildEntityRepositoryOpeProtoName , pim.getName());
	}

	public static String getRepositoryBuilderName() {
		return RepositoryBuilderProtoName;
	}

	
	
}
