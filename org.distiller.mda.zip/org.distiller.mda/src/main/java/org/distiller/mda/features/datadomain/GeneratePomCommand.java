package org.distiller.mda.features.datadomain;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.distiller.mda.metamodelhelper.DistillerConst;
import org.modelio.api.module.IModule;
import org.modelio.api.module.command.DefaultModuleCommandHandler;
import org.modelio.api.module.context.log.ILogService;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.vcore.smkernel.mapi.MObject;

/**
 * Implementation of the IModuleContextualCommand interface.
 * <br>The module contextual commands are displayed in the contextual menu and in the specific toolbar of each module property page.
 * <br>The developer may inherit the DefaultModuleContextualCommand class which contains a default standard contextual command implementation.
 *
 */
public class GeneratePomCommand extends DefaultModuleCommandHandler {
	/**
	 * Constructor.
	 */
	public GeneratePomCommand() {
		super();
	}

	/**
	 * @see org.modelio.api.module.commands.DefaultModuleContextualCommand#accept(java.util.List,
	 *      org.modelio.api.module.IModule)
	 */
	@Override
	public boolean accept(List<MObject> selectedElements, IModule module) {
		boolean result = false;
		if (selectedElements.size() == 1 && selectedElements.get(0) instanceof Component) {
			Component selectedElement = (Component)selectedElements.get(0);
			result = selectedElement.isStereotyped(DistillerConst.DataDomainSt());
		}
		return result;
	}

	/**
	 * @see org.modelio.api.module.commands.DefaultModuleContextualCommand#actionPerformed(java.util.List,
	 *      org.modelio.api.module.IModule)
	 */
	@Override
	public void actionPerformed(List<MObject> selectedElements, IModule module) {
		ILogService logService = module.getModuleContext().getLogService();
		logService.info("CreateDomainMapCommand - actionPerformed(...)");

		Component dataDomain = (Component)selectedElements.get(0);
		TagType generateStructurePathType = DistillerConst.DataDomainSt_DirectoryTag();
    	
		genPomStructure(dataDomain, generateStructurePathType);
		genIocRepository(dataDomain, generateStructurePathType);
		genPomRepository(dataDomain, generateStructurePathType);
		DelegateServiceIoC delegateServiceIoc = new DelegateServiceIoC();
		delegateServiceIoc.GenServicesIocXml(dataDomain);
		genPomService(dataDomain, generateStructurePathType);
	}

	

	private void genPomService(Component dataDomain, TagType generateStructurePathType) {
		String genDirPath = dataDomain.getTagValue(generateStructurePathType) + "\\" + dataDomain.getName() + "ServiceImpl";
		PomTemplate templater = new PomTemplate(dataDomain);
		String pomStr = templater.GetService_pom();
		try {
			File fileDir = new File(genDirPath );
			fileDir.mkdirs();
			File file = new File(genDirPath + "\\pom.xml");
			FileWriter writer = new FileWriter(file);
			writer.write(pomStr);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void genPomStructure(Component dataDomain, TagType generateStructurePathType) {
		String genDirPath = dataDomain.getTagValue(generateStructurePathType) + "\\" + dataDomain.getName() + "Structure";
		PomTemplate templater = new PomTemplate(dataDomain);
		String pomStr = templater.Getstructure_pom();
		try {
			File fileDir = new File(genDirPath );
			fileDir.mkdirs();
			File file = new File(genDirPath + "\\pom.xml");
			FileWriter writer = new FileWriter(file);
			writer.write(pomStr);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void genIocRepository(Component dataDomain, TagType generateStructurePathType) {
		String genDirPath = dataDomain.getTagValue(generateStructurePathType) + "\\" + dataDomain.getName() + "RepositoryImpl\\src\\main\\resources";
		PomTemplate templater = new PomTemplate(dataDomain);
		String CONTENT = templater.Getrepository_ioc();
		try {
			File fileDir = new File(genDirPath );
			fileDir.mkdirs();
			File file = new File(genDirPath + "\\repositories.xml");
			FileWriter writer = new FileWriter(file);
			writer.write(CONTENT);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void genPomRepository(Component dataDomain, TagType generateStructurePathType) {
		String genDirPath = dataDomain.getTagValue(generateStructurePathType) + "\\" + dataDomain.getName() + "RepositoryImpl";
		PomTemplate templater = new PomTemplate(dataDomain);
		String CONTENT = templater.getRepositoryimpl_pom();
		try {
			File fileDir = new File(genDirPath );
			fileDir.mkdirs();
			File file = new File(genDirPath + "\\pom.xml");
			FileWriter writer = new FileWriter(file);
			writer.write(CONTENT);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


}
