package org.distiller.mda.features.service;

import org.distiller.mda.features.datadomain.DataDomainObjFinder;
import org.distiller.mda.impl.DistillerMdaModule;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.distiller.mda.metamodelhelper.ServiceConst;
import org.levore.modeliotools.metamodelhelper.JavaConstants;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.ITransaction;
import org.modelio.api.modelio.model.IUmlModel;
import org.modelio.api.module.IModule;
import org.modelio.api.module.context.log.ILogService;
import org.modelio.metamodel.uml.infrastructure.Stereotype;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.Package;

public class DelegateService {
	public  Package delegateCreateDtoPack(String serviceDtoName, Class pimEntity) {
		Package serviceDto = null;
		IModule module = DistillerMdaModule.getInstance();
		ILogService logService = module.getModuleContext().getLogService();
		logService.info("CreateDomainMapCommand - actionPerformed(...)");

		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();

		Stereotype javaServiceDtoSt = ServiceConst.ServiceDTOPackageSt();
		Stereotype eventDependencySt = DistillerConst.DependencySt();
		Stereotype javaDesignerPackageSt = JavaConstants.GetJavaPackageStereotype(module);

		try(ITransaction t = session.createTransaction("CreateConf")){
			Component domainData = DistillerConst.DataDomain(pimEntity);
			Component structure = DataDomainObjFinder.FindStructure(domainData);

			serviceDto = ServiceObjFinder.FindServiceDtoPack(pimEntity);
			if(serviceDto == null) {
				serviceDto = model.createPackage(serviceDtoName, structure);
				serviceDto.getExtension().add(javaServiceDtoSt);
				serviceDto.getExtension().add(javaDesignerPackageSt);
				model.createDependency(serviceDto, pimEntity,eventDependencySt);
				model.createDependency(serviceDto, domainData,eventDependencySt);

			}
			t.commit();
		}
		return serviceDto;
	}
	
	

	public  Package delegateCreateInterfacePack(String serviceInterfaceName, Class pimEntity) {
		Package serviceInterface = null;
		IModule module = DistillerMdaModule.getInstance();
		ILogService logService = module.getModuleContext().getLogService();
		logService.info("CreateDomainMapCommand - actionPerformed(...)");

		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();

		Stereotype javaServiceInterfaceSt = ServiceConst.ServiceInterfacePackageSt();
		Stereotype eventDependencySt = DistillerConst.DependencySt();
		Stereotype javaDesignerPackageSt = JavaConstants.GetJavaPackageStereotype(module);

		try(ITransaction t = session.createTransaction("CreateConf")){
			Component domainData = DistillerConst.DataDomain(pimEntity);
			Component structure = DataDomainObjFinder.FindStructure(domainData);

			serviceInterface = ServiceObjFinder.FindServiceInterfacePack(domainData);
			if(serviceInterface == null) {
				serviceInterface = model.createPackage(serviceInterfaceName, structure);
				serviceInterface.getExtension().add(javaServiceInterfaceSt);
				serviceInterface.getExtension().add(javaDesignerPackageSt);
				model.createDependency(serviceInterface, domainData,eventDependencySt);
			}
			t.commit();
		}
		return serviceInterface;
	}

	public  Package delegateCreateTransformerPack(String serviceTransformerName, Class pimEntity) {
		Package serviceTransformer = null;
		IModule module = DistillerMdaModule.getInstance();
		ILogService logService = module.getModuleContext().getLogService();
		logService.info("CreateDomainMapCommand - actionPerformed(...)");

		IModelingSession session = module.getModuleContext().getModelingSession();
		IUmlModel model = session.getModel();

		Stereotype javaServiceTransformerSt = ServiceConst.ServiceTransformerPackageSt();
		Stereotype eventDependencySt = DistillerConst.DependencySt();
		Stereotype javaDesignerPackageSt = JavaConstants.GetJavaPackageStereotype(module);

		try(ITransaction t = session.createTransaction("CreateConf")){
			Component domainData = DistillerConst.DataDomain(pimEntity);
			Component structure = DataDomainObjFinder.FindStructure(domainData);

			serviceTransformer = ServiceObjFinder.FindserviceTransformerPack(domainData);
			if(serviceTransformer == null) {
				serviceTransformer = model.createPackage(serviceTransformerName, structure);
				serviceTransformer.getExtension().add(javaServiceTransformerSt);
				serviceTransformer.getExtension().add(javaDesignerPackageSt);
				model.createDependency(serviceTransformer, domainData,eventDependencySt);
			}
			t.commit();
		}
		return serviceTransformer;
	}

	



	


	
}
