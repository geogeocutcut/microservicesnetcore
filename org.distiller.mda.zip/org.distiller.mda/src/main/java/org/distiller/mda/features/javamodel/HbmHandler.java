package org.distiller.mda.features.javamodel;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.distiller.mda.metamodelhelper.DistillerConst;
import org.levore.modeliotools.treevisitor.HandlerAdapter;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.AssociationEnd;
import org.modelio.metamodel.uml.statik.Attribute;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Classifier;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.Package;

public class HbmHandler extends HandlerAdapter {

	private Component dataDomain;
//	private DistillerMdaModule module;
//	private IModelingSession session;
	private TagType generateStructurePathType;
	private String genPathProto = "%s\\%sRepositoryImpl\\src\\main\\resources\\hbm\\"; //\\%s.hbm.xml";

	public HbmHandler(Component dataDomain)  {
		this.dataDomain=dataDomain;
//		this.module = DistillerMdaModule.getInstance();
//		this.session = module.getModuleContext().getModelingSession();
		generateStructurePathType = DistillerConst.DataDomainSt_DirectoryTag();
	}

	@Override
	protected void beginVisitingClassifier(Classifier visited) {
		Class jEntity = JavaModelObjFinder.FindJEntityFromPimEntity((Class)visited);
		Package jModelPack = JavaModelObjFinder.FindJavaModelPack(dataDomain);
		HbmTemplate template = new HbmTemplate(jModelPack);
		String genDirPath = getGenPath(jEntity);
		StringBuffer content = new StringBuffer("");
		content.append(template.getHeader(jEntity));
		for (Attribute attr : jEntity.getOwnedAttribute()) {
			if (!attr.getName().equals("id"))
				content.append(template.getAttribute(attr));
		}
		for (AssociationEnd end: jEntity.getOwnedEnd()) {
			if (isOneToOne(end)) content.append(template.getOnetoone(end));
			if (isOneToMany(end)) content.append(template.getOnetomany(end));
			if (isManyToOne(end)) content.append(template.getManytoone(end));
			if (isManyToMany(end)) content.append(template.getManytomany(end));
		}
		content.append(template.getEnd());
		
		
		try {
			File fileDir = new File(genDirPath );
			fileDir.mkdirs();
			File file = new File(genDirPath + "\\" + jEntity.getName() + ".hbm.xml");
			FileWriter writer = new FileWriter(file);
			writer.write(content.toString());
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private boolean isOneToOne(AssociationEnd end) {
		boolean result = false;
		if (!end.getOpposite().getMultiplicityMax().equals("*") && !end.getMultiplicityMax().equals("*"))
			result = true;
		return result;
	}
	private boolean isOneToMany(AssociationEnd end) {
		boolean result = false;
		if (!end.getOpposite().getMultiplicityMax().equals("*") && end.getMultiplicityMax().equals("*"))
			result = true;
		return result;
	}
	private boolean isManyToOne(AssociationEnd end) {
		boolean result = false;
		if (end.getOpposite().getMultiplicityMax().equals("*") && !end.getMultiplicityMax().equals("*"))
			result = true;
		return result;
	}
	private boolean isManyToMany(AssociationEnd end) {
		boolean result = false;
		if (end.getOpposite().getMultiplicityMax().equals("*") && end.getMultiplicityMax().equals("*"))
			result = true;
		return result;
	}

	private String getGenPath(Class jEntity) {
		String rootPath = dataDomain.getTagValue(generateStructurePathType);
		return String.format(genPathProto, rootPath, dataDomain.getName());//, jEntity.getName());
	}

	
}
