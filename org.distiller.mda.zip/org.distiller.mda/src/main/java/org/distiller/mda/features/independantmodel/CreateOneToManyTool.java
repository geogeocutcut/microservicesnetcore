package org.distiller.mda.features.independantmodel;

import java.util.List;

import org.distiller.mda.i18n.I18nMessageService;
import org.distiller.mda.impl.DistillerMdaModule;
import org.distiller.mda.metamodelhelper.DistillerConst;
import org.modelio.api.modelio.diagram.IDiagramGraphic;
import org.modelio.api.modelio.diagram.IDiagramHandle;
import org.modelio.api.modelio.diagram.IDiagramLink;
import org.modelio.api.modelio.diagram.IDiagramLink.LinkRouterKind;
import org.modelio.api.modelio.diagram.ILinkPath;
import org.modelio.api.modelio.diagram.InvalidDestinationPointException;
import org.modelio.api.modelio.diagram.InvalidPointsPathException;
import org.modelio.api.modelio.diagram.InvalidSourcePointException;
import org.modelio.api.modelio.diagram.tools.DefaultLinkTool;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.ITransaction;
import org.modelio.api.modelio.model.IUmlModel;
import org.modelio.metamodel.uml.statik.AggregationKind;
import org.modelio.metamodel.uml.statik.Association;
import org.modelio.metamodel.uml.statik.AssociationEnd;
import org.modelio.metamodel.uml.statik.Class;
import org.modelio.metamodel.uml.statik.Classifier;

public class CreateOneToManyTool extends DefaultLinkTool {

	@Override
	public boolean acceptFirstElement(IDiagramHandle arg0, IDiagramGraphic arg1) {
		boolean result = false;
		if ((arg1 != null) 
				&& (arg1.getElement() != null)
				&& arg1.getElement() instanceof Class
				&& ((Class)arg1.getElement()).isStereotyped(DistillerConst.EntitySt())){ 
		//	Class src = (Class)arg1.getElement();
			result = true;
		}
		return result;
	}

	@Override
	public boolean acceptSecondElement(IDiagramHandle arg0, IDiagramGraphic arg1, IDiagramGraphic arg2) {
		boolean result = false;
		if ((arg2 != null) 
				&& (arg2.getElement() != null)
				&& arg2.getElement() instanceof Class
				&& ((Class)arg2.getElement()).isStereotyped(DistillerConst.EntitySt())){ 
			//Class target = (Class)arg2.getElement();
			result = true;
		}
		return result;
	}

	@Override
	public void actionPerformed(IDiagramHandle representation, IDiagramGraphic arg1, IDiagramGraphic arg2, LinkRouterKind arg3,
			ILinkPath path) {
		IModelingSession session = DistillerMdaModule.getInstance().getModuleContext().getModelingSession();
        IUmlModel model = session.getModel();        
        try( ITransaction transaction = session.createTransaction (I18nMessageService.getString ("Info.Session.Create", "UML Aggregation"))){
        
            Classifier c_source = (Classifier)arg1.getElement();
            Classifier c_destination = (Classifier)arg2.getElement();
        
            Association association = model.createAssociation();
        
            AssociationEnd endSource = model.createAssociationEnd();          
            endSource.setMultiplicityMin("1");
            endSource.setMultiplicityMax("1");
            endSource.setSource(c_destination);
            endSource.setTarget(c_source);
        
            AssociationEnd endTarget = model.createAssociationEnd();
            endTarget.setName(c_destination.getName().toLowerCase());
            endTarget.setAggregation(AggregationKind.KINDISCOMPOSITION);
            //endTarget.setMultiplicityMin("1");
            endTarget.setMultiplicityMax("*");
           
            association.getEnd().add(endTarget);    
            association.getEnd().add(endSource);
             
            
            endSource.setOpposite(endTarget);
            endTarget.setOpposite(endSource);  
            
            endSource.setNavigable(false);
            endTarget.setNavigable(true);
        
        
            List<IDiagramGraphic> graphics = representation.unmask(association, 0 , 0);
            for (IDiagramGraphic graphic : graphics){
                if (graphic instanceof IDiagramLink){
                    IDiagramLink link = (IDiagramLink) graphic;
                    link.setPath(path);                
                }
            }
        
            representation.save();
            representation.close();
            transaction.commit ();
        } catch (InvalidSourcePointException e) {
        	//TODO : Manage log
        } catch (InvalidPointsPathException e) {
        	//TODO : Manage log
        } catch (InvalidDestinationPointException e) {
        	//TODO : Manage log
        }
		
	}

}
