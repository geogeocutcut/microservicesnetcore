package org.distiller.mda.features.datadomain;

import java.util.List;

import org.distiller.mda.metamodelhelper.DistillerConst;
import org.distiller.mda.metamodelhelper.JavaModelConst;
import org.distiller.mda.metamodelhelper.ServiceConst;
import org.levore.modeliotools.metamodelhelper.JavaConstants;
import org.modelio.api.modelio.model.IModelingSession;
import org.modelio.api.modelio.model.ITransaction;
import org.modelio.api.modelio.model.IUmlModel;
import org.modelio.api.module.IModule;
import org.modelio.api.module.command.DefaultModuleCommandHandler;
import org.modelio.api.module.context.log.ILogService;
import org.modelio.metamodel.uml.infrastructure.Stereotype;
import org.modelio.metamodel.uml.infrastructure.TagType;
import org.modelio.metamodel.uml.statik.Component;
import org.modelio.metamodel.uml.statik.DataType;
import org.modelio.metamodel.uml.statik.Interface;
import org.modelio.metamodel.uml.statik.Package;
import org.modelio.vcore.smkernel.mapi.MObject;

/**
 * Implementation of the IModuleContextualCommand interface.
 * <br>The module contextual commands are displayed in the contextual menu and in the specific toolbar of each module property page.
 * <br>The developer may inherit the DefaultModuleContextualCommand class which contains a default standard contextual command implementation.
 *
 */
public class CreateDataDomainCommand extends DefaultModuleCommandHandler {
	/**
	 * Constructor.
	 */
	public CreateDataDomainCommand() {
		super();
	}

	/**
	 * @see org.modelio.api.module.commands.DefaultModuleContextualCommand#accept(java.util.List,
	 *      org.modelio.api.module.IModule)
	 */
	@Override
	public boolean accept(List<MObject> selectedElements, IModule module) {
		boolean result = false;
		if (selectedElements.size() == 1 && selectedElements.get(0) instanceof Package) {
			Package selectedElement = (Package)selectedElements.get(0);
			result = selectedElement.isStereotyped(DistillerConst._ModuleName,  DistillerConst._DomainMapSt);
		}
		return result;
	}

	/**
	 * @see org.modelio.api.module.commands.DefaultModuleContextualCommand#actionPerformed(java.util.List,
	 *      org.modelio.api.module.IModule)
	 */
	@Override
	public void actionPerformed(List<MObject> selectedElements, IModule module) {
		ILogService logService = module.getModuleContext().getLogService();
		logService.info("CreateDomainMapCommand - actionPerformed(...)");

		IModelingSession session = module.getModuleContext().getModelingSession();
		//        List<MObject> root = session.getModel().getModelRoots();
		//IModuleUserConfiguration configuration = module.getModuleContext().getConfiguration();

		Package visited = (Package)selectedElements.get(0);
		//MessageDialog.openInformation(null, "Hello", modelelt.getName());
		try(ITransaction t = session.createTransaction("CreateConf")){
			IUmlModel model = session.getModel();

			Stereotype dataDomainSt = DistillerConst.DataDomainSt();
			Stereotype independantModelSt = DistillerConst.IndependantModelSt();
			Stereotype structureSt = DistillerConst.DataStructureSt();
			Stereotype respositoryImplSt = JavaModelConst.RepositoryImplPrjSt();
			Stereotype javaModelSt  = JavaModelConst.JavaEntityPackSt();
			Stereotype iRepsositoryPackageSt = JavaModelConst.IRepositoryPackageSt();
			Stereotype eventDependencySt = DistillerConst.DependencySt();
			Stereotype javaDesignerComponent = JavaConstants.GetJavaComponentStereotype(module);
			Stereotype javaDesignerPackage = JavaConstants.GetJavaPackageStereotype(module);

			TagType generateDomainPathType = DistillerConst.DataDomainSt_DirectoryTag();
			TagType generatePathType = JavaConstants.GetJavaComponentGenerationPath(module);


			//Create Data domaine
			Component dataDomain = model.createComponent("Data domain", visited);
			dataDomain.getExtension().add(dataDomainSt);
			dataDomain.putTagValue(generateDomainPathType, "");

			//Create Independant model
			Package independantModel = model.createPackage("Independant model", dataDomain);
			independantModel.getExtension().add(independantModelSt);

			//Create java projects Package
			Package projects = model.createPackage(DataDomainPrototypeName.getJavaProjectsName(), dataDomain);

			createStructureJavaProject(model, structureSt, javaModelSt, iRepsositoryPackageSt, eventDependencySt,
					javaDesignerComponent, javaDesignerPackage, generatePathType, dataDomain, independantModel,
					projects);

			//RepositoryImpl
			Component repositoryImpl = model.createComponent(DataDomainPrototypeName.getRepositoryName(dataDomain), projects);
			repositoryImpl.getExtension().add(javaDesignerComponent);
			repositoryImpl.getExtension().add(respositoryImplSt);
			model.createDependency(repositoryImpl, dataDomain, eventDependencySt);
			repositoryImpl.putTagValue(generatePathType, DataDomainPrototypeName.getRepositoryImplPath(dataDomain));

			// create java model package
			String repositoryPackName = DataDomainPrototypeName.getRepositoryImplPackageName(dataDomain);
			Package repositoryPack = model.createPackage(repositoryPackName, repositoryImpl);
			repositoryPack.getExtension().add(javaDesignerPackage);

			repositoryPack.getExtension().add(JavaModelConst.RepositoryImplPackageSt());
			model.createDependency(repositoryPack, dataDomain, eventDependencySt);
			model.createDependency(repositoryPack, independantModel, eventDependencySt);

			//create Hibernate package
			Package hibernate = DataDomainObjFinder.FindHibernatePackage(dataDomain);
			if(hibernate == null) 
				hibernate = model.createPackage(DataDomainPrototypeName.getHibernatePackName(), projects);
			
			//Create Hibernate session
			DataType hSession = DataDomainObjFinder.FindHibernateSession(dataDomain);
			if(hSession == null) 
				model.createDataType(DataDomainPrototypeName.getHibernateSessionName(), hibernate);
			
			//Create Orm Builder
			DataType ormBuilder = DataDomainObjFinder.FindOrmBuilder(dataDomain);
			if(ormBuilder == null) 
				model.createDataType(DataDomainPrototypeName.getOrmBuilderName(), hibernate);
			
			Interface closeable = DataDomainObjFinder.FindCloseable(dataDomain);
			if(ormBuilder == null) 
				model.createInterface(DataDomainPrototypeName.getCloseableName(), hibernate);
			
			
			
			DataType logger = DataDomainObjFinder.FindLogger(dataDomain);
			if(logger == null) 
				model.createDataType(DataDomainPrototypeName.getLoggerName(), hibernate);

			//Create ServiceImplPrj
			Component serviceImplPrj = DataDomainObjFinder.FindServiceImplPrj(dataDomain);
			if (serviceImplPrj == null ) {
				serviceImplPrj = model.createComponent(DataDomainPrototypeName.getServiceImplPrjName(dataDomain), projects, JavaConstants.GetJavaComponentStereotype(module));
				serviceImplPrj.getExtension().add(ServiceConst.ServiceImplPrjSt());
				model.createDependency(serviceImplPrj, dataDomain, DistillerConst.DependencySt());
			}
			
			t.commit();
		}
	}

	private void createStructureJavaProject(IUmlModel model, Stereotype structureSt, Stereotype javaModelSt,
			Stereotype iRepsositoryPackageSt, Stereotype eventDependencySt, Stereotype javaDesignerComponent,
			Stereotype javaDesignerPackage, TagType generatePathType, Component dataDomain, Package independantModel,
			Package projects) {
		//create structure java project
		Component structure = model.createComponent(DataDomainPrototypeName.getStructureProjectName(dataDomain), projects);
		structure.getExtension().add(javaDesignerComponent);
		structure.getExtension().add(structureSt);
		model.createDependency(structure, dataDomain, eventDependencySt);
		structure.putTagValue(generatePathType, "");

		// create java model package
		String packageModelName = String.format(DataDomainPrototypeName.ModelPackageName, dataDomain.getName()).toLowerCase();
		Package javaModelPackage = model.createPackage(packageModelName, structure);
		javaModelPackage.getExtension().add(javaDesignerPackage);
		javaModelPackage.getExtension().add(javaModelSt);
		model.createDependency(javaModelPackage, dataDomain, eventDependencySt);
		model.createDependency(javaModelPackage, independantModel, eventDependencySt);

		//create java repository interface package
		String packageRepositoryName = DataDomainPrototypeName.getIRepositoryPackageName(dataDomain);
		Package javaRespositoryPackage = model.createPackage(packageRepositoryName, structure);
		javaRespositoryPackage.getExtension().add(javaDesignerPackage);
		javaRespositoryPackage.getExtension().add(iRepsositoryPackageSt);
		model.createDependency(javaRespositoryPackage, dataDomain, eventDependencySt);
		model.createDependency(javaRespositoryPackage, independantModel, eventDependencySt);
	}


}
