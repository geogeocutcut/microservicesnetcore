﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace Smag.Framework.Common.Cryptography
{
    public class Encrypter
    {
        private const string strKey = "LqNirlyejysn6wwnrBSZzWZQ";

        private static byte[] FormatKey(string securityKey, int length)
        {
            string key = securityKey;
            while (key.Length < length)
                key += securityKey;

            byte[] bytes = UTF8Encoding.UTF8.GetBytes(key);

            byte[] res = new byte[length];
            for (int i = 0; i < length; i++)
                res[i] = bytes[i];

            return res;
        }

        public static string GetRandomSecurityKey()
        {
            TripleDESCryptoServiceProvider t = new TripleDESCryptoServiceProvider();
            Random random = new Random();
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < t.Key.Length; i++)
                builder.Append((char)random.Next('0', 'z' + 1));

            return builder.ToString();
        }

        public static string Encrypt(string data)
        {
            return Encrypt(data, strKey);
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="data"></param>
        /// <param name="securityKey"></param>
        /// <remarks>
        /// Equivalent PHP / testé via http://writecodeonline.com/php/
        ///
        ///  $data = ""; // TODO
        ///  $securityKey = ""; // TODO
        ///  $blockSize = mcrypt_get_block_size('tripledes', 'ecb');
        ///  $len = strlen($data);
        ///  $pad = $blockSize - ($len % $blockSize);
        ///  $data .= str_repeat(chr($pad), $pad);
        ///  $encData = mcrypt_encrypt('tripledes', $securityKey, $data, 'ecb');
        ///  echo base64_encode($encData);
        /// </remarks>
        /// <returns></returns>
        public static string Encrypt(string data, string securityKey)
        {
            if (string.IsNullOrEmpty(data) || string.IsNullOrEmpty(securityKey))
                return string.Empty;

            byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(data);

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            byte[] bytes = UTF8Encoding.UTF8.GetBytes(securityKey);
            //tdes.KeySize = bytes.Length; // erreur : affectation de la taille en bit par une valeur en octet ??
            tdes.Key = bytes;
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = tdes.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            tdes.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        public static string Decrypt(string encryptedData)
        {
            return Decrypt(encryptedData, strKey);
        }

        public static string Decrypt(string encryptedData, string securityKey)
        {
            if (string.IsNullOrEmpty(encryptedData) || string.IsNullOrEmpty(securityKey))
                return string.Empty;

            byte[] toEncryptArray = Convert.FromBase64String(encryptedData);

            TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();
            tdes.Key = FormatKey(securityKey, tdes.Key.Length);
            tdes.Mode = CipherMode.ECB;
            tdes.Padding = PaddingMode.PKCS7;

            ICryptoTransform cTransform = tdes.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            tdes.Clear();
            return UTF8Encoding.UTF8.GetString(resultArray);
        }
    }
}