﻿using System.ComponentModel;
using System.Text;

namespace Smag.Framework.Common.Extension
{
    /// <summary>
    /// Extensions de classes pour les exceptions.
    /// </summary>
    public static class ExceptionExtensions
    {
        #region Méthodes publiques

        /// <summary>
        /// Obtient la description de l'erreur, avec son erreur interne.
        /// </summary>
        /// <param name="ex">Exception.</param>
        /// <returns>Message complet de l'erreur.</returns>
        public static string GetExtendedMessage(this System.Exception ex)
        {
            StringBuilder errorMessage = null;
            if (ex != null)
            {
                string indent = null;
                while (ex != null)
                {
                    string message = ex.Message?.Trim();
                    if (!string.IsNullOrEmpty(message))
                    {
                        if (errorMessage == null)
                        {
                            errorMessage = new StringBuilder(message);
                            indent = "\n    ";
                        }
                        else
                        {
                            errorMessage.Append(indent);
                            errorMessage.Append(message.Replace("\n", indent));
                            indent += "    ";
                        }
                    }
                    ex = ex.InnerException;
                }
            }
            return errorMessage?.ToString();
        }

        /// <summary>
        /// Renvoie l'exception initiale. (La plus interne)
        /// </summary>
        /// <param name="ex">Exception à examiner.</param>
        /// <returns>Exception la plus interne.</returns>
        public static System.Exception GetInitialException(this System.Exception ex)
        {
            System.Exception initialException = null;
            while (ex != null)
            {
                initialException = ex;
                ex = ex.InnerException;
            }
            return initialException;
        }

        /// <summary>
        /// Obtient le code d'erreur Win32 correspondant à l'exception actuelle.
        /// </summary>
        /// <param name="ex">Exception.</param>
        /// <returns>Code d'erreur Win32 s'il s'agit d'une exception Win32, <value>null</value> sinon.</returns>
        public static int? GetWin32ErrorCode(this System.Exception ex)
        {
            if (ex is Win32Exception winEx)
                return winEx.ErrorCode;
            if (ex.InnerException == null)
                return null;
            return GetWin32ErrorCode(ex.InnerException);
        }

        #endregion Méthodes publiques
    }
}