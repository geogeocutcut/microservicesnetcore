﻿namespace Smag.Framework.KeyManager
{
    public interface IKeyManager
    {
        MType Key { get; }

        /// <summary>
        /// Get settings based on the key value. Should return null value if not found
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        string Get(string key);
    }
}