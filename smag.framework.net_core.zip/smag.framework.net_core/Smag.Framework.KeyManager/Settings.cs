﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Smag.Framework.KeyManager
{
    public class Settings
    {
        //default configuration manager type to be used if no manager type is specified while getting settings
        private static MType _defaultManagerType;

        //runtime configuration manager type to be used under a runtime environment
        private static MType _runtimeManagerType;

        //a set of available configuration managers to be set during the init
        private static readonly Dictionary<MType, IKeyManager> Managers = new Dictionary<MType, IKeyManager>();

        /// <summary>
        /// During a instantiation of Settings, we set a collection of configuration managers of various types.
        /// We could optionally specify the default configuration manager type to be used if necessary. By default, the WebConfig type will be used.
        /// The same configuration can be specified for runtime configuration manager, with the default type : Azure configuration manager
        /// </summary>
        public static void Instantiate(
            IKeyManager[] keyManagers,
            MType defaultMangerType = MType.WebConfig,
            MType runtimeMangerType = MType.Azure
            )
        {
            //reset the managers collection
            Managers.Clear();

            //add all input configuration managers
            keyManagers?.ToList().ForEach(AddManager);
            _defaultManagerType = defaultMangerType;
            _runtimeManagerType = runtimeMangerType;
        }

        /// <summary>
        /// Get settings by key, based on current running mode (debug/runtime).
        /// </summary>
        /// <param name="key">Key value for configuration</param>
        /// <param name="getWithFallBackStrategy">Indicating in case of "not found" of the given key under the desired configuration manager,
        /// whether we should get settings from the default configuration manger or not (fallback solution).</param>
        /// <returns></returns>
        public static string Get(string key, bool getWithFallBackStrategy = true)
        {
            //we determinate which manager type to use based on the current running mode : debug or runtime
            var managerTypeToUser = System.Diagnostics.Debugger.IsAttached ? _defaultManagerType : _runtimeManagerType;

            return GetWithManagerType(key, managerTypeToUser, getWithFallBackStrategy);
        }

        /// <summary>
        /// Get settings from a desired configuration manager
        /// </summary>
        /// <param name="key">key value of the settings to be fetched</param>
        /// <param name="desiredManagerType">desired configuration manager type to use for fetching settings</param>
        /// <param name="getWithFallBackStrategy">should use a fallback get strategy with the default configuration manager type</param>
        /// <returns></returns>
        public static string GetWithManagerType(string key, MType desiredManagerType, bool getWithFallBackStrategy = true)
        {
            string setting = null;

            if (Managers.ContainsKey(desiredManagerType))
                //if the desired configuration manager type is found, get directly from it
                setting = Managers[desiredManagerType].Get(key);

            if (
                //anyway if no setting has been fetched with the desired manager type, or the desired manager type is not set in Managers collection
                setting == null
                && desiredManagerType != _defaultManagerType
                //but it is allow to use a fallback get (get from the default configuration manager)
                && getWithFallBackStrategy
                )
                //get with the default manager type
                setting = Managers[_defaultManagerType].Get(key);

            return setting;
        }

        private static void AddManager(IKeyManager manager)
        {
            if (manager == null)
                throw new ArgumentNullException(nameof(manager));

            if (Managers.Any(x => x.Key == manager.Key))
                throw new Exception("A configuration manager of the same type has already been added");

            Managers.Add(manager.Key, manager);
        }
    }
}