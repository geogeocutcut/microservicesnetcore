﻿namespace Smag.Framework.KeyManager
{
    public enum MType
    {
        Azure,
        WebConfig,
        Json,
        Xml,
        Database
    };
}