﻿using System.Configuration;

namespace Smag.Framework.KeyManager.ConfigurationManagerImpl
{
    public class LocalConfigurationManager : KeyManager
    {
        private readonly string _configFilePath;

        public LocalConfigurationManager(string configFilePath = null) : base(MType.WebConfig)
        {
            _configFilePath = configFilePath;
        }

        public override string Get(string key)
        {
            //while no specific config file path is specified during the instantiation of the current instance
            //we get by default from the project config file
            if (string.IsNullOrEmpty(_configFilePath))
                return ConfigurationManager.AppSettings[key];

            //otherwise, we try to load and find configurations from the specified config file
            var configFile = ConfigurationManager.OpenMappedExeConfiguration(
                new ExeConfigurationFileMap { ExeConfigFilename = _configFilePath },
                ConfigurationUserLevel.None);

            return configFile.AppSettings.Settings[key].Value;
        }
    }
}