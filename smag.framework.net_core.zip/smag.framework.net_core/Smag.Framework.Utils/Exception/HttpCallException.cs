﻿namespace Smag.Framework.Utils.Exception
{
    public class HttpCallException : System.Exception
    {
        public HttpCallException(string message) : base(message)
        {
        }
    }
}