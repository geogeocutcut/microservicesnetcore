﻿using System.Collections.Generic;

namespace Smag.Framework.Utils.Exception
{
    public class HttpErrorDetail
    {
        public Metadata metadata { get; set; }
        public bool success { get; set; }
        public List<Error> errors { get; set; }

        public class Error
        {
            public string code { get; set; }
            public string message { get; set; }
        }

        public class Metadata
        {
            public string transaction_id { get; set; }
            public int status_code { get; set; }
        }
    }
}
