﻿using System;
using System.Collections.Generic;

namespace Smag.Framework.Utils.HttpClient
{
    /// <summary>
    /// this class is only used for holding a root uri endpoint
    /// a Build method is provide for building a ExecutableSecureHttpClient based on the root uri
    /// </summary>
    public class SecureHttpClientRoot
    {
        private IDictionary<string, string> _headers;
        private readonly string _rootEndPointUri;

        public SecureHttpClientRoot(string rootEndPointUri)
        {
            if (string.IsNullOrEmpty(rootEndPointUri))
                throw new ArgumentException(nameof(rootEndPointUri));

            _rootEndPointUri = rootEndPointUri + (rootEndPointUri.EndsWith("/") ? "" : "/");
        }

        /// <summary>
        /// add headers if necessary
        /// </summary>
        /// <param name="headers"></param>
        /// <returns></returns>
        public SecureHttpClientRoot WithHeaders(IDictionary<string, string> headers)
        {
            _headers = headers;
            return this;
        }

        /// <summary>
        /// build a executable secure http client with the full endpoint and headers if exist
        /// </summary>
        /// <param name="complementUri">the complement uri to add after the root endpoint uri</param>
        /// <returns></returns>
        public ExecutableSecureHttpClient Build(string complementUri = null)
            => new ExecutableSecureHttpClient($"{_rootEndPointUri}{complementUri}", _headers);
    }
}