﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Smag.Framework.Utils.HttpClient
{
    public class ExecutableSecureHttpClient
    {
        //http headers to add for request
        private readonly IDictionary<string, string> _headers;

        //the final uri to call
        private readonly Uri _fullUri;

        public ExecutableSecureHttpClient(string fullUri, IDictionary<string, string> headers = null)
        {
            _headers = headers;
            _fullUri = new Uri(fullUri);
        }

        #region Get

        public async Task<T> GetAsync<T>()
            => JsonConvert.DeserializeObject<T>(await SendGetAsync());

        private async Task<string> SendGetAsync([CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            using (var requestMessage = BuildHttpRequestMessageWithHeaders(HttpMethod.Get, _fullUri))
                return await HttpCallAsync(requestMessage, callerFilePath, callerName, callerLineNumber);
        }

        #endregion Get

        #region Put

        public async Task<T> PutAsync<T>(object obj, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            var content = new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
            return JsonConvert.DeserializeObject<T>(await SendPutAsync(content));
        }

        private async Task<string> SendPutAsync(HttpContent content = null, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            using (var requestMessage = BuildHttpRequestMessageWithHeaders(HttpMethod.Put, _fullUri, content))
                return await HttpCallAsync(requestMessage, callerFilePath, callerName, callerLineNumber);
        }

        #endregion Put

        #region Post

        public async Task<T> PostAsync<T>(object obj, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            var content = new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
            return JsonConvert.DeserializeObject<T>(await SendPostAsync(content));
        }

        public async Task PostAsync(object obj, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            var stringContent = new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
            await SendPostAsync(stringContent);
        }

        private async Task<string> SendPostAsync(HttpContent content = null, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            using (var requestMessage = BuildHttpRequestMessageWithHeaders(HttpMethod.Post, _fullUri, content))
                return await HttpCallAsync(requestMessage, callerFilePath, callerName, callerLineNumber);
        }

        #endregion Post

        #region Delete

        public async Task DeleteAsync()
            => await SendDeleteAsync();

        private async Task<string> SendDeleteAsync([CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            using (var requestMessage = BuildHttpRequestMessageWithHeaders(HttpMethod.Delete, _fullUri))
                return await HttpCallAsync(requestMessage, callerFilePath, callerName, callerLineNumber);
        }

        #endregion Delete

        private static async Task<string> HttpCallAsync(HttpRequestMessage requestMessage, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            //Log.Log.Info($"---{requestMessage.Method.Method} : {requestMessage.RequestUri.AbsoluteUri}---");

            using (var response = await HttpClientFactory.GetClient().SendAsync(requestMessage, default(CancellationToken)))
            {
                if (!response.IsSuccessStatusCode)
                {
                    //Log.Log.Debug($"{requestMessage.Method.Method} : {callerFilePath}, {callerName}, line number : {callerLineNumber} return error status");

                    string errors = string.Empty;
                    string errorContent = response?.Content?.ReadAsStringAsync().Result;
                    Exception.HttpErrorDetail result = null;
                    if (!string.IsNullOrEmpty(errorContent))
                    {
                        try
                        {
                            result = JsonConvert.DeserializeObject<Exception.HttpErrorDetail>(errorContent);
                        }
                        catch
                        {
                            errors = errorContent;
                        }

                        if (result?.errors != null)
                        {
                            foreach (Exception.HttpErrorDetail.Error error in result.errors)
                            {
                                errors += " " + error.message;
                            }
                        }
                    }
#if DEBUG
                    Debugger.Break();
#endif
                    throw new Exception.HttpCallException($"{requestMessage.Method.Method} : {requestMessage.RequestUri.AbsoluteUri}. {(int)response.StatusCode} {response.StatusCode} : {response.ReasonPhrase + " " + errors}");
                }

                return response.Content?.ReadAsStringAsync().Result;
            }
        }

        /// <summary>
        /// build a new httpRequestMessage with headers
        /// </summary>
        private HttpRequestMessage BuildHttpRequestMessageWithHeaders(HttpMethod method, Uri uri, HttpContent content = null)
        {
            var httpRequestMessage = new HttpRequestMessage(method, uri);

            if (_headers != null)
                foreach (var keyValuePair in _headers)
                    httpRequestMessage.Headers.Add(keyValuePair.Key, keyValuePair.Value);

            if ((method == HttpMethod.Post || method == HttpMethod.Put) && content != null)
                httpRequestMessage.Content = content;

            return httpRequestMessage;
        }
    }
}