﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Smag.Framework.Utils.HttpClient
{
    public class HttpHeaderHelper
    {
        private const string CORRELATION_KEY = "X-Correlation-ID";
        private const string SUBSCRIPTION_PRODUCT_KEY = "Ocp-Apim-Subscription-Key";
        private const string OCP_APIM_TRACE = "Ocp-Apim-Trace";
        private const string TOKEN_KEY = "SmagAuthorization";
        private static IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// https://docs.microsoft.com/fr-fr/aspnet/core/fundamentals/http-context?view=aspnetcore-2.1
        /// we need to add into ConfigureServices(IServiceCollection services)
        /// services.AddHttpContextAccessor();
        /// </summary>
        /// <param name="httpContextAccessor"></param>
        public HttpHeaderHelper(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// preparer a dico for http headers
        /// As suggested in the name of this function, it's currently a specific method for adding information such as token and api key, and only for SMAG use cases
        /// </summary>
        public static IDictionary<string, string> BuildSmagHttpHeader(string token = null)
        {
            var headers = new Dictionary<string, string>
            {
                {OCP_APIM_TRACE, "false"}
            };

            //add subscription key
            var resultSub = _httpContextAccessor.HttpContext.Request.Headers[SUBSCRIPTION_PRODUCT_KEY];

            //if (string.IsNullOrEmpty(resultSub))
            //    Log.Log.Info($"ERROR {SUBSCRIPTION_PRODUCT_KEY} NOT FOUND ");
            headers.Add(SUBSCRIPTION_PRODUCT_KEY, resultSub);

            //add token
            if (!string.IsNullOrEmpty(token))
                headers.Add(TOKEN_KEY, $"Bearer {token}");

            //Add Correlation ID : API Manager
            headers.Add(CORRELATION_KEY, GetCorrelationId());

            return headers;
        }

        /// <summary>
        /// Try get correlation id from the input Header, otherwise, generate a new one.
        /// This implementation is inspired by the implementation of the httpRequestMessage.GetCorrelationId() function.
        /// </summary>
        private static string GetCorrelationId()
        {
            _httpContextAccessor.HttpContext.Request.Headers.TryGetValue(CORRELATION_KEY, out var res);

            var id = res.ToArray().First();

            // ReSharper disable once InvertIf
            if (string.IsNullOrEmpty(id))
            {
                var guid = Trace.CorrelationManager.ActivityId;

                if (guid == Guid.Empty)
                    guid = Guid.NewGuid();

                id = guid.ToString();
            }

            return id.ToString();
        }
    }
}