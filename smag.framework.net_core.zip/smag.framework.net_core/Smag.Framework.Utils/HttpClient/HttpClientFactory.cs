﻿using System.Net;

namespace Smag.Framework.Utils.HttpClient
{
    public class HttpClientFactory
    {
        private static volatile System.Net.Http.HttpClient _client;

        private static volatile object _lockObj = new object();

        static HttpClientFactory()
        {
            if (_client == null)
                lock (_lockObj)
                    if (_client == null)
                    {
                        ServicePointManager.SecurityProtocol = ServicePointManager.SecurityProtocol | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                        ServicePointManager.DefaultConnectionLimit = 100;
                        _client = new System.Net.Http.HttpClient();
                    }
        }

        public static System.Net.Http.HttpClient GetClient() => _client;
    }
}