﻿using Smag.Framework.DAL;

namespace Smag.Framework.Data
{
    public interface IDServiceProvider
    {
        IService GetService<IService>(IUnitOfWork uow, IUnitOfWork smagUow = null);
    }
}