﻿using Smag.Framework.Azure.Management.KeyVault;
using System.Collections.Generic;

namespace Smag.Framework.KeyManager.AzureImp
{
    /// <summary>
    /// This class is used for getting settings with Azure KeyVault.
    /// We need to have in the configuration file keys corresponding to the naming convention predefined in ConventionalConfigurationName class :

    /// the following lines are optional, and should be configured based on current context
    /// <add key="PartyData_AzureVaultUrl" value="https://some_azure_key_vault_identicator_url_1/with_a_secret_for_key_vault_1" />
    /// <add key="AppData_AzureVaultUrl" value="https://some_azure_key_vault_identicator_url_2/with_a_secret_for_key_vault_2" />
    /// <add key="PartyOp_AzureVaultUrl" value="https://some_azure_key_vault_identicator_url_3/with_a_secret_for_key_vault_3" />
    /// <add key="AppOp_AzureVaultUrl" value="https://some_azure_key_vault_identicator_url_4/with_a_secret_for_key_vault_4" />
    /// </summary>
    public class AzureKeyManager : KeyManager
    {
        private static readonly Dictionary<string, string> VaultKeys = new Dictionary<string, string>();

        public AzureKeyManager() : base(MType.Azure)
        {
        }

        public override string Get(string key)
        {
            lock (VaultKeys) //lock before read
            {
                if (!VaultKeys.ContainsKey(key))
                    lock (VaultKeys)//lock before write
                    {
                        //build the conventional configuration key name for Azure configurations, with predefined naming convention
                        var azureVaultUrlKeyName = ConventionalNameHelper.GetAzureConventionalConfigurationName(key);
                        var azureVaultUrl = Settings.GetWithManagerType(azureVaultUrlKeyName, MType.WebConfig);

                        //just call azure manager to get secret value
                        VaultKeys[key] = string.IsNullOrEmpty(azureVaultUrl) ? null : AzureKeyVaultManager.GetSecret(azureVaultUrl);
                    }

                return VaultKeys[key];
            }
        }
    }
}