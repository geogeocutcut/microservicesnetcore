﻿namespace Smag.Framework.Configuration
{
    /// <summary>
    /// Une application Jarvis.
    /// </summary>
    public class OAuthClient
    {
        /// <summary>
        /// Nom de la clé, passée dans les en-têtes HTTP, contenant l'authentification. ("Bearer ######")
        /// </summary>
        public string AuthorizationHeaderKey { get; set; }

        /// <summary>
        /// Identifiant de l'application.
        /// </summary>
        public string ClientId { get; set; }

        /// <summary>
        /// Nom du serveur fournissant les JWT (JSON Web Token).
        /// </summary>
        public string Issuer { get; set; }

        /// <summary>
        /// Mot de passe associé dans la base de données JarvisAuthenticate.
        /// </summary>
        public byte[] Secret
        {
            get; set;
        }
    }
}