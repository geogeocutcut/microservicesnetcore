﻿using System.Runtime.Serialization;

// ReSharper disable once CheckNamespace
namespace Smag.Framework.DAL
{
    public class DALException : System.Exception, ISerializable
    {
        public DALException()
        { }

        public DALException(string message) : base(message)
        { }

        public DALException(string message, System.Exception innerException) : base(message, innerException)
        { }

        protected DALException(SerializationInfo info, StreamingContext context) : base(info, context)
        { }
    }
}