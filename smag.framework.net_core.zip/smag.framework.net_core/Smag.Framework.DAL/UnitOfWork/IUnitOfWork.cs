﻿namespace Smag.Framework.DAL
{
    public interface IUnitOfWork
    {
        ITransaction Begin();

        void Commit();

        void Rollback();

        TRepository GetRepository<TRepository>();
    }
}