﻿using Microsoft.AspNetCore.Http;
using Smag.Framework.DAL.NHImpl;
using System.Threading.Tasks;

namespace Smag.Framework.Services.Middleware
{
    public class NHibernateResourceDisposeMiddleware
    {
        private readonly RequestDelegate _next;

        public NHibernateResourceDisposeMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next.Invoke(context);

                //if session exists
                if (NHConnectionManager.HasSession())
                {
                    var trans = NHConnectionManager.GetCurrentSession().Transaction;

                    if (trans != null && trans.IsActive)
                        trans.Commit();
                }

                NHConnectionManager.DisposeCurrentSession();
            }
            catch (System.Exception ex)
            {
                if (NHConnectionManager.HasSession())
                {
                    var trans = NHConnectionManager.GetCurrentSession().Transaction;

                    if (trans != null && trans.IsActive)
                        trans.Rollback();
                }

                NHConnectionManager.DisposeCurrentSession();

                throw;
            }
        }
    }
}