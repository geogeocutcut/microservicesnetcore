﻿using System;
using System.Linq;

namespace Smag.Framework.Services.OData
{
    public class ODataServiceRouteMap
    {
        internal string RouteName { get; }
        internal string RoutePrefix { get; }
        internal Type[] EntityTypesToExpose { get; }

        public ODataServiceRouteMap(Type[] entityTypesToExpose, string routeName = "odata", string routePrefix = null)
        {
            if (entityTypesToExpose == null || !entityTypesToExpose.Any())
                throw new ArgumentException(nameof(entityTypesToExpose));

            EntityTypesToExpose = entityTypesToExpose;
            RouteName = routeName;
            RoutePrefix = routePrefix;
        }
    }
}