﻿using Humanizer;

// ReSharper disable once CheckNamespace
namespace System
{
    public static class StringHelper
    {
        //https://stackoverflow.com/questions/18781027/regex-camel-case-to-underscore-ignore-first-occurrence
        public static string ToSnakeCase(this string s)
        {
            return Text.RegularExpressions.Regex.Replace(
                s,
                "(?<=.)([A-Z])",
                "_$0",
                Text.RegularExpressions.RegexOptions.Compiled).ToLowerInvariant();
        }

        public static string ToSmagControllerName(this string s) => s.ToSnakeCase().Pluralize();
    }
}