﻿using Microsoft.AspNet.OData.Builder;
using Microsoft.AspNet.OData.Extensions;
using Microsoft.OData.Edm;
using Smag.Framework.Services.OData;
using System;
using System.Collections.Generic;
using System.Linq;

// ReSharper disable once CheckNamespace
namespace Microsoft.AspNetCore.Routing
{
    public static class RouteBuilderExtension
    {
        /// <summary>
        /// This function build and expose a set of entities.
        /// Comparing to the previous function : public static void ODataConfig(this IRouteBuilder routeBuilder, ODataServiceRouteMap map)
        /// This one takes "ODataServiceRouteMap[] maps" as input.
        /// This is used when we want to preparer different odata domains (based on different routePrefix), in order to expose different things
        /// how to use :
        /// in Startup.cs
        /// public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        /// {
        ///     ...
        ///     app.UseMvc(b => b.ODataConfig(new ODataServiceRouteMap( my_entityTypeArrayToExpose[] )));
        /// }
        /// </summary>
        public static void ODataConfig(this IRouteBuilder routeBuilder, ODataServiceRouteMap[] maps)
        {
            if (maps == null || !maps.Any())
                throw new ArgumentException(nameof(maps));

            SetAuthorizedOperations(routeBuilder);

            foreach (var map in maps)
            {
                routeBuilder.MapODataServiceRoute(
                    routeName: map.RouteName,
                    routePrefix: map.RoutePrefix,
                    model: GetEdmModel(map.EntityTypesToExpose));
            }
        }

        /// <summary>
        /// set default allowed odata operations
        /// </summary>
        /// <param name="routeBuilder"></param>
        private static void SetAuthorizedOperations(IRouteBuilder routeBuilder)
            => routeBuilder.Select().Expand().Filter().OrderBy().MaxTop(20).Count();

        /// <summary>
        /// build and return an Odata model based on the input types to expose
        /// </summary>
        private static IEdmModel GetEdmModel(IEnumerable<Type> entitySets)
        {
            var builder = new ODataConventionModelBuilder();

            //expose all entity sets
            foreach (var entitySet in entitySets)
                builder.AddEntitySet(entitySet.Name.ToSmagControllerName(), builder.AddEntityType(entitySet));

            //update naming convention
            builder.OnModelCreating += conventionModelBuilder =>
                conventionModelBuilder.StructuralTypes.ToList().ForEach(t =>
                    t.Properties.ToList().ForEach(p => p.Name = p.Name.ToSnakeCase()));

            //build and return model
            return builder.GetEdmModel();
        }
    }
}