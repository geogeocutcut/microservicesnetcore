﻿using Microsoft.AspNet.OData.Extensions;
using Microsoft.AspNetCore.Mvc;
using Smag.Framework.Services.OData.NamingConvention;

// ReSharper disable once CheckNamespace
namespace Microsoft.Extensions.DependencyInjection
{
    public static class ServiceCollectionExtension
    {
        /// <summary>
        /// how to use :
        /// in Startup.cs :
        /// public void ConfigureServices(IServiceCollection services)
        /// {
        ///     ...
        ///     services.EnableOData();
        /// }
        /// </summary>
        public static IServiceCollection EnableOData(this IServiceCollection services)
        {
            //enable odata
            services.AddOData();

            services
                //add smag controller/action naming convention for rewriting dynamically controller/action names
                .AddMvc(op =>
                {
                    op.Conventions.Add(new SmagODataControllerNamingConvention());
                    op.Conventions.Add(new SmagODataActionNamingConvention());
                })
                .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            return services;
        }
    }
}