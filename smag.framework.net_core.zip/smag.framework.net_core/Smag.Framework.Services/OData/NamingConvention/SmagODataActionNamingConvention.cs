﻿using Microsoft.AspNetCore.Mvc.ApplicationModels;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Smag.Framework.Services.OData.NamingConvention
{
    /// <summary>
    /// Apply naming convention designed by SMAG for actions in each ctrl :
    /// - action name : [HttpVerb]CamelCase
    /// - url navigation property name : snake_case => need to change action name to [HttpVerb]snake_case
    /// </summary>
    public class SmagODataActionNamingConvention : IActionModelConvention
    {
        //some exceptional odata action names to keep
        private static readonly IEnumerable<string> ExceptionActionNames = new[] {
            "GetMetadata",
            "GetServiceDocument"
        };

        public void Apply(ActionModel action)
        {
            var actionName = action.ActionName;

            if (ExceptionActionNames.Contains(actionName))
                return;

            //currently, we just rewrite the Get action name
            //to be completed if necessary
            if (actionName.StartsWith("Get") && actionName.Length > "Get".Length)
                action.ActionName = $"Get{actionName.Substring(3).ToSnakeCase()}";
        }
    }
}