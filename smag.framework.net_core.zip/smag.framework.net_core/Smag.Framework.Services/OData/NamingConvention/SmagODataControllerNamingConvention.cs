﻿using Microsoft.AspNet.OData;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using System;

namespace Smag.Framework.Services.OData.NamingConvention
{
    /// <summary>
    /// Apply naming convention designed by SMAG for controllers :
    /// - controller name : CamelCase[Controller]
    /// - url name : snake_case => need to change ctrl name to snake_case[Controller]
    /// </summary>
    public class SmagODataControllerNamingConvention : IControllerModelConvention
    {
        private const string MetadataODataControllerName = "Metadata";

        public void Apply(ControllerModel controller)
        {
            //odata will add an odata ctrl named Metadata, used for exposing odata meta data schema
            //this route should be kept as it is without applying naming convention
            if (controller.ControllerName == MetadataODataControllerName) return;

            //for other controllers, if it's an odata controller
            var isODataController = typeof(ODataController).IsAssignableFrom(controller.ControllerType);

            if (isODataController)
                //apply controller naming convention
                controller.ControllerName = controller.ControllerName.ToSnakeCase();
        }
    }
}