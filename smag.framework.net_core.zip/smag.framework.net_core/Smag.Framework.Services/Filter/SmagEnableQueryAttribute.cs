﻿using Microsoft.AspNetCore.Http.Internal;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Primitives;
using System;
using System.Collections.Generic;
using System.Linq;

// ReSharper disable once CheckNamespace
namespace Microsoft.AspNet.OData
{
    [AttributeUsage(AttributeTargets.Class)]
    public class SmagEnableQueryAttribute : EnableQueryAttribute
    {
        public override void OnActionExecuted(ActionExecutedContext actionExecutedContext)
        {
            var request = actionExecutedContext.HttpContext.Request;

            //todo
            //request.Query = new QueryCollection(request.Query
            //    .Select(x => new
            //    {
            //        x.Key,
            //        Value = string.Equals(x.Key, "$select", StringComparison.InvariantCultureIgnoreCase)
            //            ? OverrideSelectQuery(x.Value.ToArray())
            //            : x.Value
            //    })
            //    .ToDictionary(x => x.Key, x => x.Value));

            base.OnActionExecuted(actionExecutedContext);
        }

        private static StringValues OverrideSelectQuery(Type entityType, string[] selectProperties)
        {
            if (entityType == null) throw new ArgumentNullException(nameof(entityType));
            if (selectProperties == null || !selectProperties.Any()) throw new ArgumentException(nameof(selectProperties));

            var res = new List<string>();

            //get custom attributs in order to determinate all allowed properties to be selected
            var allAllowedProperties = GetAllAllowedPropertyNames(entityType);

            if (allAllowedProperties == null || !allAllowedProperties.Any())
            {
                //todo
                //type is not allowed for user
                throw new NotImplementedException();
            }

            //filter selectProperties
            res = selectProperties.Where(x => allAllowedProperties.Contains(x)).ToList();

            if (!res.Any())//todo
                //type is not allowed for user
                throw new NotImplementedException();

            return new StringValues(string.Join(',', res));
        }

        private static string[] GetAllAllowedPropertyNames(Type entityType)
        {
            throw new NotImplementedException();
        }
    }
}