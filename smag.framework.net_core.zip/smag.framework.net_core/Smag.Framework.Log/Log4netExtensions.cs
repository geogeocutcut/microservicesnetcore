﻿using Smag.Framework.Log;

// ReSharper disable once CheckNamespace
namespace Microsoft.Extensions.Logging
{
    /// <summary>
    /// how to use :
    /// first of all, preparer your log4net.config file somewhere
    /// in Startup.cs
    /// public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
    /// {
    ///     ...
    ///     //loggerFactory.AddLog4Net("my log4net config file path");
    ///     loggerFactory.AddLog4Net();
    /// }
    /// </summary>
    // ReSharper disable once InconsistentNaming
    public static class Log4netExtensions
    {
        private const string DefaultConfigName = "log4net.config";

        public static ILoggerFactory AddLog4Net(this ILoggerFactory factory, string log4NetConfigFile = DefaultConfigName)
        {
            factory.AddProvider(new Log4NetProvider(log4NetConfigFile));
            return factory;
        }
    }
}