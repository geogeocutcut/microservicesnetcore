﻿using FluentNHibernate.Cfg;
using NHibernate;
using NHibernate.Context;

namespace Smag.Framework.DAL.NHImpl
{
    // ReSharper disable once InconsistentNaming
    public class NHConnectionManager
    {
        private static volatile ISessionFactory _sessionFactory;
        private static volatile object _lockObj = new object();

        public static ISessionFactory GetSessionFactory() => _sessionFactory;

        static NHConnectionManager()
        {
            if (_sessionFactory == null)
                lock (_lockObj)
                    if (_sessionFactory == null)
                        _sessionFactory = Fluently.Configure(new NHibernate.Cfg.Configuration().Configure())
                            .BuildSessionFactory();
        }

        public static bool HasSession() => CurrentSessionContext.HasBind(_sessionFactory);

        public static ISession GetCurrentSession()
        {
            if (!CurrentSessionContext.HasBind(_sessionFactory))
                CurrentSessionContext.Bind(_sessionFactory.OpenSession());

            return _sessionFactory.GetCurrentSession();
        }

        public static void DisposeCurrentSession()
        {
            var currentSession = CurrentSessionContext.Unbind(_sessionFactory);
            currentSession?.Transaction.Dispose();
        }
    }
}