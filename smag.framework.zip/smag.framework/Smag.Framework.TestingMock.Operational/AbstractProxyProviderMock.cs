﻿using Newtonsoft.Json;
using Smag.Framework.DAL;
using Smag.Framework.DAL.UnitOfWork;
using Smag.Framework.Operational;
using System;

namespace Smag.Framework.TestingMock.Operational
{
    public abstract class AbstractProxyProviderMock<TDataBase> : IOProxyProvider
    {
        private TDataBase _databaseSystem;

        public TDataBase Db { get; set; }
        private string jsonDB = "";


        private bool _isOpen;

        public bool TransactionOpen
        {
            get
            {
                return _isOpen;
            }

            set
            {
                throw new NotImplementedException();
            }
        }
        public AbstractProxyProviderMock(TDataBase database)
        {
            _databaseSystem = database;
            Db = database;
        }
        public void Commit()
        {
            if (_isOpen)
            {
                jsonDB = JsonConvert.SerializeObject(Db);

                if (string.IsNullOrEmpty(jsonDB))
                    throw new Exception("Erreur dans la DALContext de TU : La BDD de TU est mal serializée.");

                _isOpen = false;
            }
            else
                throw new Exception("Erreur dans la DALContext de TU : La transaction n'est pas ouverte.");

        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }

        public ITransaction Begin()
        {
            if (Db == null) // Si la base est nulle, on désérialize depuis le fichier JSON
                Db = _databaseSystem;

            _isOpen = true;

            return null;

        }

        public void Rollback()
        {
            if (_isOpen)
            {
                Db = _databaseSystem;
            }
            else
                throw new Exception("Impossible de rollback une transaction qui n'a pas été ouverte.");

            _isOpen = false;
        }

        public TProxy GetProxy<TProxy>(string name = "") where TProxy : class
        {
            throw new NotImplementedException();
        }
    }
}
