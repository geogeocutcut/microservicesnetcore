﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smag.Framework.TestingMock.Operational
{
    public abstract class BaseStore
    {

        public static IStoreInMemory Initialize<T>()
        {
            T instance = Activator.CreateInstance<T>();
            return ((IStoreInMemory)instance).Get();
        }
    }
}
