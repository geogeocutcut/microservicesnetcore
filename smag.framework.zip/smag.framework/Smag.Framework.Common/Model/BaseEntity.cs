﻿

using System;

namespace Smag.Framework.Common.Model
{
    public abstract class BaseEntity<TId>
    {
        public virtual TId Id { get; set; }
        public virtual string UniqueIdentifier { get; set; } = Guid.NewGuid().ToString();
    }
}
