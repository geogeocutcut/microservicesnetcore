﻿using System;

namespace Smag.Framework.Common.Model
{
    public abstract class AvailableEntity<TId> : BaseEntity<TId>
    {

	
        public virtual DateTime? FromDate { get; set; }
        public virtual DateTime? ThruDate { get; set; }

    }
}
