﻿using Smag.Framework.Common.Extensions;



namespace Smag.Framework.Common.Model
{



    public abstract class EnumeratedAuditableEntity<E, TId> : AuditableEntity<TId>
        where E : struct
    {

        /// <summary>
        /// Code.
        /// </summary>
        public virtual string Code { get; set; }

        /// <summary>
        /// Renvoie la valeur énumérée correspondante au code de l'instance actuelle.
        /// </summary>
        /// <returns>Valeur énumérée correspondant au code, ou <value>null</value> si aucune valeur ne correspond.</returns>
        public virtual E? Value
        {
            get
            {
                return EnumExtensions.FromCode<E>(Code);
            }
        }

    }   // public abstract class EnumeratedAuditableEntity<E>



}   // namespace Smag.Framework.Common.Model
