﻿using System;

namespace Smag.Framework.Common.Exceptions
{
    public class HttpCallException : Exception
    {
        private string _error;

        public string Error
        {
            get
            {
                return _error;
            }
        }

        public HttpCallException(string error, string message) : base(message)
        {
            _error = error;
        }
    }
}