﻿using System;
using System.Threading;



namespace Smag.Framework.Common.Maths
{



    /// <summary>
    /// Générateur de nombres aléatoires.
    /// </summary>
    /// <remarks>Cette classe est thread-safe.</remarks>
    public static class RandomNumber
    {

        #region Variables statiques

        /// <summary>
        /// Verrou pour le multithreading.
        /// </summary>
        private static readonly object s_lock = new object();

        /// <summary>
        /// Permet d'initialiser les générateurs de nombres aléatoires de chaque thread.
        /// </summary>
        private static readonly Random s_seedGenerator = new Random();

        /// <summary>
        /// Générateur de nombres aléatoires pour un thread.
        /// </summary>
        private static readonly ThreadLocal<Random> s_threadedRandom = new ThreadLocal<Random>(GenerateNewRandom);

        #endregion

        #region Méthodes statiques privées

        /// <summary>
        /// Crée un générateur de nombre aléatoires pour le thread actuel.
        /// </summary>
        /// <returns></returns>
        private static Random GenerateNewRandom()
        {
            lock (s_lock)
            {
                return new Random(s_seedGenerator.Next());
            }
        }

        #endregion

        #region Méthodes statiques publiques

        /// <summary>
        /// Génère un nombre décimal aléatoire compris entre 0 et <paramref name="maxValue"/>. (inclus)
        /// </summary>
        /// <param name="maxValue">Valeur maximale.</param>
        /// <param name="digits">Nombre de chiffres après la virgule. Si &lt;0 alors la valeur retournée ne sera pas arrondie.</param>
        /// <returns>Un nombre décimal aléatoire compris entre 0 et <paramref name="maxValue"/> (inclus).</returns>
        public static double Get(double maxValue, int digits = -1)
        {
            return Get(0.0, maxValue, digits);
        }

        /// <summary>
        /// Génère un nombre décimal aléatoire compris entre <paramref name="minValue"/> et <paramref name="maxValue"/>. (inclus)
        /// </summary>
        /// <param name="minValue">Valeur minimale.</param>
        /// <param name="maxValue">Valeur maximale.</param>
        /// <param name="digits">Nombre de chiffres après la virgule. Si &lt;0 alors la valeur retournée ne sera pas arrondie.</param>
        /// <returns>Un nombre aléatoire compris entre <paramref name="minValue"/> et <paramref name="maxValue"/> (inclus).</returns>
        public static double Get(double minValue, double maxValue, int digits = -1)
        {
            double rnd = s_threadedRandom.Value.NextDouble();   // rnd € [0, 0.99999999999999978].
            rnd = Math.Min(rnd * 1.0000000000001, 1.0);
            rnd *= (maxValue - minValue);
            rnd += minValue;
            if (digits < 0)
                return rnd;
            return Math.Round(rnd, digits);
        }

        /// <summary>
        /// Génère un nombre entier aléatoire compris entre 0 et <paramref name="maxValue"/>. (inclus)
        /// </summary>
        /// <param name="maxValue">Valeur maximale.</param>
        /// <returns>Un nombre entier aléatoire compris entre 0 et <paramref name="maxValue"/> (inclus).</returns>
        public static int Get(int maxValue)
        {
            return Get(0, maxValue);
        }

        /// <summary>
        /// Génère un nombre entier aléatoire compris entre <paramref name="minValue"/> et <paramref name="maxValue"/>. (inclus)
        /// </summary>
        /// <param name="minValue">Valeur minimale.</param>
        /// <param name="maxValue">Valeur maximale.</param>
        /// <returns>Un nombre entier aléatoire compris entre <paramref name="minValue"/> et <paramref name="maxValue"/> (inclus).</returns>
        public static int Get(int minValue, int maxValue)
        {
            if (maxValue == Int32.MaxValue)
                return s_threadedRandom.Value.Next(minValue, maxValue);
            else
                return s_threadedRandom.Value.Next(minValue, maxValue + 1);
        }

        #endregion

    }



}
