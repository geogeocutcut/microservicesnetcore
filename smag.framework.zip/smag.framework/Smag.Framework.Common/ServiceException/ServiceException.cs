﻿using System;

namespace Smag.Framework.Common
{
    public class ServiceException : Exception
    {

        public string Error;
        

        public ServiceException(string error,string message):base(message)
        {
            Error = error;
        }
    }
}
