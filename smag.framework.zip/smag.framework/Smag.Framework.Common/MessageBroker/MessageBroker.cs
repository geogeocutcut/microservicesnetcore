﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smag.Framework.Common.MessageBroker
{
    public class MessageBroker
    {
        private static MessageBroker _instance;
        private static object syncRoot = new Object();
        private readonly Dictionary<string, List<Delegate>> _subscribers;
        public static MessageBroker Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new MessageBroker();
                return _instance;
            }
        }
        private MessageBroker()
        {
            _subscribers = new Dictionary<string, List<Delegate>>();
        }

        public void Publish<T>(string queue, T obj)
        {
            if (obj == null || String.IsNullOrEmpty(queue))
                return;
            if (!_subscribers.ContainsKey(queue))
            {
                return;
            }
            var delegates = _subscribers[queue];
            if (delegates == null || delegates.Count == 0) return;
            foreach (var handler in delegates.Select
            (item => item as Action<T>))
            {
                Task.Factory.StartNew(() => handler?.Invoke(obj));
            }
        }

        

        public void Subscribe<T>(Action<T> action, string queue)
        {
            var delegates = _subscribers.ContainsKey(queue) ?
                            _subscribers[queue] : new List<Delegate>();
            if (!delegates.Contains(action))
            {
                delegates.Add(action);
            }
            _subscribers[queue] = delegates;
        }



        public void Unsubscribe<T>(Action<T> action, string queue)
        {
            if (!_subscribers.ContainsKey(queue)) return;
            var delegates = _subscribers[queue];
            if (delegates.Contains(action))
                delegates.Remove(action);
            if (delegates.Count == 0)
                _subscribers.Remove(queue);
        }



        public void Dispose()
        {
            _subscribers?.Clear();
        }
    }
}
