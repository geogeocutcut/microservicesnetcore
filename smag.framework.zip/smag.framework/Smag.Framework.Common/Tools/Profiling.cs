﻿#define PROFILING_ENABLED

#if PROFILING_ENABLED
//#define INCLUDE_CALLER_NAMESPACE
//#define INCLUDE_CALLER_PARAMETERS
#define MEASURE_PERFORMANCES_IN_MS
//#define MEASURE_PERFORMANCES_IN_TICKS_STOPWATCH
//#define MEASURE_PERFORMANCES_IN_TICKS_WIN32
#endif

using Smag.Framework.Common.Logs;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;



namespace Smag.Framework.Common.Tools
{



    /// <summary>
    /// Comptabilise le nombre d'appels et le temps écoulé, en ticks ou en millisecondes.
    /// </summary>
    /// <example>
    /// using (var profiling = new Profiling())
    /// {
    ///     .. code à chronométrer ..
    /// }
    /// </example>
    /// <remarks>
    /// 1) Décommenter l'un des <code>#define MEASURE_PERFORMANCES_IN_..</code> au début de ce fichier afin de sélectionner le mode de calcul :
    ///     a) MEASURE_PERFORMANCES_IN_MS               : Calcule le temps écoulé en millisecondes.
    ///     b) MEASURE_PERFORMANCES_IN_TICKS_STOPWATCH  : Calcule le temps écoulé en cycles CPU, à l'aide d'un StopWatch C#.
    ///     c) MEASURE_PERFORMANCES_IN_TICKS_WIN32      : Calcule le temps écoulé en cycles CPU, à l'aide des méthodes Win32 QueryPerformance* définies dans 'kernel32.dll'.
    ///   Si tous les #define sont commentés, aucune mesure de performances ne sera faite.
    ///   
    /// 2) Afin d'afficher le résultat final, appelez l'une des méthodes statiques <see cref="LogStatistics(Level)"/> (log classique, envoyé éventuellement au Monitoring), <see cref="PrintStatistics"/> (log dans la Console) ou <see cref="TraceStatistics"/> (log dans la trace de Visual Studio).
    /// 3) Appelez la méthode statique <see cref="ClearStatistics"/>  lorsque vous voulez remettre à zéro les statistiques.
    /// </remarks>
    public class Profiling : IDisposable
    {

        #region Types

#if MEASURE_PERFORMANCES_IN_MS

        private class Stats
        {

            /// <summary>
            /// Temps moyen écoulé en millisecondes.
            /// </summary>
            public double AverageElapsedMilliseconds
            {
                get
                {
                    if (Count > 0L)
                        return TotalElapsedMilliseconds / (double)Count;
                    return -1.0;
                }
            }

            /// <summary>
            /// Indique comment le temps moyen doit être interprété.
            /// </summary>
            public Impact AverageSeverity
            {
                get
                {
                    double avg = AverageElapsedMilliseconds;
                    if (avg < 250.0)
                        return Impact.Low;
                    else if (avg < 1000.0)
                        return Impact.Medium;
                    else
                        return Impact.High;
                }
            }

            /// <summary>
            /// Nombre total d'appels effectués.
            /// </summary>
            public UInt64 Count;

            /// <summary>
            /// Temps total écoulé en millisecondes.
            /// </summary>
            public double TotalElapsedMilliseconds;

        }

#elif MEASURE_PERFORMANCES_IN_TICKS_STOPWATCH || MEASURE_PERFORMANCES_IN_TICKS_WIN32

        private class Stats
        {

            /// <summary>
            /// Temps moyen écoulé en millisecondes.
            /// </summary>
            public decimal AverageElapsedMilliseconds
            {
                get
                {
                    decimal avg = AverageElapsedTicks;
                    UInt64 frequency = Profiling.TicksPerSecond;
                    if (avg < 0m || frequency <= 1L)
                        return -1m;
                    return avg * 1000m / (decimal)frequency;
                }
            }

            /// <summary>
            /// Temps moyen écoulé en ticks.
            /// </summary>
            public decimal AverageElapsedTicks
            {
                get
                {
                    if (Count > 0L)
                        return (decimal)TotalElapsedTicks / (decimal)Count;
                    return -1m;
                }
            }

            /// <summary>
            /// Indique comment le temps moyen doit être interprété.
            /// </summary>
            public Impact AverageSeverity
            {
                get
                {
                    decimal avg = AverageElapsedMilliseconds;
                    if (avg < 250m)
                        return Impact.Low;
                    else if (avg < 1000m)
                        return Impact.Medium;
                    else
                        return Impact.High;
                }
            }

            /// <summary>
            /// Nombre total d'appels effectués.
            /// </summary>
            public UInt64 Count;

            /// <summary>
            /// Temps total écoulé en ticks.
            /// </summary>
            public UInt64 TotalElapsedTicks;

        }

#else

        private class Stats
        {
        }

#endif

#if MEASURE_PERFORMANCES_IN_TICKS_WIN32
        /// <summary>
        /// Récupère le nombre de cycles écoulés depuis que la machine est allumée.
        /// </summary>
        /// <param name="performanceCount">Nombre de cycles écoulés depuis l'allumage de l'ordinateur.</param>
        /// <returns><value>true</value> si l'opération a réussi, <value>false</value> sinon.</returns>
        [DllImport("kernel32.dll", SetLastError = true), SuppressUnmanagedCodeSecurity]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool QueryPerformanceCounter(out long performanceCount);
#endif

#if MEASURE_PERFORMANCES_IN_TICKS_STOPWATCH || MEASURE_PERFORMANCES_IN_TICKS_WIN32
        /// <summary>
        /// Obtient la fréquence du processeur de comptage de cycles.
        /// </summary>
        /// <param name="frequency">Fréquence, en Hz, du processeur de comptage de cycles.</param>
        /// <returns><value>true</value> si l'opération a réussi, <value>false</value> sinon.</returns>
        /// <remarks>Cette fréquence est fixée au démarrage de l'ordinateur et est constante quelques soient les cores.</remarks>
        [DllImport("kernel32.dll", SetLastError = true), SuppressUnmanagedCodeSecurity]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool QueryPerformanceFrequency(out long frequency);
#endif

        #endregion

        #region Variables statiques

#if PROFILING_ENABLED
#if MEASURE_PERFORMANCES_IN_MS || MEASURE_PERFORMANCES_IN_TICKS_STOPWATCH || MEASURE_PERFORMANCES_IN_TICKS_WIN32

        /// <summary>
        /// Permet de gérer les sections critiques.
        /// </summary>
        private static object s_lock = new object();

        /// <summary>
        /// Statistiques.
        /// </summary>
        private static Dictionary<string, Stats> s_stats = new Dictionary<string, Stats>();

#endif
#endif

        #endregion

        #region Variables membres

#if PROFILING_ENABLED
#if MEASURE_PERFORMANCES_IN_MS || MEASURE_PERFORMANCES_IN_TICKS_STOPWATCH

        /// <summary>
        /// Permet de comptabiliser le temps écoulé.
        /// </summary>
        private Stopwatch m_watch;

#elif MEASURE_PERFORMANCES_IN_TICKS_WIN32

        /// <summary>
        /// Valeur du compteur de cycles au démarrage.
        /// </summary>
        private long m_startingCounter;

#endif
#endif

        #endregion

        #region Constructeurs / Destructeur

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="name">Nom.</param>
        public Profiling(string name = null)
        {
#if PROFILING_ENABLED
            Name = name;
            if (string.IsNullOrEmpty(Name))
            {
                StackFrame frame = new StackFrame(1);
                var caller = frame.GetMethod();
#if INCLUDE_CALLER_NAMESPACE
                string type = caller.DeclaringType.FullName;
#else
                string type = caller.DeclaringType.Name;
#endif
                string methodName = caller.Name;
#if INCLUDE_CALLER_PARAMETERS
                string parameters = string.Join(", ", caller.GetParameters().Select(p => p.ToString()));
#else
                string parameters = (caller.GetParameters().Count() > 0) ? ".." : "";
#endif
                Name = type + "." + methodName + "(" + parameters + ")";
            }
#if MEASURE_PERFORMANCES_IN_MS || MEASURE_PERFORMANCES_IN_TICKS_STOPWATCH
            m_watch = new Stopwatch();
            m_watch.Start();
#elif MEASURE_PERFORMANCES_IN_TICKS_WIN32
            long count = -1L;
            if (QueryPerformanceCounter(out count))
                m_startingCounter = count;
#endif
#endif
        }

        /// <summary>
        /// Appelé à la "destruction" de l'objet actuel.
        /// Met à jour les statistiques.
        /// </summary>
        public void Dispose()
        {
#if PROFILING_ENABLED
#if MEASURE_PERFORMANCES_IN_MS
            m_watch.Stop();
            lock (s_lock)
            {
                if (!string.IsNullOrEmpty(Name))
                {
                    lock (s_lock)
                    {
                        Stats stats = null;
                        if (s_stats.TryGetValue(Name, out stats))
                        {
                            ++stats.Count;
                            stats.TotalElapsedMilliseconds += m_watch.ElapsedMilliseconds;
                            s_stats[Name] = stats;
                        }
                        else
                        {
                            s_stats.Add(Name, new Stats
                            {
                                Count = 1,
                                TotalElapsedMilliseconds = m_watch.ElapsedMilliseconds
                            });
                        }
                    }
                }
            }
#elif MEASURE_PERFORMANCES_IN_TICKS_STOPWATCH
            m_watch.Stop();
            if (!string.IsNullOrEmpty(Name))
            {
                lock (s_lock)
                {
                    Stats stats = null;
                    if (s_stats.TryGetValue(Name, out stats))
                    {
                        ++stats.Count;
                        stats.TotalElapsedTicks += (UInt64)m_watch.ElapsedTicks;
                        s_stats[Name] = stats;
                    }
                    else
                    {
                        s_stats.Add(Name, new Stats
                        {
                            Count = 1,
                            TotalElapsedTicks = (UInt64)m_watch.ElapsedTicks
                        });
                    }
                }
            }
#elif MEASURE_PERFORMANCES_IN_TICKS_WIN32
            long endingCounter = -1L;
            if (QueryPerformanceCounter(out endingCounter) && m_startingCounter > 0L && !string.IsNullOrEmpty(Name))
            {
                lock (s_lock)
                {
                    Stats stats = null;
                    if (s_stats.TryGetValue(Name, out stats))
                    {
                        ++stats.Count;
                        stats.TotalElapsedTicks += (UInt64)(endingCounter - m_startingCounter);
                        s_stats[Name] = stats;
                    }
                    else
                    {
                        s_stats.Add(Name, new Stats
                        {
                            Count = 1,
                            TotalElapsedTicks = (UInt64)(endingCounter - m_startingCounter)
                        });
                    }
                }
            }
#endif
#endif
        }

        #endregion

        #region Propriétés

#if PROFILING_ENABLED
        /// <summary>
        /// Nom.
        /// </summary>
        public string Name
        {
            get;
            private set;
        }
#endif

        #endregion

        #region Propriétés statitiques

        /// <summary>
        /// Détermine si le profiling est activé.
        /// </summary>
        public static bool IsEnabled
        {
            get
            {
#if PROFILING_ENABLED
                return true;
#else
                return false;
#endif
            }
        }

#if MEASURE_PERFORMANCES_IN_TICKS_STOPWATCH || MEASURE_PERFORMANCES_IN_TICKS_WIN32
        public static UInt64 TicksPerSecond
        {
            get
            {
                long frequency = -1L;
                if (QueryPerformanceFrequency(out frequency))
                    return (UInt64)frequency;
                return 0L;
            }
        }
#endif

        #endregion

        #region Méthodes statiques privées

        /// <summary>
        /// Convertit la sévérité du temps moyen sous forme de texte.
        /// </summary>
        /// <param name="severity">Sévérité du temps moyen par appel.</param>
        /// <param name="html">Indique si les textes renvoyés sont au format HTML (si <value>true</value>), ou au format TEXTE (si <value>false</value>).</param>
        /// <param name="logo">Texte représentant la sévérité.</param>
        /// <param name="valStart">Texte à placer avant les valeurs.</param>
        /// <param name="valEnd">Texte à placer après les valeurs.</param>
        private static void ToText(Impact? severity, bool html, out string logo, out string valStart, out string valEnd)
        {
            string backgroundColor, color, text;
            switch (severity)
            {
                case Impact.High:
                    backgroundColor = "#ffe8e8";
                    color = "red";
                    text = html ? "!" : "[!]";
                    break;

                case Impact.Medium:
                    backgroundColor = "#EDDA74";
                    color = "#E56717";
                    text = html ? "?" : "[?]";
                    break;

                case Impact.Low:
                    backgroundColor = "#e8ffe8";
                    color = "green";
                    text = html ? "&#10003;" : "[ ]";
                    break;

                default:
                    backgroundColor = "#e8e8ff";
                    color = "blue";
                    text = "";
                    break;
            }
            valStart = html ? string.Format("<span style=\"color:{0};font-weight:bold;\">", color) : "";
            valEnd = html ? "</span>" : "";
            logo = html ? string.Format("<span style=\"border:1px solid {0};background-color:{1};color:{0};font-weight:bold;display:inline-block;text-align:center;width:16px;\">{2}</span>", color, backgroundColor, text) : text;
        }

        #endregion

        #region Méthodes statiques publiques

        /// <summary>
        /// Supprime toutes les statisques.
        /// </summary>
        public static void ClearStatistics()
        {
#if PROFILING_ENABLED
#if MEASURE_PERFORMANCES_IN_MS || MEASURE_PERFORMANCES_IN_TICKS_STOPWATCH || MEASURE_PERFORMANCES_IN_TICKS_WIN32
            lock (s_lock)
            {
                s_stats.Clear();
            }
#endif
#endif
        }

        /// <summary>
        /// Renvoie les statistiques triées par ordre décroissant de temps moyen.
        /// </summary>
        /// <returns>Statistiques.</returns>
        private static List<KeyValuePair<string, Stats>> GetStatisticsSortedByAverageTime()
        {
#if MEASURE_PERFORMANCES_IN_MS
            return s_stats.OrderByDescending(s => s.Value.AverageElapsedMilliseconds).ToList();
#elif MEASURE_PERFORMANCES_IN_TICKS_STOPWATCH || MEASURE_PERFORMANCES_IN_TICKS_WIN32
            return s_stats.OrderByDescending(s => s.Value.AverageElapsedTicks).ToList();
#else
            return new List<KeyValuePair<string, Stats>>();
#endif
        }

        /// <summary>
        /// Construit le texte des statistiques.
        /// </summary>
        /// <param name="html">Indique si le texte renvoyé est au format HTML (si <value>true</value>), ou s'il est au format TEXTE (si <value>false</value>).</param>
        /// <returns>Texte des statistiques.</returns>
        public static string GetStatistics(bool html = false)
        {
            StringBuilder sbStats = new StringBuilder();
#if PROFILING_ENABLED
            if (html)
                sbStats.Append("<u><b>Profiling statistics</b></u> :<ol>\n");
            else
                sbStats.Append("Profiling statistics :\n");
#if MEASURE_PERFORMANCES_IN_MS
            lock (s_lock)
            {
                UInt64 sumCount = 0L;
                double sumTotalElapsedMilliseconds = 0.0;
                var stats = GetStatisticsSortedByAverageTime();
                foreach (var s in stats)
                {
                    sumCount += s.Value.Count;
                    sumTotalElapsedMilliseconds += s.Value.TotalElapsedMilliseconds;
                    string logo, valStart, valEnd;
                    ToText(s.Value.AverageSeverity, html, out logo, out valStart, out valEnd);
                    if (html)
                        sbStats.AppendFormat("<li>{0} <b>{1}</b> :", logo, s.Key);
                    else
                        sbStats.AppendFormat("\t{0} {1,-20} :", logo, s.Key);
                    sbStats.AppendFormat("   {2}{0,5:#,##0}{3} call{4} in {2}{1,12:#,##0.000}{3} ms", s.Value.Count, s.Value.TotalElapsedMilliseconds, valStart, valEnd, (s.Value.Count >= 2) ? "s" : "");
                    sbStats.AppendFormat(",   i.e. {1}{0,12:#,##0.000}{2} ms/call", s.Value.AverageElapsedMilliseconds, valStart, valEnd);
                    if (html)
                        sbStats.Append(".</li>\n");
                    else
                        sbStats.Append(".\n");
                }
                if (html)
                    sbStats.Append("</ol/>\n");
                else
                    sbStats.Append("\n");
                if (sumCount >= 1)
                {
                    if (html)
                        sbStats.Append(" &rArr; ");
                    else
                        sbStats.Append("  -->  ");
                    string logo, valStart, valEnd;
                    ToText(null, html, out logo, out valStart, out valEnd);
                    sbStats.AppendFormat("{2}{0:#,##0}{3} call{4} in {2}{1:#,##0.000}{3} ms", sumCount, sumTotalElapsedMilliseconds, valStart, valEnd, (sumCount >= 2) ? "s" : "");
                    double avg = sumTotalElapsedMilliseconds / (double)sumCount;
                    sbStats.AppendFormat(",   i.e. {1}{0:#,##0.000}{2} ms/call", avg, valStart, valEnd);
                    if (html)
                        sbStats.Append(".<br/>\n");
                    else
                        sbStats.Append(".\n");
                }
                else
                {
                    if (html)
                        sbStats.Append(" &rArr; No call.<br/>\n");
                    else
                        sbStats.Append("  -->  No call.\n");
                }
            }
#elif MEASURE_PERFORMANCES_IN_TICKS_STOPWATCH || MEASURE_PERFORMANCES_IN_TICKS_WIN32
            lock (s_lock)
            {
                UInt64 sumCount = 0L;
                UInt64 sumTotalElapsedTicks = 0L;
                var stats = GetStatisticsSortedByAverageTime();
                foreach (var s in stats)
                {
                    sumCount += s.Value.Count;
                    sumTotalElapsedTicks += s.Value.TotalElapsedTicks;
                    string logo, valStart, valEnd;
                    ToText(s.Value.AverageSeverity, html, out logo, out valStart, out valEnd);
                    if (html)
                        sbStats.AppendFormat("<li>{0} <b>{1}</b> :", logo, s.Key);
                    else
                        sbStats.AppendFormat("\t{0} {1,-20} :", logo, s.Key);
                    sbStats.AppendFormat("   {2}{0,5:#,##0}{3} call{4} in {2}{1,12:#,##0}{3} ticks", s.Value.Count, s.Value.TotalElapsedTicks, valStart, valEnd, (s.Value.Count >= 2) ? "s" : "");
                    sbStats.AppendFormat(",   i.e. {1}{0,12:#,##0.000}{2} ticks/call", s.Value.AverageElapsedTicks, valStart, valEnd);
                    if (html)
                        sbStats.Append(".</li>\n");
                    else
                        sbStats.Append(".\n");
                }
                if (html)
                    sbStats.Append("</ol/>\n");
                else
                    sbStats.Append("\n");
                if (sumCount >= 1)
                {
                    if (html)
                        sbStats.Append(" &rArr; ");
                    else
                        sbStats.Append("  -->  ");
                    string logo, valStart, valEnd;
                    ToText(null, html, out logo, out valStart, out valEnd);
                    sbStats.AppendFormat("{2}{0:#,##0}{3} call{4} in {2}{1:#,##0}{3} ticks", sumCount, sumTotalElapsedTicks, valStart, valEnd, (sumCount >= 2) ? "s" : "");
                    decimal avg = (decimal)sumTotalElapsedTicks / (decimal)sumCount;
                    sbStats.AppendFormat(",   i.e. {1}{0:#,##0.000}{2} ticks/call", avg, valStart, valEnd);
                    if (html)
                        sbStats.Append(".<br/>\n");
                    else
                        sbStats.Append(".\n");
                }
                else
                {
                    if (html)
                        sbStats.Append(" &rArr; No call.<br/>\n");
                    else
                        sbStats.Append("  -->  No call.\n");
                }
            }
#endif
#else
            if (html)
                sbStats.Append("<font color='red'><i>Le profiling a été désactivé.</i></font><br/>\n");
            else
                sbStats.Append("Le profiling a été désactivé.\n");
#endif
            if (html)
                return sbStats.ToString().Replace(" ", "&nbsp;");
            else
                return sbStats.ToString();
        }

        /// <summary>
        /// Envoie les statistiques dans le Log.
        /// </summary>
        /// <param name="level">Niveau d'erreur.</param>
        public static void LogStatistics(Level level = Level.Debug)
        {
#if PROFILING_ENABLED
#if MEASURE_PERFORMANCES_IN_MS || MEASURE_PERFORMANCES_IN_TICKS_STOPWATCH || MEASURE_PERFORMANCES_IN_TICKS_WIN32
            string stats = GetStatistics(false);
            Log.Write(level, stats, null);
#endif
#endif
        }

        /// <summary>
        /// Affiche les statistiques dans la console.
        /// </summary>
        public static void PrintStatistics()
        {
#if PROFILING_ENABLED
#if MEASURE_PERFORMANCES_IN_MS || MEASURE_PERFORMANCES_IN_TICKS_STOPWATCH || MEASURE_PERFORMANCES_IN_TICKS_WIN32
            string stats = GetStatistics(false);
            Console.Write(stats);
#endif
#endif
        }

        /// <summary>
        /// Affiche les statistiques dans la sortie de Visual Studio.
        /// </summary>
        public static void TraceStatistics()
        {
#if PROFILING_ENABLED
#if MEASURE_PERFORMANCES_IN_MS || MEASURE_PERFORMANCES_IN_TICKS_STOPWATCH || MEASURE_PERFORMANCES_IN_TICKS_WIN32
            string stats = GetStatistics(false);
            Trace.Write(stats);
#endif
#endif
        }

        #endregion

    }



}
