﻿using log4net;
using System;
using System.Reflection;
using System.Text;
using System.Web.Http;



[assembly: log4net.Config.XmlConfigurator(Watch = true)]    // Recharge la configuration de log4net si le fichier de config est modifié.
namespace Smag.Framework.Common
{



    /// <summary>
    /// Permet de logger des erreurs, avertissements, ...
    /// </summary>
    public static class Logger
    {

        #region Variables statiques

        /// <summary>
        /// Logueur.
        /// </summary>
        private static ILog s_logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #endregion

        #region Méthodes statiques privées

        /// <summary>
        /// Formate le message à logger.
        /// </summary>
        /// <param name="message">Texte du message.</param>
        /// <param name="args">Arguments optionnels.</param>
        /// <returns>Message formaté.</returns>
        private static string FormatMessage(string message, params object[] args)
        {
            // Formatte le message.
            StringBuilder sbMessage = new StringBuilder();
            sbMessage.AppendFormat(message, args);

            // Fin.
            return sbMessage.ToString();
        }

        #endregion

        #region Méthodes statiques publiques

        /// <summary>
        /// Logue un message servant au déboggage.
        /// </summary>
        /// <param name="message">Texte du message.</param>
        /// <param name="args">Paramètres optionnels.</param>
        public static void Debug(string message, params object[] args)
        {
            string msg = FormatMessage(message, args);
            if (!string.IsNullOrEmpty(msg))
                s_logger.Debug(msg);
        }

        /// <summary>
        /// Logue un message d'erreur.
        /// </summary>
        /// <param name="message">Texte du message.</param>
        /// <param name="args">Paramètres optionnels.</param>
        public static void Error(string message, params object[] args)
        {
            string msg = FormatMessage(message, args);
            if (!string.IsNullOrEmpty(msg))
                s_logger.Error(msg);
        }

        /// <summary>
        /// Logue une exception.
        /// </summary>
        /// <param name="ex">Exception à loguer.</param>
        /// <param name="fatal">Indique si l'exception doit être traitée comme une erreur fatale, ou comme une simple erreur.</param>
        public static void Exception(Exception ex, bool fatal = false)
        {
            // Récupère l'erreur interne, parfois plus explicite que le message d'erreur principal.
            if (ex == null)
                return;
            Exception lastInnerException = ex.InnerException;
            while (lastInnerException != null && lastInnerException.InnerException != null)
                lastInnerException = lastInnerException.InnerException;

            // Construit le message d'erreur.
            StringBuilder message = new StringBuilder("EXCEPTION : ");
            message.Append(ex.Message);
            HttpResponseException httpEx = ex as HttpResponseException;
            if (httpEx != null)
                message.AppendFormat(" ({0})", httpEx.Response.ReasonPhrase);
            else if (lastInnerException != null)
                message.AppendFormat(" ({0})", lastInnerException.Message);

            // Logue le message d'erreur.
            if (fatal)
                Fatal(message.ToString());
            else
                Error(message.ToString());
        }

        /// <summary>
        /// Logue un message d'erreur fatale.
        /// </summary>
        /// <param name="message">Texte du message.</param>
        /// <param name="args">Paramètres optionnels.</param>
        public static void Fatal(string message, params object[] args)
        {
            string msg = FormatMessage(message, args);
            if (!string.IsNullOrEmpty(msg))
                s_logger.Fatal(msg);
        }

        /// <summary>
        /// Logue un message d'information.
        /// </summary>
        /// <param name="message">Texte du message.</param>
        /// <param name="args">Paramètres optionnels.</param>
        public static void Info(string message, params object[] args)
        {
            string msg = FormatMessage(message, args);
            if (!string.IsNullOrEmpty(msg))
                s_logger.Info(msg);
        }

        /// <summary>
        /// Logue un message d'avertissement.
        /// </summary>
        /// <param name="message">Texte du message.</param>
        /// <param name="args">Paramètres optionnels.</param>
        public static void Warning(string message, params object[] args)
        {
            string msg = FormatMessage(message, args);
            if (!string.IsNullOrEmpty(msg))
                s_logger.Warn(msg);
        }

        #endregion

    }   // public static class Log



}   // namespace Smag.Framework.Common
