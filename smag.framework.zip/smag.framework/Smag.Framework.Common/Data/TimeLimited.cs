﻿using System;



namespace Smag.Framework.Common.Data
{



    /// <summary>
    /// Encapsule des données valides pendant un certain temps.
    /// </summary>
    /// <typeparam name="T">Type des données limitées dans le temps.</typeparam>
    public class TimeLimited<T>
    {

        #region Variables membres

        /// <summary>
        /// Données encapsulées.
        /// </summary>
        private T m_data;

        /// <summary>
        /// Date et heure jusqu'à laquelle les données sont encore valides.
        /// </summary>
        private DateTime? m_endingTime;

        /// <summary>
        /// Date et heure à partir de laquelle les données ont été affectées.
        /// </summary>
        private DateTime? m_startingTime;

        /// <summary>
        /// Durée de validité des données.
        /// </summary>
        private TimeSpan? m_timeout;

        #endregion

        #region Constructeurs

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="timeout">Durée de validité des données, en millisecondes. Si négatif alors les données seront valides indéfiniment.</param>
        public TimeLimited(double timeout = -1)
        {
            m_data = default(T);
            m_timeout = (timeout < 0) ? (TimeSpan?)null : TimeSpan.FromMilliseconds(timeout);
            m_endingTime = null;
            m_startingTime = null;
        }

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="timeout">Durée de validité des données. Si <value>null</value> alors les données seront valides indéfiniment.</param>
        public TimeLimited(TimeSpan? timeout)
        {
            m_data = default(T);
            m_timeout = timeout;
            m_endingTime = null;
            m_startingTime = null;
        }

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="data">Données initiales.</param>
        /// <param name="timeout">Durée de validité des données, en millisecondes. Si négatif alors les données seront valides indéfiniment.</param>
        public TimeLimited(T data, double timeout = -1)
        {
            m_data = data;
            m_timeout = (timeout < 0) ? (TimeSpan?)null : TimeSpan.FromMilliseconds(timeout);
            m_startingTime = DateTime.Now;
            m_endingTime = (timeout > 0) ? m_startingTime.Value.AddMilliseconds(timeout) : (DateTime?)null;
        }

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="data">Données initiales.</param>
        /// <param name="timeout">Durée de validité des données. Si <value>null</value> alors les données seront valides indéfiniment.</param>
        public TimeLimited(T data, TimeSpan? timeout)
        {
            m_data = data;
            m_timeout = timeout;
            m_startingTime = DateTime.Now;
            m_endingTime = timeout.HasValue ? m_startingTime.Value.Add(timeout.Value) : (DateTime?)null;
        }

        #endregion

        #region Méthodes

        /// <summary>
        /// Supprime les données encapsulées.
        /// </summary>
        public void Clear()
        {
            m_endingTime = null;
            m_startingTime = null;
            m_data = default(T);
        }

        /// <summary>
        /// Si des données ont été affectées, réinitialise la période de validité.
        /// </summary>
        public void ResetValidityPeriod()
        {
            if (m_startingTime.HasValue)
            {
                m_startingTime = DateTime.Now;
                m_endingTime = m_timeout.HasValue ? m_startingTime.Value.Add(m_timeout.Value) : (DateTime?)null;
            }
        }

        #endregion

        #region Propriétés

        /// <summary>
        /// Données limitées dans le temps.
        /// </summary>
        public T Data
        {
            get
            {
                if (IsValid)
                    return m_data;
                return default(T);
            }
            set
            {
                m_data = value;
                m_startingTime = DateTime.Now;
                m_endingTime = m_timeout.HasValue ? m_startingTime.Value.Add(m_timeout.Value) : (DateTime?)null;
            }
        }

        /// <summary>
        /// Indique si les données encapsulées <see cref="Data"/> sont encore valides.
        /// </summary>
        public bool IsValid
        {
            get
            {
                if (!m_startingTime.HasValue)
                    return false;   // les données n'ont pas été affectées.
                if (!m_endingTime.HasValue)
                    return true;    // il n'y aucune limite de temps.
                return (m_endingTime.Value >= DateTime.Now);
            }
        }

        /// <summary>
        /// Durée pendant lesquelles les données sont valides.
        /// </summary>
        /// <remarks>Si <value>null</value> alors les données seront valides indéfiniment.</remarks>
        public TimeSpan? Timeout
        {
            get
            {
                return m_timeout;
            }
            set
            {
                m_timeout = value;
                if (m_timeout.HasValue)
                {
                    m_endingTime = m_startingTime.HasValue ? m_startingTime.Value.Add(m_timeout.Value) : (DateTime?)null;
                }
                else
                {
                    m_endingTime = null;
                }
            }
        }

        #endregion

    }



}
