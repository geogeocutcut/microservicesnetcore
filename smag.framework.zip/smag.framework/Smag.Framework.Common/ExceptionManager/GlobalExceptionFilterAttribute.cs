﻿using Newtonsoft.Json;
using Smag.Framework.Common.Exceptions;
using Smag.Framework.Common.Extensions;
using Smag.Framework.Common.Logs;
using System;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using System.Web.Http.Filters;
using AuthenticationException = System.Security.Authentication.AuthenticationException;

namespace Smag.Framework.Common.ExceptionManager
{
    public class GlobalExceptionFilterAttribute : ExceptionFilterAttribute
    {
        public override void OnException(HttpActionExecutedContext actionExecutedContext)
        {
            actionExecutedContext.Exception.Log();

            if (actionExecutedContext.Exception is AuthenticationException)
            {
                // 401 for token problems
                var resp = new HttpResponseMessage(HttpStatusCode.Unauthorized)
                {
                    ReasonPhrase = actionExecutedContext.Exception.GetReason(),
                    Content = new StringContent(JsonConvert.SerializeObject(new { error = actionExecutedContext.Exception.GetReason(), error_description = actionExecutedContext.Exception.Message }), Encoding.UTF8, "application/json")
                };

                throw new HttpResponseException(resp);
            }
            else if (actionExecutedContext.Exception is ServiceException)
            {
                // Exception de service IoTA.
                var resp = new HttpResponseMessage(HttpStatusCode.BadRequest)
                {
                    ReasonPhrase = ((ServiceException)actionExecutedContext.Exception).Error,
                    Content = new StringContent(JsonConvert.SerializeObject(new { error = ((ServiceException)actionExecutedContext.Exception).Error, error_description = actionExecutedContext.Exception.Message }), Encoding.UTF8, "application/json")
                };

                throw new HttpResponseException(resp);
            }
            else if (actionExecutedContext.Exception is NotImplementedException)
            {
                // Méthode non implémentée.
                actionExecutedContext.Response = new HttpResponseMessage(HttpStatusCode.NotImplemented);
            }
            else if (actionExecutedContext.Exception is HttpCallException)
            {
                var resp = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    ReasonPhrase = actionExecutedContext.Exception.GetReason(),
                    Content = new StringContent(JsonConvert.SerializeObject(new { error = ((HttpCallException)actionExecutedContext.Exception).Error, error_description = actionExecutedContext.Exception.Message }), Encoding.UTF8, "application/json")
                };

                throw new HttpResponseException(resp);
            }
            else
            {
                // Erreur générale.
                actionExecutedContext.Response = HttpException.BuildMessage(HttpStatusCode.BadRequest, actionExecutedContext.Exception, true);

                var resp = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    ReasonPhrase = actionExecutedContext.Exception.GetReason(),
                    Content = new StringContent(JsonConvert.SerializeObject(new { error = actionExecutedContext.Exception.GetReason(), error_description = actionExecutedContext.Exception.Message }), Encoding.UTF8, "application/json")
                };

                throw new HttpResponseException(resp);
            }
        }
    }
}