﻿using System;



namespace Smag.Framework.Common.Attributes
{



    [AttributeUsage(AttributeTargets.Field)]
    public sealed class CodeAttribute : Attribute
    {

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="code">Code initial.</param>
        public CodeAttribute(string code)
        {
            Code = code;
        }

        /// <summary>
        /// Code associé au champ.
        /// </summary>
        public string Code { get; private set; }

    }



}
