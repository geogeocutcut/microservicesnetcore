﻿using System;
using System.Runtime.CompilerServices;



namespace Smag.Framework.Common.Logs
{



    /// <summary>
    /// Extensions de classes pour le logging.
    /// </summary>
    public static class LogExtensions
    {

        /// <summary>
        /// Logue l'exception actuelle.
        /// </summary>
        /// <param name="ex">Exception à loguer.</param>
        /// <param name="message">Message optionnel.</param>
        /// <param name="level">Niveau d'erreur.</param>
        /// <param name="impact">Niveau d'impact.</param>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Log(this Exception ex, string message = null, Level level = Level.Error, Impact? impact = null)
        {
            Logs.Log.Process(ex, message, level, impact);
        }

        /// <summary>
        /// Logue le message actuel.
        /// </summary>
        /// <param name="message">Message à lguer.</param>
        /// <param name="level">Niveau d'erreur.</param>
        /// <param name="impact">Niveau d'impact.</param>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Log(this string message, Level level = Level.Info, Impact? impact = null)
        {
            Logs.Log.Process(null, message, level, impact);
        }

    }



}
