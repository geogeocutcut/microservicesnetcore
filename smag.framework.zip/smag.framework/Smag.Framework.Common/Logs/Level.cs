﻿using Smag.Framework.Common.Attributes;



namespace Smag.Framework.Common.Logs
{



    /// <summary>
    /// Niveau d'erreur.
    /// </summary>
    public enum Level
    {

        /// <summary>
        /// Débogage.
        /// </summary>
        [Code("Debug")]
        Debug=1,

        /// <summary>
        /// Information.
        /// </summary>
        [Code("Info")]
        Info=2,

        /// <summary>
        /// Avertissement.
        /// </summary>
        [Code("Warning")]
        Warning=3,

        /// <summary>
        /// Erreur.
        /// </summary>
        [Code("Error")]
        Error=4,

        /// <summary>
        /// Erreur fatale.
        /// </summary>
        [Code("Fatal")]
        Fatal=5

    }



}
