﻿//#define DISABLE_LOGGING
using log4net;
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.Extensibility;
using Smag.Framework.Common.Services;
using Smag.Framework.KeyManager;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;



[assembly: log4net.Config.XmlConfigurator(Watch = true)]    // Recharge la configuration de log4net si le fichier de config est modifié.
namespace Smag.Framework.Common.Logs
{



    /// <summary>
    /// Permet de logger des erreurs, avertissements, ..
    /// </summary>
    public static class Log
    {

        #region Constantes


        /// <summary>
        /// Nom de la clé, dans le fichier App/Web.config, contenant l'identifiant de l'application.
        /// </summary>
        private const string LOG_APP_CODE = "LogAppCode";

        /// <summary>
        /// Nom de la clé, dans le fichier App/Web.config, contenant le nom complet de l'application.
        /// </summary>
        private const string LOG_APP_NAME = "LogAppName";

        /// <summary>
        /// Nom de la clé, dans le fichier App/Web.config, contenant l'adresse de la Web API chargée d'ajouter les logs en base de données.
        /// </summary>
        private const string LOGGING_API_URL = "LoggingApi";

        #endregion

        #region Types internes

        /// <summary>
        /// Application stockant ses logs en base de données.
        /// </summary>
        private class PersistedApplication
        {

            /// <summary>
            /// Identifiant de l'application.
            /// </summary>
            public string Code;

            /// <summary>
            /// Nom complet de l'application.
            /// </summary>
            public string Name;

            /// <summary>
            /// Adresse du service Web chargée de stocker les logs dans la base de données.
            /// </summary>
            public Uri ApiUrl;
        }

        #endregion

        #region Variables statiques

        /// <summary>
        /// Logueur.
        /// </summary>
        private static ILog s_log4net = null;

        /// <summary>
        /// Méthodes pouvant être appelées pour loguer un message.
        /// </summary>
        private static List<Action<Exception, string, Level, Impact>> s_loggers = new List<Action<Exception, string, Level, Impact>>();

        /// <summary>
        /// Référence les applications dont les logs doivent être envoyés à la Web API.
        /// </summary>
        private static Dictionary<string, PersistedApplication> s_persistedApplications = null;

        /// <summary>
        /// Nombre de tâches de log actuellement en cours d'exécution.
        /// </summary>
        private static long s_runningTasksCount = 0;


        private static TelemetryClient telemetryClient = null;

        #endregion

        #region Constructeur

        /// <summary>
        /// Constructeur.
        /// </summary>
        static Log()
        {
            UseDatabase = false;
            UseLog4Net = true;

            try
            {
                string APPINSIGHTS_INSTRUMENTATIONKEY = ConfigurationManager.AppSettings.Get("APPINSIGHTS_INSTRUMENTATIONKEY");

                if (!String.IsNullOrEmpty(APPINSIGHTS_INSTRUMENTATIONKEY))
                {
                    TelemetryConfiguration.Active.InstrumentationKey = APPINSIGHTS_INSTRUMENTATIONKEY;
                    telemetryClient = new TelemetryClient { InstrumentationKey = TelemetryConfiguration.Active.InstrumentationKey };
                }
            }
            catch
            {
                Log.Error("An error occured when trying to configure application insight");
            }


        }

        #endregion

        #region Propriétés publiques

        /// <summary>
        /// Indique si les logs doivent être envoyés à une Web API qui les stockera en base de données.
        /// </summary>
        public static bool UseDatabase
        {
            get
            {
                return (s_persistedApplications != null);
            }
            set
            {
                if (value)
                {
                    if (s_persistedApplications == null)
                    {
                        s_persistedApplications = new Dictionary<string, PersistedApplication>();
                        s_loggers.Add(PersistToDatabase);
                    }
                }
                else
                {
                    if (s_persistedApplications != null)
                    {
                        s_loggers.Remove(PersistToDatabase);
                        s_persistedApplications = null;
                    }
                }
            }
        }

        /// <summary>
        /// Indique si les logs doivent être envoyés à log4net.
        /// </summary>
        public static bool UseLog4Net
        {
            get
            {
                return (s_log4net != null);
            }
            set
            {
                if (value)
                {
                    if (s_log4net == null)
                    {
                        s_log4net = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
                        s_loggers.Add(SendToLog4Net);
                    }
                }
                else
                {
                    if (s_log4net != null)
                    {
                        s_loggers.Remove(SendToLog4Net);
                        s_log4net = null;
                    }
                }
            }
        }

        #endregion

        #region Méthodes statiques privées

        /// <summary>
        /// Formate le message à loguer.
        /// </summary>
        /// <param name="message">Texte du message.</param>
        /// <param name="args">Arguments optionnels.</param>
        /// <returns>Message formaté.</returns>
        private static string FormatMessage(string message, params object[] args)
        {
            StringBuilder sbMessage = new StringBuilder();
            if (!string.IsNullOrEmpty(message))
                sbMessage.AppendFormat(message.Replace("{}", "{{}}"), args);
            return sbMessage.ToString();
        }

        /// <summary>
        /// Obtient les informations sur l'application dont les logs doivent être envoyés à la Web API.
        /// </summary>
        /// <returns>Code et nom de l'application + URL de la Web API.</returns>
        private static PersistedApplication GetPersistedApplication()
        {
#if DISABLE_LOGGING
            return null;
#else
            if (s_persistedApplications == null)
                return null;
            string assemblyFullName = Assembly.GetCallingAssembly().FullName;
            PersistedApplication app;
            if (s_persistedApplications.TryGetValue(assemblyFullName, out app))
                return app;

            // Essaie d'obtenir les informations à partir du App/Web.config.
            try
            {
                string appCode = GetApplicationCode();
                string appName = GetApplicationName();
                string url = GetLoggingApiUrl();
                if (string.IsNullOrEmpty(appCode) || string.IsNullOrEmpty(appName) || string.IsNullOrEmpty(url))
                    throw new InvalidOperationException();
                app = new PersistedApplication
                {
                    Code = appCode,
                    Name = appName,
                    ApiUrl = new Uri(url)
                };

                // Enregistre l'application.
                Register(app);

                // Ajoute les informations.
                lock (s_persistedApplications)
                {
                    if (!s_persistedApplications.ContainsKey(assemblyFullName))
                    {
                        lock (s_persistedApplications)
                        {
                            s_persistedApplications.Add(assemblyFullName, app);
                        }
                    }
                }
                return app;
            }
            catch
            {
                lock (s_persistedApplications)
                {
                    if (!s_persistedApplications.ContainsKey(assemblyFullName))
                    {
                        lock (s_persistedApplications)
                        {
                            s_persistedApplications.Add(assemblyFullName, null);
                        }
                    }
                }
                return null;
            }
#endif
        }

        /// <summary>
        /// Envoie le log à la Web API chargée de le sauvegarder dans la base de données de monitoring.
        /// </summary>
        /// <param name="ex">Exception. (éventuellement <value>null</value>)</param>
        /// <param name="message">Description de l'erreur. (éventuellement <value>null</value>)</param>
        /// <param name="level">Niveau d'erreur.</param>
        /// <param name="impact">Niveau d'impact.</param>
        private static void PersistToDatabase(Exception ex, string message, Level level, Impact impact)
        {
            var app = GetPersistedApplication();
            if (app == null)
                return;
            Uri url = new Uri(app.ApiUrl, "api/logging/persist");
            WebServiceHelper.Post(url.AbsoluteUri, null, PersistedLogData.Build(app.Code, ex, message, level, impact));
        }

        /// <summary>
        /// Permet de créer l'application en base de données si elle n'existe pas
        /// </summary>
        /// <param name="app">Application.</param>
        private static void Register(PersistedApplication app)
        {
            Uri url = new Uri(app.ApiUrl, "api/logging/register");
            WebServiceHelper.Post(url.AbsoluteUri, null, new
            {
                appCode = app.Code,
                appName = app.Name
            });
        }

        /// <summary>
        /// Envoie le log à 'log4net'.
        /// </summary>
        /// <param name="ex">Exception. (éventuellement <value>null</value>)</param>
        /// <param name="message">Description de l'erreur. (éventuellement <value>null</value>)</param>
        /// <param name="level">Niveau d'erreur.</param>
        /// <param name="impact">Niveau d'impact.</param>
        private static void SendToLog4Net(Exception ex, string message, Level level, Impact impact)
        {


            if (s_log4net == null)
                return;
            if (string.IsNullOrEmpty(message))
            {
                if (ex != null)
                {
                    switch (level)
                    {
                        case Level.Debug:
                            System.Diagnostics.Trace.TraceInformation(ex.Message + "\n" + ex.StackTrace);
                            s_log4net.Debug("", ex);
                            break;
                        case Level.Error:
                            System.Diagnostics.Trace.TraceError(ex.Message + "\n" + ex.StackTrace);
                            s_log4net.Error("", ex);
                            break;
                        case Level.Fatal:
                            System.Diagnostics.Trace.TraceError(ex.Message + "\n" + ex.StackTrace);
                            s_log4net.Fatal("", ex);
                            break;
                        case Level.Info:
                            System.Diagnostics.Trace.TraceInformation(ex.Message + "\n" + ex.StackTrace);
                            s_log4net.Info("", ex);
                            break;
                        case Level.Warning:
                            System.Diagnostics.Trace.TraceWarning(ex.Message + "\n" + ex.StackTrace);
                            s_log4net.Warn("", ex);
                            break;
                    }
                }
            }
            else if (ex == null)
            {
                switch (level)
                {
                    case Level.Debug: s_log4net.Debug(message); break;
                    case Level.Error: s_log4net.Error(message); break;
                    case Level.Fatal: s_log4net.Fatal(message); break;
                    case Level.Info: s_log4net.Info(message); break;
                    case Level.Warning: s_log4net.Warn(message); break;
                }


            }
            else
            {
                switch (level)
                {
                    case Level.Debug: s_log4net.Debug(message, ex); break;
                    case Level.Error: s_log4net.Error(message, ex); break;
                    case Level.Fatal: s_log4net.Fatal(message, ex); break;
                    case Level.Info: s_log4net.Info(message, ex); break;
                    case Level.Warning: s_log4net.Warn(message, ex); break;
                }


            }
        }

        #endregion

        #region Méthodes statiques publiques

        /// <summary>
        /// Logue un message servant au déboggage.
        /// </summary>
        /// <param name="message">Texte du message.</param>
        /// <param name="args">Paramètres optionnels.</param>
        public static void Debug(string message, params object[] args)
        {
            string msg = FormatMessage(message, args);
            Process(null, msg, Level.Debug, null);
        }

        /// <summary>
        /// Logue un message d'erreur.
        /// </summary>
        /// <param name="message">Texte du message.</param>
        /// <param name="args">Paramètres optionnels.</param>
        public static void Error(string message, params object[] args)
        {
            string msg = FormatMessage(message, args);
            Process(null, msg, Level.Error, null);
        }

        /// <summary>
        /// Logue un message d'erreur fatale.
        /// </summary>
        /// <param name="message">Texte du message.</param>
        /// <param name="args">Paramètres optionnels.</param>
        public static void Fatal(string message, params object[] args)
        {
            string msg = FormatMessage(message, args);
            Process(null, msg, Level.Fatal, null);
        }


        public static void Flush()
        {
            if (telemetryClient != null)
                telemetryClient.Flush();

        }

        /// <summary>
        /// Obtient l'identifiant de l'application, à partir du fichier App/Web.config.
        /// </summary>
        /// <returns>Identifiant de l'application.</returns>
        public static string GetApplicationCode()
        {
            return Settings.GetWithManagerType(LOG_APP_CODE, MType.WebConfig);
        }

        /// <summary>
        /// Obtient le nom complet de l'application, à partir du fichier App/Web.config.
        /// </summary>
        /// <returns>Nom complet de l'application.</returns>
        public static string GetApplicationName()
        {
            return Settings.GetWithManagerType(LOG_APP_NAME, MType.WebConfig);
        }

        /// <summary>
        /// Obtient, à partir du fichier App/Web.config, l'adresse de la Web API chargée d'ajouter les logs en base de données.
        /// </summary>
        /// <returns>Adresse de la Web API chargée d'ajouter les logs en base de données.</returns>
        public static string GetLoggingApiUrl()
        {
            return Settings.GetWithManagerType(LOGGING_API_URL, MType.WebConfig);
        }

        /// <summary>
        /// Logue un message d'information.
        /// </summary>
        /// <param name="message">Texte du message.</param>
        /// <param name="args">Paramètres optionnels.</param>
        public static void Info(string message, params object[] args)
        {
            string msg = FormatMessage(message, args);
            Process(null, msg, Level.Info, null);
        }
        /// <summary>
        /// Logue un message d'information.
        /// </summary>
        /// <param name="message">Texte du message.</param>
        /// <param name="args">Paramètres optionnels.</param>
        public static void Exception(Exception ex)
        {
            TelemetryClient _telemetryClient = new TelemetryClient();
            _telemetryClient.TrackException(ex);
            Process(null,"Exception.Message: " + ex.Message, Level.Info, null);
            Process(null, "Exception.StackTrace: " + ex.StackTrace, Level.Info, null);
        }
        /// <summary>
        /// Logue un message d'information.
        /// </summary>
        /// <param name="message">Texte du message.</param>
        /// <param name="args">Paramètres optionnels.</param>
        public static void Request(string message,Level level = Level.Info)
        {
            Process(null, message, level, null);
        }

        /// <summary>
        /// Attend que toutes les tâches de logging soient terminées.
        /// </summary>
        /// <param name="milliseconds">Temps maximal à attendre, en millisecondes. Si ce nombre est négatif, alors la fonction attendra indéfiniment.</param>
        /// <returns><value>true</value> si toutes les tâches de log sont terminées, <value>false</value> sinon.</returns>
        /// <remarks>lorsque l'application est un programme console, il est conseillé d'appeler cette méthode afin de s'assurer que tous les logs ont bien été traités.</remarks>
        public static bool WaitForCompletion(long milliseconds = -1L)
        {
            const int MAX_TIMEOUT = 50;
            long count = Interlocked.Read(ref s_runningTasksCount);
            if (milliseconds == 0)
                return (count <= 0);
            long remainingMilliseconds = milliseconds;
            while (count > 0)
            {
#if DEBUG
                Trace.WriteLine(string.Format("{0} running logging task{1}.", count, (count >= 2) ? "s" : ""));
#endif
                int timeout;
                if (milliseconds < 0)
                    timeout = MAX_TIMEOUT;
                else if (remainingMilliseconds < (long)MAX_TIMEOUT)
                    timeout = (int)remainingMilliseconds;
                else
                    timeout = MAX_TIMEOUT;
                Thread.Sleep(timeout);
                count = Interlocked.Read(ref s_runningTasksCount);
                if (milliseconds > 0)
                {
                    remainingMilliseconds -= (long)timeout;
                    if (remainingMilliseconds <= 0)
                        return (count <= 0);
                }
            }
            return true;
        }

        /// <summary>
        /// Logue un message d'avertissement.
        /// </summary>
        /// <param name="message">Texte du message.</param>
        /// <param name="args">Paramètres optionnels.</param>
        public static void Warning(string message, params object[] args)
        {
            string msg = FormatMessage(message, args);
            Process(null, msg, Level.Warning, null);
        }

        /// <summary>
        /// Logue un message.
        /// </summary>
        /// <param name="level">Niveau d'erreur.</param>
        /// <param name="message">Texte du message.</param>
        /// <param name="args">Paramètres optionnels.</param>
        public static void Write(Level level, string message, params object[] args)
        {
            string msg = FormatMessage(message, args);
            Process(null, msg, level, null);
        }

        #endregion

        #region Méthodes statiques internes

        /// <summary>
        /// Traite un message de log.
        /// </summary>
        /// <param name="ex">Exception. (éventuellement <value>null</value>)</param>
        /// <param name="message">Description de l'erreur.</param>
        /// <param name="level">Niveau d'erreur.</param>
        /// <param name="impact">Niveau d'impact.</param>
        internal static void Process(Exception ex, string message, Level level, Impact? impact)
        {

            Impact imp = impact ?? level.ToImpact();
            foreach (var logger in s_loggers)
            {
                Interlocked.Increment(ref s_runningTasksCount);
                Task.Factory
                    .StartNew(() =>
                    {
                        logger(ex, message, level, imp);
                    })
                    .ContinueWith(t =>
                    {
                        Interlocked.Decrement(ref s_runningTasksCount);
                    });
            }

        }

        #endregion

    }   // public static class Log



}   // namespace Smag.Framework.Common
