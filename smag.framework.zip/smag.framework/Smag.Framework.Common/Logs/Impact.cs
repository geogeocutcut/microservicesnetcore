﻿using Smag.Framework.Common.Attributes;



namespace Smag.Framework.Common.Logs
{



    /// <summary>
    /// Niveau d'impact : Haut, Moyen, Faible.
    /// </summary>
    public enum Impact
    {

        /// <summary>
        /// Faible.
        /// </summary>
        [Code("Low")]
        Low=1,

        /// <summary>
        /// Moyen.
        /// </summary>
        [Code("Medium")]
        Medium=2,

        /// <summary>
        /// Élevé.
        /// </summary>
        [Code("High")]
        High=3

    }



}
