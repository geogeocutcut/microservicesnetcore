﻿namespace Smag.Framework.Common.Logs
{



    public static class LevelExtensions
    {

        /// <summary>
        /// Obtient le niveau d'impact correspondant généralement au niveau d'erreur actuel.
        /// </summary>
        /// <param name="level">Niveau d'erreur.</param>
        /// <returns>Niveau d'impact.</returns>
        public static Impact ToImpact(this Level level)
        {
            switch (level)
            {
                case Level.Error:
                    return Impact.Medium;

                case Level.Fatal:
                    return Impact.High;

                default:
                    //case Level.Debug:
                    //case Level.Info:
                    //case Level.Warning:
                    return Impact.Low;
            }
        }

    }



}
