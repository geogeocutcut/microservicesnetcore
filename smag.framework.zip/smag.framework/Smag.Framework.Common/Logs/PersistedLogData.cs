﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;
using System.Web;
using Smag.Framework.Common.Extensions;



namespace Smag.Framework.Common.Logs
{



    /// <summary>
    /// Un message de log sauvegardé en base de données.
    /// </summary>
    public class PersistedLogData
    {

        #region Propriétés

        /// <summary>
        /// Date et heure, au format UTC, à laquelle le log a été ajouté en base.
        /// </summary>
        public DateTime DateUtc { get; set; }

        /// <summary>
        /// Description brève de l'erreur.
        /// </summary>
        public string ShortDescription { get; set; }

        /// <summary>
        /// Identifiant de l'application ayant généré ce log.
        /// </summary>
        public string ApplicationCode { get; set; }

        /// <summary>
        /// Niveau d'impact. (Haut, Moyen, Faible)
        /// </summary>
        public Impact Impact { get; set; }

        /// <summary>
        /// Niveau d'erreur. (Debug, Info, Warning, Error, Fatal)
        /// </summary>
        public Level Level { get; set; }

        /// <summary>
        /// Code d'erreur.
        /// </summary>
        public string ErrorCode { get; set; }

        /// <summary>
        /// Message de l'exception.
        /// </summary>
        public string ExceptionMessage { get; set; }

        /// <summary>
        /// Type d'exception .Net.
        /// </summary>
        public string ExceptionType { get; set; }

        /// <summary>
        /// Exception interne.
        /// </summary>
        public string InnerException { get; set; }

        /// <summary>
        /// Message de l'exception interne.
        /// </summary>
        public string InnerExceptionMessage { get; set; }

        /// <summary>
        /// Nom du fichier source ayant généré le log actuel.
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// Numéro de ligne dans le fichier source ayant généré le log actuel.
        /// </summary>
        public int? LineNumber { get; set; }

        /// <summary>
        /// Nom de la méthode du fichier source ayant généré le log actuel.
        /// </summary>
        public string MethodName { get; set; }

        /// <summary>
        /// Nom de la classe définie dans le fichier source ayant généré le log actuel.
        /// </summary>
        public string ClassName { get; set; }

        /// <summary>
        /// État de pile d'appel.
        /// </summary>
        public string StackTrace { get; set; }

        /// <summary>
        /// Adresse IP du serveur ayant généré le log.
        /// </summary>
        public string IpAddress { get; set; }

        /// <summary>
        /// Indique si le log est lié à une version de l'application en Production.
        /// </summary>
        public bool IsProduction { get; set; }

        /// <summary>
        /// Informations sur l'utilisateur connecté au moment où le log actuel a été généré.
        /// </summary>
        public string AuthenticationContext { get; set; }

        #endregion

        #region Méthodes statiques publiques

        /// <summary>
        /// Construit un message de log.
        /// </summary>
        /// <param name="applicationCode">Identifiant de l'application qui envoie le log.</param>
        /// <param name="ex">Exception à loguer.</param>
        /// <param name="message">Message optionnel.</param>
        /// <param name="level">Niveau d'erreur.</param>
        /// <param name="impact">Niveau d'impact.</param>
        /// <returns>Message de log.</returns>
        /// <see cref="https://stackoverflow.com/questions/20525277/simple-way-to-perform-error-logging/20525703#"/> 
        public static PersistedLogData Build(string applicationCode, Exception ex, string message, Level level, Impact impact)
        {
            PersistedLogData log = new PersistedLogData
            {
                DateUtc = DateTime.Now.ToUniversalTime(),
                ShortDescription = message,
                ApplicationCode = applicationCode,
                Impact = impact,
                Level = level,
                IpAddress = GetIpAddress(),
#if DEBUG
                IsProduction = false,
#else
                IsProduction = !Debugger.IsAttached,
#endif
                AuthenticationContext = GetAuthenticationContext()
            };

            // Cas d'une exception.
            if (ex != null)
            {
                // Informations de base.
                log.ExceptionMessage = ex.Message;
                log.ExceptionType = ex.GetType().FullName;
                log.StackTrace = ex.StackTrace;
                if (ex.InnerException != null)
                {
                    log.InnerException = ex.InnerException.ToString();
                    log.InnerExceptionMessage = ex.InnerException.Message;
                }

                // Code d'erreur.
                int? win32ErrorCode = ex.GetWin32ErrorCode();
                if (win32ErrorCode.HasValue)
                    log.ErrorCode = win32ErrorCode.Value.ToString();

                // Obtient les informations sur le fichier du code source ayant généré l'exception.
                var stackTrace = new StackTrace(ex, true);
                var allFrames = stackTrace.GetFrames();
                if (allFrames != null)
                {
                    foreach (var frame in allFrames)
                    {
                        log.FileName = frame.GetFileName();
                        log.LineNumber = frame.GetFileLineNumber();
                        var method = frame.GetMethod();
                        if (method != null)
                        {
                            log.MethodName = method.Name;
                            log.ClassName = method.DeclaringType.FullName;
                        }
                    }
                }
            }

            // Fin.
            return log;
        }

        #endregion

        #region Méthodes statiques privées

        /// <summary>
        /// Obtient des informations sur l'utilisateur actuel.
        /// </summary>
        /// <returns>Informations sur l'utilisateur.</returns>
        private static string GetAuthenticationContext()
        {
            StringBuilder sbAuthenticationContext = new StringBuilder();
            bool valid = false;

            // Utilisateur Web ?
            var webUser = GetCurrentWebUser();
            if (webUser != null)
            {
                #region Affiche les informations sur l'utilisateur connecté au Web Service.
                bool firstValidClaim = true;
                foreach (var claim in webUser.Claims)
                {
                    // Type et valeur du claim.
                    if (string.IsNullOrEmpty(claim.Type))
                        continue;
                    if (firstValidClaim)
                    {
                        sbAuthenticationContext.Append("Utilisateur Web :\n");
                        firstValidClaim = false;
                        valid = true;
                    }
                    sbAuthenticationContext.AppendFormat("\t{0} : ", claim.Type);
                    if (claim.Value == null)
                        sbAuthenticationContext.Append("null\n");
                    else
                        sbAuthenticationContext.AppendFormat("\"{0}\"\n", claim.Value);

                    // Propriétés du claim.
                    int propertiesCount = (claim.Properties == null) ? 0 : claim.Properties.Count;
                    if (propertiesCount > 0)
                    {
                        foreach (var p in claim.Properties)
                        {
                            if (string.IsNullOrEmpty(p.Key))
                                continue;
                            sbAuthenticationContext.AppendFormat("\t\t{0} : ", p.Key);
                            if (p.Value == null)
                                sbAuthenticationContext.Append("null\n");
                            else
                                sbAuthenticationContext.AppendFormat("\"{0}\"\n", p.Value);
                        }
                    }
                }
                #endregion
            }

            // Compte Windows ?
            string windowsAccount = GetCurrentWindowsAccount();
            if (!string.IsNullOrEmpty(windowsAccount))
            {
                if (sbAuthenticationContext.Length > 0)
                    sbAuthenticationContext.Append("\n");
                sbAuthenticationContext.Append(windowsAccount);
                valid = true;
            }

            // Construit la chaîne finale.
            return valid ? sbAuthenticationContext.ToString() : null;
        }

        /// <summary>
        /// Obtient les informations sur l'utilisateur actuellement connecté au service Web.
        /// </summary>
        /// <returns>Informations sur l'utilisateur actuel.</returns>
        private static ClaimsIdentity GetCurrentWebUser()
        {
            try
            {
                HttpContext currentContext = HttpContext.Current;
                if (currentContext == null)
                    return null;
                IPrincipal user = currentContext.User;
                if (user == null)
                    return null;
                IIdentity identity = user.Identity;
                return identity as ClaimsIdentity;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Obtient les informations sur la machine actuelle et sur le compte Windows de l'utilisateur actuel.
        /// </summary>
        /// <returns>Informations sur la machine actuelle et sur le compte Windows de l'utilisateur actuel.</returns>
        private static string GetCurrentWindowsAccount()
        {
            StringBuilder sbWindowsAccount = new StringBuilder();
            bool valid = false;
            sbWindowsAccount.Append("Informations Système :\n");
            if (!string.IsNullOrEmpty(Environment.UserName))
            {
                if (string.IsNullOrEmpty(Environment.UserDomainName))
                    sbWindowsAccount.AppendFormat("\tUtilisateur : {0}\n", Environment.UserName);
                else
                    sbWindowsAccount.AppendFormat("\tCompte Windows : {0}\\{1}\n", Environment.UserDomainName, Environment.UserName);
                valid = true;
            }
            if (!string.IsNullOrWhiteSpace(Environment.MachineName))
            {
                sbWindowsAccount.AppendFormat("\tOrdinateur : {0}\n", Environment.MachineName.TrimmedOrNull());
                valid = true;
            }
            if (Environment.OSVersion != null)
            {
                sbWindowsAccount.AppendFormat("\tSystème d'exploitation : {0} {1}\n", Environment.OSVersion.ToString(), Environment.Is64BitOperatingSystem ? "x64" : "x86");
                valid = true;
            }
            return valid ? sbWindowsAccount.ToString() : null;
        }

        /// <summary>
        /// Obtient l'adresse IP de la machine actuelle.
        /// </summary>
        /// <returns>Adresse IP de la machine actuelle, ou <value>null</value> si elle n'a pas été trouvée.</returns>
        private static string GetIpAddress()
        {
            // Obtient le nom de la machine actuelle.
            string hostName = null;
            try
            {
                hostName = Environment.MachineName;
            }
            catch
            {
                Log.Error("An error occured when trying to get local machine ip address");
            }

            // Détermine quelle est son adresse IP.
            IPAddress ipAddress = null;
            if (!string.IsNullOrEmpty(hostName))
            {
                ipAddress = GetIpAddress(hostName, true);
                if (ipAddress == null)
                    ipAddress = GetIpAddress(hostName, false);
            }
            if (ipAddress == null)
            {
                const string LOCAL_IP_ADDRESS = "127.0.0.1";
                ipAddress = GetIpAddress(LOCAL_IP_ADDRESS, true);
                if (ipAddress == null)
                    ipAddress = GetIpAddress(LOCAL_IP_ADDRESS, false);
            }

            // Renvoie le résultat.
            if (ipAddress == null)
                return null;
            return ipAddress.ToString();
        }

        /// <summary>
        /// Utilise le DNS pour obtenir l'adresse IP d'une machine.
        /// </summary>
        /// <param name="hostName">Nom de la machine recherchée.</param>
        /// <param name="IPv4"><value>true</value> si une adresse IPv4 doit être renvoyée, <value>false</value> si ce doit être une adresse IPv6.</param>
        /// <returns>Adresse IPv4/IPv6 de la machine, ou <value>null</value> si le DNS ne trouve pas cette machine.</returns>
        private static IPAddress GetIpAddress(string hostName, bool IPv4)
        {
            try
            {
                if (string.IsNullOrEmpty(hostName))
                    return null;
                IPHostEntry host = Dns.GetHostEntry(hostName);
                foreach (IPAddress ipAddress in host.AddressList)
                {
                    if (IPv4 && ipAddress.AddressFamily == AddressFamily.InterNetwork)
                        return ipAddress;
                    if (!IPv4 && ipAddress.AddressFamily == AddressFamily.InterNetworkV6)
                        return ipAddress;
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        #endregion

    }



}
