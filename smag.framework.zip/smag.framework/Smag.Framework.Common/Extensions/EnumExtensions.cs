﻿using Smag.Framework.Common.Attributes;
using System;
using System.Collections.Generic;
using System.Reflection;



namespace Smag.Framework.Common.Extensions
{



    /// <summary>
    /// Extensions de classes pour les valeurs énumérées. (Enum ..)
    /// </summary>
    public static class EnumExtensions
    {

        /// <summary>
        /// Essaie de convertir la valeur de l'attribut 'Code' vers la valeur énumérée correspondante.
        /// </summary>
        /// <typeparam name="E">Type énuméré.</typeparam>
        /// <param name="code">Code à rechercher.</param>
        /// <param name="ignoreCase">Indique si la casse doit être ignorée.</param>
        /// <returns>Valeur énumérée correspondant au code, ou <value>null</value> si aucun code ne correspond.</returns>
        public static E? FromCode<E>(string code, bool ignoreCase = true)
            where E : struct
        {
            if (string.IsNullOrEmpty(code))
                return null;
            Type type = typeof(E);
            if (!type.IsEnum)
                throw new ArgumentException("La valeur doit être une énumération.", "enumeratedValue");
            foreach (E value in (E[])Enum.GetValues(type))
            {
                string valueCode = GetCode<E>(value);
                if (string.IsNullOrEmpty(valueCode))
                    continue;
                if (string.Compare(code, valueCode, ignoreCase) == 0)
                    return value;
            }
            return null;
        }

        /// <summary>
        /// Renvoie la valeur de l'attribut 'Code' d'une valeur énumérée.
        /// </summary>
        /// <typeparam name="E">Type énuméré.</typeparam>
        /// <param name="enumeratedValue">Valeur dont le code doit être extrait.</param>
        /// <returns>Code de la valeur.</returns>
        public static string GetCode<E>(this E enumeratedValue)
            where E : struct
        {
            Type type = enumeratedValue.GetType();
            if (!type.IsEnum)
                throw new ArgumentException("La valeur doit être une énumération.", "enumeratedValue");
            MemberInfo[] memberInfo = type.GetMember(enumeratedValue.ToString());
            if (memberInfo != null && memberInfo.Length > 0)
            {
                object[] attrs = memberInfo[0].GetCustomAttributes(typeof(CodeAttribute), false);
                if (attrs != null && attrs.Length > 0)
                    return ((CodeAttribute)attrs[0]).Code;
            }
            return enumeratedValue.ToString();
        }

        /// <summary>
        /// Obtient la liste des codes d'un type énuméré.
        /// </summary>
        /// <typeparam name="E">Type énuméré.</typeparam>
        /// <param name="sort">Indique si la liste des codes doit être triée par nom.</param>
        /// <param name="unique">Indique si les doublons doivent être éliminés.</param>
        /// <returns>Liste des codes.</returns>
        public static List<string> GetCodes<E>(bool sort = true, bool unique = true)
            where E : struct
        {
            Type type = typeof(E);
            if (!type.IsEnum)
                throw new ArgumentException("La valeur doit être une énumération.", "enumeratedValue");
            List<string> codes = new List<string>();
            foreach (E value in (E[])Enum.GetValues(type))
            {
                string code = GetCode<E>(value);
                if (string.IsNullOrEmpty(code))
                    continue;
                if (!unique || !codes.Contains(code))
                    codes.Add(code);
            }
            if (sort)
                codes.Sort();
            return codes;
        }

    }



}
