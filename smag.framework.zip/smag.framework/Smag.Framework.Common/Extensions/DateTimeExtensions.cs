﻿using System;
using System.Globalization;
using System.Text;



namespace Smag.Framework.Common.Extensions
{



    /// <summary>
    /// Intervalles de temps.
    /// </summary>
    public enum TimeInterval
    {

        /// <summary>
        /// Millénaire.
        /// </summary>
        Millennium,

        /// <summary>
        /// Siècle.
        /// </summary>
        Century,

        /// <summary>
        /// Décennie.
        /// </summary>
        Decade,

        /// <summary>
        /// Année.
        /// </summary>
        Year,

        /// <summary>
        /// Mois.
        /// </summary>
        Month,

        /// <summary>
        /// Semaine.
        /// </summary>
        Week,

        /// <summary>
        /// Journée.
        /// </summary>
        Day,

        /// <summary>
        /// Heure.
        /// </summary>
        Hour,

        /// <summary>
        /// Minute.
        /// </summary>
        Minute,

        /// <summary>
        /// Seconde.
        /// </summary>
        Second

    }



    /// <summary>
    /// Extensions de classes pour les dates.
    /// </summary>
    public static class DateTimeExtensions
    {

        /// <summary>
        /// Format international d'une date.
        /// </summary>
        /// <see cref="https://docs.microsoft.com/en-us/sql/relational-databases/collations/write-international-transact-sql-statements"/>
        private const string INTERNATIONAL_DATE_FORMAT = "yyyy-MM-ddTHH:mm:ss.fff";

        /// <summary>
        /// 1er janvier 1971 à minuit.
        /// </summary>
        private static readonly DateTime s_timestampOrigin = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

        /// <summary>
        /// Transforme un temps écoulé en chaîne de caractères.
        /// </summary>
        /// <param name="duration">Temps écoulé.</param>
        /// <returns>Forme textuelle du temps écoulé.</returns>
        public static string GetFormatedString(this TimeSpan duration)
        {
            StringBuilder sb = new StringBuilder();
            if (duration.Days > 0)
                sb.AppendFormat("{0}j", duration.Days);
            if (duration.Hours > 0)
            {
                if (sb.Length > 0)
                    sb.AppendFormat(" {0:00}h", duration.Hours);
                else
                    sb.AppendFormat("{0}h", duration.Hours);
            }
            if (duration.Minutes > 0)
            {
                if (sb.Length > 0)
                    sb.AppendFormat(" {0:00}m", duration.Minutes);
                else
                    sb.AppendFormat("{0}m", duration.Minutes);
            }
            if (duration.Seconds > 0 || duration.Milliseconds > 0)
            {
                if (sb.Length > 0)
                    sb.AppendFormat(" {0:00}.{1:000}s", duration.Seconds, duration.Milliseconds);
                else
                    sb.AppendFormat("{0}.{1:000}s", duration.Seconds, duration.Milliseconds);
            }
            return sb.ToString();
        }

        /// <summary>
        /// Obtient la tranche horaire à laquelle appartient la date et heure <paramref name="date"/>.
        /// </summary>
        /// <param name="date">Date et heure.</param>
        /// <param name="startingDate">Début de la tranche horaire.</param>
        /// <param name="endingDate">Fin de la tranche horaire.</param>
        /// <param name="interval">Intervalle de la plage horaire.</param>
        public static void GetTimeSlot(this DateTime date, out DateTime startingDate, out DateTime endingDate, TimeInterval interval)
        {
            switch (interval)
            {
                case TimeInterval.Millennium:
                    startingDate = new DateTime(date.Year - (date.Year % 1000), 1, 1, 0, 0, 0);
                    endingDate = startingDate.AddYears(1000).AddTicks(-1);
                    break;

                case TimeInterval.Century:
                    startingDate = new DateTime(date.Year - (date.Year % 100), 1, 1, 0, 0, 0);
                    endingDate = startingDate.AddYears(100).AddTicks(-1);
                    break;

                case TimeInterval.Decade:
                    startingDate = new DateTime(date.Year - (date.Year % 10), 1, 1, 0, 0, 0);
                    endingDate = startingDate.AddYears(10).AddTicks(-1);
                    break;

                case TimeInterval.Year:
                    startingDate = new DateTime(date.Year, 1, 1, 0, 0, 0);
                    endingDate = startingDate.AddYears(1).AddTicks(-1);
                    break;

                case TimeInterval.Month:
                    startingDate = new DateTime(date.Year, date.Month, 1, 0, 0, 0);
                    endingDate = startingDate.AddMonths(1).AddTicks(-1);
                    break;

                case TimeInterval.Week:
                    startingDate = date.Date.AddDays(DayOfWeek.Monday - date.DayOfWeek);
                    endingDate = startingDate.AddDays(7).AddTicks(-1);
                    break;

                case TimeInterval.Day:
                    startingDate = new DateTime(date.Year, date.Month, date.Day, 0, 0, 0);
                    endingDate = startingDate.AddDays(1).AddTicks(-1);
                    break;

                case TimeInterval.Hour:
                    startingDate = new DateTime(date.Year, date.Month, date.Day, date.Hour, 0, 0);
                    endingDate = startingDate.AddHours(1).AddTicks(-1);
                    break;

                case TimeInterval.Minute:
                    startingDate = new DateTime(date.Year, date.Month, date.Day, date.Hour, date.Minute, 0);
                    endingDate = startingDate.AddMinutes(1).AddTicks(-1);
                    break;

                case TimeInterval.Second:
                    startingDate = new DateTime(date.Year, date.Month, date.Day, date.Hour, date.Minute, date.Second);
                    endingDate = startingDate.AddSeconds(1).AddTicks(-1);
                    break;

                default:
                    throw new Exception("Unknown time interval.");
            }
        }

        /// <summary>
        /// Obtient la tranche horaire à laquelle appartient la date et heure <paramref name="date"/>.
        /// </summary>
        /// <param name="date">Date et heure.</param>
        /// <param name="startingDate">Début de la tranche horaire.</param>
        /// <param name="endingDate">Fin de la tranche horaire.</param>
        /// <param name="interval">Intervalle de la plage horaire.</param>
        public static void GetTimeSlot(this DateTime? date, out DateTime? startingDate, out DateTime? endingDate, TimeInterval interval)
        {
            if (date.HasValue)
            {
                GetTimeSlot(date.Value, out startingDate, out endingDate, interval);
            }
            else
            {
                startingDate = null;
                endingDate = null;
            }
        }

        /// <summary>
        /// Obtient le n° de semaine (1.52) d'une date.
        /// </summary>
        /// <param name="date">Date.</param>
        /// <returns>N° de semaine (1.52).</returns>
        public static int GetWeek(this DateTime date)
        {
            var currentCulture = CultureInfo.CurrentCulture;
            return currentCulture.Calendar.GetWeekOfYear(date, currentCulture.DateTimeFormat.CalendarWeekRule, currentCulture.DateTimeFormat.FirstDayOfWeek);
        }

        /// <summary>
        /// Détermine quelle est la date et heure du 1er jour d'une semaine et celle du dernier jour.
        /// </summary>
        /// <param name="week">Semaine.</param>
        /// <param name="year">Année.</param>
        /// <param name="monday">Date et heure du 1er jour.</param>
        /// <param name="sunday">Date et heure à la fin du 7ème jour.</param>
        public static void GetWeek(int week, int year, out DateTime monday, out DateTime sunday)
        {
            monday = new DateTime(year, 1, 1, 0, 0, 0);
            while (monday.DayOfWeek != DayOfWeek.Monday)
                monday = monday.AddDays(1);
            if (week > 0)
                monday = monday.AddDays(7 * week);
            sunday = monday.AddDays(7).AddTicks(-1L);
        }

        /// <summary>
        /// Détermine si la date <paramref name="date"/> est incluse dans la période définie par <paramref name="start"/> et <paramref name="end"/>.
        /// </summary>
        /// <param name="date">Date à comparer.</param>
        /// <param name="start">Date de début; si elle est <value>null</value>, elle ne sera pas prise en compte.</param>
        /// <param name="end">Date de fin; si elle est <value>null</value>, elle ne sera pas prise en compte.</param>
        /// <returns><value>true</value> si <paramref name="date"/> est supérieure ou égale à <paramref name="start"/> et inférieure ou égale à <paramref name="end"/>.</returns>
        public static bool IsBetween(this DateTime date, DateTime? start, DateTime? end)
        {
            if (start.HasValue && start.Value > date)
                return false;
            if (end.HasValue && end.Value < date)
                return false;
            return true;
        }

        /// <summary>
        /// Convertit un timestamp en une date.
        /// </summary>
        /// <param name="timestamp">Nombre total de secondes écoulées depuis le 1er janvier 1970 à minuit.</param>
        /// <param name="utc">Indique si l'heure est format UTC.</param>
        /// <returns>Date correspondante.</returns>
        public static DateTime? ToDate(this long timestamp, bool utc = true)
        {
            if (timestamp < 0L)
                return null;
            TimeSpan elapsedTime = TimeSpan.FromSeconds(timestamp);
            DateTime date = s_timestampOrigin + elapsedTime;
            return utc ? date.ToLocalTime() : date;
        }

        /// <summary>
        /// Détermine le nombre total de secondes écoulées depuis le 1er janvier 1970 à minuit.
        /// </summary>
        /// <param name="date">Date et heure à convertir.</param>
        /// <param name="utc">Indique si l'heure est format UTC.</param>
        /// <returns>Timestamp correspondant.</returns>
        public static long ToTimestamp(this DateTime date, bool utc = true)
        {
            TimeSpan elapsedTime = (utc ? date : date.ToUniversalTime()) - s_timestampOrigin;
            return (long)elapsedTime.TotalSeconds;
        }

        /// <summary>
        /// Convertit une date au format international "'yyyy-MM-ddTHH:mm:ss.fff'".
        /// </summary>
        /// <param name="date">Date à convertir.</param>
        /// <returns>Chaîne représentant la date au format international.</returns>
        public static string ToInternational(this DateTime date)
        {
            return date.ToString(INTERNATIONAL_DATE_FORMAT, CultureInfo.InvariantCulture);
        }

    }



}
