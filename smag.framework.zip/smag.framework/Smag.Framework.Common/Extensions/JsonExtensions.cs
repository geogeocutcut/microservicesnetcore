﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;



namespace Smag.Framework.Common.Extensions
{



    /// <summary>
    /// Extensions de classes pour les objets JSON.
    /// </summary>
    public static class JsonExtensions
    {

        /// <summary>
        /// Expression régulière permettant de trouver une sous-chaîne subscript ("[…]").
        /// </summary>
        private static readonly Regex s_subscriptFinder = new Regex(@"\[[^\[\]]+\]");

        /// <summary>
        /// Convertit en chaîne de caractères le noeud JSON <paramref name="token"/>.
        /// </summary>
        /// <param name="token">Noeud JSON.</param>
        /// <returns>Version chaîne du noeud JSON.</returns>
        public static string Dump(this JToken token)
        {
            if (token == null)
                return null;
            return token.ToString(Formatting.Indented);
        }

        /// <summary>
        /// Obtient le nom d'un noeud JSON.
        /// </summary>
        /// <param name="token">Noeud JSON.</param>
        /// <param name="separator">Caractères séparateurs utilisés dans la conversion du chemin vers le nom.</param>
        /// <returns>Nom du noeud.</returns>
        public static string GetName(this JToken token, string separator = "/")
        {
            string[] path = token.GetPath();
            if (path == null)
                return null;
            return string.Join(separator, path);
        }

        /// <summary>
        /// Obtient le chemin d'un noeud JSON.
        /// </summary>
        /// <param name="token">Noeud JSON.</param>
        /// <returns>Chemin du noeud.</returns>
        public static string[] GetPath(this JToken token)
        {
            if (token == null)
                return null;
            string path = token.Path;
            Match m = s_subscriptFinder.Match(path);
            while (m.Success)
            {
                path = path.Replace(m.Value, "");
                m = s_subscriptFinder.Match(path);
            }
            string[] finalPath = path.Split(new char[] { '.' }, StringSplitOptions.RemoveEmptyEntries);
            if (finalPath == null || finalPath.Length < 1)
                return null;
            return finalPath;
        }

        /// <summary>
        /// Obtient la valeur d'un noeud JSON donné.
        /// </summary>
        /// <typeparam name="T">Type de la valeur stockée dans le noeud JSON.</typeparam>
        /// <param name="token">Noeud JSON.</param>
        /// <param name="name">Nom du noeud JSON.</param>
        /// <returns>Valeur du noeud.</returns>
        public static T GetValue<T>(this JToken token, string name = null)
        {
            if (token == null)
                return default(T);
            if (string.IsNullOrEmpty(name))
                return token.Value<T>();

            // Méthode 1.
            JToken value = token.SelectToken(name);
            if (value != null)
            {
                if (value.Type == JTokenType.Array)
                    return ((JArray)value).ToObject<T>();
                return value.Value<T>();
            }

            // Méthode 2.
            var baseName = token.GetName();
            if (!string.IsNullOrEmpty(baseName))
            {
                foreach (var v in token.Values())
                {
                    var valueName = v.GetName();
                    if (string.IsNullOrEmpty(valueName))
                        continue;
                    valueName = valueName.Substring(baseName.Length + 1);
                    if (string.IsNullOrEmpty(valueName))
                        continue;
                    if (string.Compare(valueName, name, true) == 0)
                        return v.Value<T>();
                }
            }
            return default(T);
        }

        /// <summary>
        /// Extrait toutes les valeurs d'un objet JSON.
        /// </summary>
        /// <param name="obj">Objet JSON.</param>
        /// <param name="values">Valeurs stockées dans l'objet JSON et ses enfants.</param>
        private static void GetValues(JObject obj, ref List<KeyValuePair<string[], string>> values)
        {
            foreach (var p in obj.Properties())
            {
                GetValues(p, ref values);
            }
        }

        /// <summary>
        /// Extrait toutes les valeurs d'un noeud JSON.
        /// </summary>
        /// <param name="token">Noeud JSON.</param>
        /// <param name="values">Valeurs stockées dans le noeud JSON et ses enfants.</param>
        private static void GetValues(JToken token, ref List<KeyValuePair<string[], string>> values)
        {
            if (token.Type == JTokenType.Object)
            {
                // Objet JSON.
                foreach (JProperty child in token.Children<JProperty>())
                    GetValues(child, ref values);
            }
            else if (token.Type == JTokenType.Array)
            {
                // Tableau JSON.
                foreach (JToken child in token.Children())
                    GetValues(child, ref values);
            }
            else if (token.Type == JTokenType.Property)
            {
                // Propriété JSON.
                foreach (JToken value in token.Values())
                    GetValues(value, ref values);
            }
            else
            {
                // Ajoute le nom et la valeur du noeud JSON actuel.
                string[] path = token.GetPath();
                string value = token.Value<string>();
                if (path != null)
                    values.Add(new KeyValuePair<string[], string>(path, value));
            }
        }

        /// <summary>
        /// Obtient la/les valeur(s) d'un noeud JSON donné.
        /// </summary>
        /// <typeparam name="T">Type des valeurs stockées dans le noeud JSON.</typeparam>
        /// <param name="token">Noeud JSON.</param>
        /// <param name="name">Nom du noeud JSON.</param>
        /// <returns>Valeur(s) du noeud.</returns>
        public static IList<T> GetValues<T>(this JToken token, string name = null)
        {
            List<T> values = new List<T>();
            if (token != null)
            {
                if (!string.IsNullOrEmpty(name))
                {
                    string[] path = token.GetPath();
                    if (path != null && path.Length >= 1 && string.Compare(path[path.Length - 1], name, true) == 0)
                        name = null;
                }
                switch (token.Type)
                {

                    case JTokenType.Array:
                        // Tableau JSON.
                        foreach (JToken child in token.Children())
                            values.AddRange(GetValues<T>(child, name));
                        break;

                    case JTokenType.Object:
                        // Objet JSON.
                        foreach (JProperty child in token.Children<JProperty>())
                            values.AddRange(GetValues<T>(child, name));
                        break;

                    case JTokenType.Property:
                        // Propriété JSON.
                        foreach (JToken child in token.Values())
                            values.AddRange(GetValues<T>(child, name));
                        break;

                    default:
                        // Noeud générique.
                        if (string.IsNullOrEmpty(name))
                        {
                            T value = token.Value<T>();
                            values.Add(value);
                        }
                        break;

                }
            }
            return values;
        }

        /// <summary>
        /// Renvoie une liste de toutes les valeurs stockées dans un objet JSON.
        /// </summary>
        /// <param name="token">Noeud JSON.</param>
        /// <returns>Liste des valeurs.</returns>
        public static List<KeyValuePair<string[], string>> GetValues(this JToken token)
        {
            List<KeyValuePair<string[], string>> values = new List<KeyValuePair<string[], string>>();
            if (token != null)
                GetValues(token, ref values);
            return values;
        }

        /// <summary>
        /// Extrait les informations stockées dans des données JSON.
        /// </summary>
        /// <param name="token">Données JSON.</param>
        /// <returns>Informations stockées dans les données JSON.</returns>
        public static IList<IDictionary<string, object>> ToDictionaries(this JToken token)
        {
            if (token == null)
                throw new ArgumentNullException("token", "Missing JSON data.");
            List<IDictionary<string, object>> data = new List<IDictionary<string, object>>();
            if (token.Type == JTokenType.String)
            {
                return ToDictionaries(JToken.Parse(token.Value<string>()));
            }
            else if (token.Type == JTokenType.Array)
            {
                foreach (JToken child in token.Children())
                    data.AddRange(child.ToDictionaries());
            }
            else
            {
                Dictionary<string, object> d = token.ToObject<Dictionary<string, object>>();
                if (d != null)
                    data.Add(d);
            }
            return data;
        }

    }



}
