﻿using System;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;



namespace Smag.Framework.Common.Extensions
{



    /// <summary>
    /// Une exception HTTP.
    /// </summary>
    public class HttpException : HttpResponseException
    {

        #region Constructeurs

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="errorCode">Code d'erreur HTTP.</param>
        /// <param name="message">Texte de l'erreur.</param>
        /// <param name="args">Arguments.</param>
        public HttpException(HttpStatusCode errorCode, string message, params object[] args)
            : base(BuildMessage(errorCode, message, args))
        {
        }

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="errorCode">Code d'erreur HTTP.</param>
        /// <param name="ex">Exception.</param>
        /// <param name="extended">Indique si le message complet de l'exception doit être inclus, ou seulement le message principal.</param>
        public HttpException(HttpStatusCode errorCode, Exception ex, bool extended)
            : base(BuildMessage(errorCode, ex, extended))
        {
        }

        #endregion

        #region Méthodes statiques

        /// <summary>
        /// Construit un message HTTP.
        /// </summary>
        /// <param name="errorCode">Code d'erreur HTTP.</param>
        /// <param name="message">Texte de l'erreur.</param>
        /// <param name="args">Arguments.</param>
        /// <returns>Message HTTP.</returns>
        public static HttpResponseMessage BuildMessage(HttpStatusCode errorCode, string message, params object[] args)
        {
            if (string.IsNullOrEmpty(message))
                return new HttpResponseMessage(errorCode);
            if (args == null || args.Length < 1)
            {
                return new HttpResponseMessage(errorCode)
                {
                    Content = new StringContent(message, Encoding.UTF8, "text/plain")
                };
            }
            else
            {
                return new HttpResponseMessage(errorCode)
                {
                    Content = new StringContent(string.Format(message, args), Encoding.UTF8, "text/plain")
                };
            }
        }

        /// <summary>
        /// Construit un message HTTP.
        /// </summary>
        /// <param name="errorCode">Code d'erreur HTTP.</param>
        /// <param name="ex">Exception.</param>
        /// <param name="extended">Indique si le message complet de l'exception doit être inclus, ou seulement le message principal.</param>
        /// <returns>Message HTTP.</returns>
        public static HttpResponseMessage BuildMessage(HttpStatusCode errorCode, Exception ex, bool extended)
        {
            if (ex == null)
                ex = new InvalidOperationException();
            return BuildMessage(errorCode, extended ? ex.GetExtendedMessage() : ex.Message);
        }

        #endregion

    }



}
