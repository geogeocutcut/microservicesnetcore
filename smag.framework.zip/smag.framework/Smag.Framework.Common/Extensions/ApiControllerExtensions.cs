﻿using Smag.Framework.Common.Logs;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Web.Http;



namespace Smag.Framework.Common.Extensions
{



    /// <summary>
    /// Extensions de classes pour Web API.
    /// </summary>
    public static class ApiControllerExtensions
    {

        #region Méthodes privées

        /// <summary>
        /// Obtient les informations sur l'utilisateur Web actuellement connecté.
        /// </summary>
        /// <param name="controller">Contrôleur Web.</param>
        /// <returns>Informations sur l'utilisateur Web.</returns>
        private static IDictionary<string, Claim> GetClaims(this ApiController controller)
        {
            try
            {
                // Utilise les informations sur l'utilisateur du contrôleur Web.
                ClaimsIdentity identity = controller?.User?.Identity as ClaimsIdentity;
                if (identity == null)
                    return new Dictionary<string, Claim>();

                // Extrait les valeurs.
                Dictionary<string, Claim> claims = new Dictionary<string, Claim>();
                foreach (var claim in identity.Claims)
                {
                    if (string.IsNullOrEmpty(claim.Type))
                        continue;
                    claims.AddOrSet(claim.Type, claim);
                }
                return claims;
            }
            catch (Exception ex)
            {
                ex.Log();
                return new Dictionary<string, Claim>();
            }
        }

        #endregion

        #region Méthodes publiques

        /// <summary>
        /// Obtient l'identifiant de l'utilisateur Web actuellement connecté.
        /// </summary>
        /// <param name="controller">Contrôleur Web.</param>
        /// <returns>Identifiant de l'utilisateur Web.</returns>
        public static string GetCurrentWebUserId(this ApiController controller)
        {
            Claim userId;
            if (!GetClaims(controller).TryGetValue("UserId", out userId))
                return null;
            return userId.Value;
        }

        /// <summary>
        /// Obtient les informations sur l'utilisateur Web actuellement connecté.
        /// </summary>
        /// <param name="controller">Contrôleur Web.</param>
        /// <param name="includeProperties">Indique si les propriétés de chaque revendication d'identité doivent être incluses, en plus du contenu de chaque revendication d'identité Web.</param>
        /// <returns>Informations sur l'utilisateur Web, ou <value>null</value> si aucun utilisateur n'a été trouvé.</returns>
        public static IDictionary<string, string> GetCurrentWebUserInformation(this ApiController controller, bool includeProperties = true)
        {
            var claims = GetClaims(controller);
            Dictionary<string, string> webUserInfo = new Dictionary<string, string>();
            foreach (var claim in claims.Values)
            {
                // Type et valeur du claim.
                webUserInfo.Add(claim.Type, claim.Value);

                // Propriétés du claim.
                int propertiesCount = (!includeProperties || claim.Properties == null) ? 0 : claim.Properties.Count;
                if (propertiesCount > 0)
                {
                    foreach (var p in claim.Properties)
                    {
                        if (string.IsNullOrEmpty(p.Key))
                            continue;
                        webUserInfo.AddOrSet(string.Format("{0}/{1}", claim.Type, p.Key), p.Value);
                    }
                }
            }
            return webUserInfo;
        }

        /// <summary>
        /// Extrait une valeur à partir de l'en-tête HTTP.
        /// </summary>
        /// <param name="controller">Contrôleur Web.</param>
        /// <param name="key">Nom de la valeur dans l'en-tête HTTP.</param>
        /// <param name="removeEmptyValues">Indique si les valeurs vides doivent être supprimées.</param>
        /// <param name="separator">Chaîne utilisée pour concaténer les différentes valeurs (dans le cas où la clé est définie plusieurs fois dans l'en-tête HTTP). Si <value>null</value> alors la méthode renverra <value>null</value> si plusieurs valeurs sont définies dans l'en-tête HTTP avec la même clé.</param>
        /// <param name="trim">Indique si les blancs au début et à la fin de chaque valeur doivent supprimés.</param>
        /// <returns>Valeur de la donnée <paramref name="key"/>, ou <value>null</value> s'il n'y en a pas dans l'en-tête HTTP.</returns>
        public static string GetHeaderValue(this ApiController controller, string key, bool removeEmptyValues = false, string separator = null, bool trim = false)
        {
            List<string> values = GetHeaderValues(controller, key, removeEmptyValues, trim);
            if (values.Count < 1)
                return null;
            if (values.Count == 1)
                return values[0];
            if (separator == null)
                return null;
            return string.Join(separator, values);
        }

        /// <summary>
        /// Extrait des valeurs à partir de l'en-tête HTTP.
        /// </summary>
        /// <param name="controller">Contrôleur Web.</param>
        /// <param name="key">Nom de la valeur dans l'en-tête HTTP.</param>
        /// <param name="removeEmptyValues">Indique si les valeurs vides doivent être supprimées.</param>
        /// <param name="trim">Indique si les blancs au début et à la fin de chaque valeur doivent supprimés.</param>
        /// <returns>Valeurs de la donnée <paramref name="key"/>.</returns>
        public static List<string> GetHeaderValues(this ApiController controller, string key, bool removeEmptyValues = false, bool trim = false)
        {
            try
            {
                IEnumerable<string> headerValues = null;
                if (!controller.Request.Headers.TryGetValues(key, out headerValues))
                    return new List<string>();
                List<string> values = new List<string>();
                foreach (string hv in headerValues)
                {
                    foreach (string v in hv.Split(new string[1] { ", " }, removeEmptyValues ? StringSplitOptions.RemoveEmptyEntries : StringSplitOptions.None))
                    {
                        if (removeEmptyValues)
                        {
                            if (trim && string.IsNullOrWhiteSpace(v))
                                continue;
                            if (string.IsNullOrEmpty(v))
                                continue;
                        }
                        values.Add(trim ? v.Trim() : v);
                    }
                }
                return values;
            }
            catch
            {
                return new List<string>();
            }
        }

        #endregion

    }



}
