﻿using System;
using System.ComponentModel;
using System.Net;
using System.Text;
using System.Web.Http;



namespace Smag.Framework.Common.Extensions
{



    /// <summary>
    /// Extensions de classes pour les exceptions.
    /// </summary>
    public static class ExceptionExtensions
    {

        #region Méthodes publiques

        /// <summary>
        /// Obtient la description de l'erreur, avec son erreur interne.
        /// </summary>
        /// <param name="ex">Exception.</param>
        /// <returns>Message complet de l'erreur.</returns>
        public static string GetExtendedMessage(this Exception ex)
        {
            StringBuilder errorMessage = null;
            if (ex != null)
            {
                string indent = null;
                while (ex != null)
                {
                    string message = ex.Message?.Trim();
                    if (!string.IsNullOrEmpty(message))
                    {
                        if (errorMessage == null)
                        {
                            errorMessage = new StringBuilder(message);
                            indent = "\n    ";
                        }
                        else
                        {
                            errorMessage.Append(indent);
                            errorMessage.Append(message.Replace("\n", indent));
                            indent += "    ";
                        }
                    }
                    ex = ex.InnerException;
                }
            }
            return errorMessage?.ToString();
        }

        /// <summary>
        /// Renvoie l'exception initiale. (La plus interne)
        /// </summary>
        /// <param name="ex">Exception à examiner.</param>
        /// <returns>Exception la plus interne.</returns>
        public static Exception GetInitialException(this Exception ex)
        {
            Exception initialException = null;
            while (ex != null)
            {
                initialException = ex;
                ex = ex.InnerException;
            }
            return initialException;
        }

        /// <summary>
        /// S'il s'agit d'une erreur HTTP, retourne la raison de l'erreur; sinon, retourne le message de l'erreur.
        /// </summary>
        /// <param name="ex">Exception.</param>
        /// <returns>Message d'erreur ou raison HTTP.</returns>
        public static string GetReason(this Exception ex)
        {
            // Détermine s'il s'agit d'une exception HTTP.
            if (ex == null)
                return null;
            HttpResponseException e = ex as HttpResponseException;
            if (e == null || e.Response == null)
                return ex.GetInitialException().Message;

            // Extrait la raison de l'erreur HTTP.
            string reason = null;
            if (e.Response.Content != null)
                reason = e.Response.Content.ReadAsStringAsync().Result.TrimmedOrNull();
            if (string.IsNullOrEmpty(reason))
                reason = e.Response.ReasonPhrase;
            return reason;
        }

        /// <summary>
        /// Obtient le code d'erreur Win32 correspondant à l'exception actuelle.
        /// </summary>
        /// <param name="ex">Exception.</param>
        /// <returns>Code d'erreur Win32 s'il s'agit d'une exception Win32, <value>null</value> sinon.</returns>
        public static int? GetWin32ErrorCode(this Exception ex)
        {
            Win32Exception winEx = ex as Win32Exception;
            if (winEx != null)
                return winEx.ErrorCode;
            if (ex.InnerException == null)
                return null;
            return GetWin32ErrorCode(ex.InnerException);
        }

        /// <summary>
        /// Convertit l'exception actuelle en exception HTTP.
        /// </summary>
        /// <param name="ex">Exception.</param>
        /// <param name="errorCode"></param>
        /// <param name="extended"></param>
        /// <returns></returns>
        public static HttpException ToHttp(this Exception ex, HttpStatusCode errorCode = HttpStatusCode.BadRequest, bool extended = true)
        {
            return new HttpException(errorCode, ex, extended);
        }

        #endregion

    }



}
