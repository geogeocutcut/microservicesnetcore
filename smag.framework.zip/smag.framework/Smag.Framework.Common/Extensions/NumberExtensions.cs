﻿using System;



namespace Smag.Framework.Common.Extensions
{



    public static class NumberExtensions
    {

        /// <summary>
        /// Détermine si <paramref name="a"/> == <paramref name="b"/> à <paramref name="digitsCount"/>
        /// </summary>
        /// <param name="a">Valeur actuelle.</param>
        /// <param name="b">Valeur à comparer.</param>
        /// <param name="digitsCount">Nombre de décimales à prendre dans la comparaison.</param>
        /// <returns><value>true</value> si <paramref name="a"/> == <paramref name="b"/>, <value>false</value> si <paramref name="a"/> != <paramref name="b"/>.</returns>
        public static bool IsEqualTo(this decimal? a, decimal? b, int digitsCount = -1)
        {
            if (!a.HasValue)
                return !b.HasValue;
            if (!b.HasValue)
                return false;
            if (digitsCount < 0)
                return a.Value.Equals(b.Value);
            return Math.Round(a.Value, digitsCount).Equals(Math.Round(b.Value, digitsCount));
        }

        /// <summary>
        /// Détermine si <paramref name="a"/> == <paramref name="b"/> à <paramref name="digitsCount"/>
        /// </summary>
        /// <param name="a">Valeur actuelle.</param>
        /// <param name="b">Valeur à comparer.</param>
        /// <param name="digitsCount">Nombre de décimales à prendre dans la comparaison.</param>
        /// <returns><value>true</value> si <paramref name="a"/> == <paramref name="b"/>, <value>false</value> si <paramref name="a"/> != <paramref name="b"/>.</returns>
        public static bool IsEqualTo(this double? a, double? b, int digitsCount = -1)
        {
            if (!a.HasValue)
                return !b.HasValue;
            if (!b.HasValue)
                return false;
            if (digitsCount < 0)
                return a.Value.Equals(b.Value);
            return Math.Round(a.Value, digitsCount).Equals(Math.Round(b.Value, digitsCount));
        }

        /// <summary>
        /// Calcule le modulo de <paramref name="a"/> par <paramref name="b"/>.
        /// </summary>
        /// <param name="a">Nombre à diviser.</param>
        /// <param name="b">Diviseur.</param>
        /// <returns>Reste de la division de <paramref name="a"/> par <paramref name="b"/>.</returns>
        /// <remarks>Le modulo du C# (a % b) calcule de façon incorrecte le reste pour les nombres négatifs.</remarks>
        public static decimal mod(this decimal a, decimal b)
        {
            return a - b * Math.Floor(a / b);
        }

        /// <summary>
        /// Calcule le modulo de <paramref name="a"/> par <paramref name="b"/>.
        /// </summary>
        /// <param name="a">Nombre à diviser.</param>
        /// <param name="b">Diviseur.</param>
        /// <returns>Reste de la division de <paramref name="a"/> par <paramref name="b"/>.</returns>
        /// <remarks>Le modulo du C# (a % b) calcule de façon incorrecte le reste pour les nombres négatifs.</remarks>
        public static double mod(this double a, double b)
        {
            return a - b * Math.Floor(a / b);
        }

        /// <summary>
        /// Calcule le modulo de <paramref name="a"/> par <paramref name="b"/>.
        /// </summary>
        /// <param name="a">Nombre à diviser.</param>
        /// <param name="b">Diviseur.</param>
        /// <returns>Reste de la division de <paramref name="a"/> par <paramref name="b"/>.</returns>
        /// <remarks>Le modulo du C# (a % b) calcule de façon incorrecte le reste pour les nombres négatifs.</remarks>
        public static float mod(this float a, float b)
        {
            return a - b * (float)Math.Floor((double)a / (double)b);
        }

        /// <summary>
        /// Calcule le modulo de <paramref name="a"/> par <paramref name="b"/>.
        /// </summary>
        /// <param name="a">Nombre à diviser.</param>
        /// <param name="b">Diviseur.</param>
        /// <returns>Reste de la division de <paramref name="a"/> par <paramref name="b"/>.</returns>
        /// <remarks>Le modulo du C# (a % b) calcule de façon incorrecte le reste pour les nombres négatifs.</remarks>
        public static int mod(this int a, int b)
        {
            int m = a % b;
            return (m < 0) ? (b + m) : m;
        }

        /// <summary>
        /// Calcule le modulo de <paramref name="a"/> par <paramref name="b"/>.
        /// </summary>
        /// <param name="a">Nombre à diviser.</param>
        /// <param name="b">Diviseur.</param>
        /// <returns>Reste de la division de <paramref name="a"/> par <paramref name="b"/>.</returns>
        /// <remarks>Le modulo du C# (a % b) calcule de façon incorrecte le reste pour les nombres négatifs.</remarks>
        public static long mod(this long a, long b)
        {
            long m = a % b;
            return (m < 0) ? (b + m) : m;
        }

        /// <summary>
        /// Convertit un angle en radians en angle en degrés.
        /// </summary>
        /// <param name="radians">Angle en radians.</param>
        /// <returns>Angle en degrés.</returns>
        public static double ToDegrees(this double radians)
        {
            return (180.0 / Math.PI) * radians;
        }

        /// <summary>
        /// Convertit un angle en degrés en angle en radians.
        /// </summary>
        /// <param name="degrees">Angle en degrés.</param>
        /// <returns>Angle en radians.</returns>
        public static double ToRadians(this double degrees)
        {
            return (Math.PI / 180.0) * degrees;
        }

    }



}
