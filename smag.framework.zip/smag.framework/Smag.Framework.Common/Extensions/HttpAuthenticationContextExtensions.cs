﻿using System.Linq;
using System.Web.Http;
using System.Web.Http.Filters;



namespace Smag.Framework.Common.Extensions
{



    public static class HttpAuthenticationContextExtensions
    {

        /// <summary>
        /// Détermine si la méthode Web appelée autorise les appels anonymes.
        /// </summary>
        /// <param name="context"></param>
        /// <returns><value>true</value> si la méthode Web appelée autorise les appels anonymes, <value>false</value> sinon.</returns>
        public static bool SkipAuthentication(this HttpAuthenticationContext context)
        {
            if (context.ActionContext.ActionDescriptor.GetCustomAttributes<AllowAnonymousAttribute>().Any())
                return true;
            return context.ActionContext.ControllerContext.ControllerDescriptor.GetCustomAttributes<AllowAnonymousAttribute>().Any();
        }
    }



}
