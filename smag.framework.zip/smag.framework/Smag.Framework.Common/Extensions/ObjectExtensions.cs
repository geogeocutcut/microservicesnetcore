﻿using System;



namespace Smag.Framework.Common.Extensions
{



    /// <summary>
    /// Extensions de classes pour les 'object'.
    /// </summary>
    public static class ObjectExtensions
    {

        /// <summary>
        /// Détermine si l'objet est une valeur numérique (float, double, int, ..).
        /// </summary>
        /// <param name="value">Objet à tester.</param>
        /// <returns><value>true</value> si l'objet est un numérique, <value>false</value> sinon.</returns>
        public static bool IsNumeric(this object value)
        {
            if (value == null)
                return false;
            return IsNumeric(value.GetType());
        }

        /// <summary>
        /// Détermine si le type <paramref name="type"/> représente une valeur numérique.
        /// </summary>
        /// <param name="type">Type à tester.</param>
        /// <returns><value>true</value> si le type est numérique, <value>false</value> sinon.</returns>
        public static bool IsNumeric(Type type)
        {
            return IsNumeric(type, Type.GetTypeCode(type));
        }

        /// <summary>
        /// Détermine si le type <paramref name="type"/> représente une valeur numérique.
        /// </summary>
        /// <param name="type">Type à tester.</param>
        /// <param name="typeCode">Code du type.</param>
        /// <returns><value>true</value> si le type est numérique, <value>false</value> sinon.</returns>
        public static bool IsNumeric(Type type, TypeCode typeCode)
        {
            return (typeCode == TypeCode.Decimal || (type.IsPrimitive && typeCode != TypeCode.Object && typeCode != TypeCode.Boolean && typeCode != TypeCode.Char));
        }

        /// <summary>
        /// Essaie de convertir un objet en un autre.
        /// </summary>
        /// <typeparam name="T">Type dans lequel</typeparam>
        /// <param name="value">Objet à convertir.</param>
        /// <param name="result">Objet converti.</param>
        /// <param name="exact">Exactitude de la conversion.</param>
        /// <returns><value>true</value> si la conversion a réussi, <value>false</value> sinon.</returns>
        public static bool TryConvertTo<T>(this object value, out T result, bool exact = false)
        {
            try
            {
                // Cas spécial : 'null'
                if (value == null)
                {
                    result = default(T);
                    return !exact;
                }

                // Null.
                Type t = typeof(T);
                Type u = Nullable.GetUnderlyingType(t);
                if (u != null)
                {
                    result = default(T);
                    return true;
                }

                // Cas usuel.
                if (value is IConvertible)
                {
                    if (u == null)
                        result = (T)Convert.ChangeType(value, t);
                    else
                        result = (T)Convert.ChangeType(value, u);
                    return true;
                }

                // Autres cas.
                Type from = value.GetType();
                if (from == t)
                {
                    result = (T)value;
                    return true;
                }
                if (!exact && from.IsSubclassOf(t))
                {
                    result = (T)value;
                    return true;
                }

                // Échec.
                result = default(T);
                return false;
            }
            catch
            {
                result = default(T);
                return false;
            }
        }

    }



}
