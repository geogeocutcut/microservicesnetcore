﻿using System;
using System.Globalization;
using System.Linq;
using System.Text;



namespace Smag.Framework.Common.Extensions
{



    /// <summary>
    /// Extensions de classes pour les chaînes de caractères.
    /// </summary>
    public static class StringExtensions
    {

        #region Constantes

        /// <summary>
        /// Formats de date.
        /// </summary>
        private static string[] DATE_FORMATS;

        /// <summary>
        /// Culture américaine.
        /// </summary>
        private static readonly CultureInfo EN_US = CultureInfo.GetCultureInfo("en-US");

        /// <summary>
        /// Culture française.
        /// </summary>
        private static readonly CultureInfo FR_FR = CultureInfo.GetCultureInfo("fr-FR");

        #endregion

        #region Constructeur

        /// <summary>
        /// Constructeur statique.
        /// </summary>
        static StringExtensions()
        {
            DATE_FORMATS = (
                new string[] { "M-d-yyyy", "dd-MM-yyyy", "MM-dd-yyyy", "M.d.yyyy", "dd.MM.yyyy", "MM.dd.yyyy" }
                .Union(FR_FR.DateTimeFormat.GetAllDateTimePatterns())
                .Union(EN_US.DateTimeFormat.GetAllDateTimePatterns())
                ).ToArray();
        }

        #endregion

        #region Méthodes

        /// <summary>
        /// Retourne une version du texte <paramref name="text"/> où la première lettre de chaque mot est en capitale, et les autres lettres sont en minuscules.
        /// </summary>
        /// <param name="text">Texte à traiter.</param>
        /// <returns>Texte d'origine avec les premières lettres de chaque mot en capitales et les autres lettres en minuscules.</returns>
        public static string Capitalized(this string text)
        {
            if (string.IsNullOrWhiteSpace(text))
                return text;
            StringBuilder sbCapitalizedText = new StringBuilder();
            bool capitalize = true;
            foreach (var c in text)
            {
                if (char.IsLetter(c))
                {
                    if (capitalize)
                    {
                        sbCapitalizedText.Append(char.ToUpper(c));
                        capitalize = false;
                    }
                    else
                    {
                        sbCapitalizedText.Append(char.ToLower(c));
                    }
                }
                else
                {
                    sbCapitalizedText.Append(c);
                    capitalize = true;
                }
            }
            return sbCapitalizedText.ToString();
        }

        /// <summary>
        /// Convertit en <paramref name="dstFormat"/> la chaîne de caractères actuellement encodée en <paramref name="srcFormat"/>.
        /// </summary>
        /// <param name="text">Chaîne de caractères encodée en <paramref name="srcFormat"/>.</param>
        /// <param name="srcFormat">Encodage source.</param>
        /// <param name="dstFormat">Encodage cible.</param>
        /// <param name="force">Indique si la fonction doit convertir directement <paramref name="text"/> en un tableau d'octets plutôt que de faire appel à la méthode <see cref="Encoding.GetBytes(string)"/>.</param>
        /// <returns>Chaîne de caractères encodée en <paramref name="dstFormat"/>.</returns>
        public static string Convert(this string text, Encoding srcFormat, Encoding dstFormat, bool force)
        {
            if (string.IsNullOrEmpty(text))
                return text;
            byte[] srcBytes;
            if (force)
                srcBytes = text.ToCharArray().Select(c => (byte)c).ToArray();
            else
                srcBytes = srcFormat.GetBytes(text);
            byte[] dstBytes = Encoding.Convert(srcFormat, dstFormat, srcBytes);
            return dstFormat.GetString(dstBytes);
        }

        /// <summary>
        /// Convertit du texte au format UTF-8 en texte au format Unicode (UTF-16).
        /// </summary>
        /// <param name="text">Texte au format UTF-8.</param>
        /// <param name="force">Indique si la fonction doit convertir directement <paramref name="text"/> en un tableau d'octets plutôt que de faire appel à la méthode <see cref="Encoding.GetBytes(string)"/>.</param>
        /// <returns>Texte au format Unicode (UTF-16).</returns>
        public static string DecodeUtf8(this string text, bool force = true)
        {
            return Convert(text, Encoding.UTF8, Encoding.Unicode, force);
        }

        /// <summary>
        /// Détermine si le caractère <paramref name="c"/> est une consonne.
        /// </summary>
        /// <param name="c">Caractère à tester.</param>
        /// <returns><value>true</value> si <paramref name="c"/> est une consonne, <value>false</value> sinon.</returns>
        public static bool IsConsonant(this char c)
        {
            return "bcçdfghjklmnñpqrstvwxzBCÇDFGHJKLMNÑPQRSTVWXZ".IndexOf(c) >= 0;
        }

        /// <summary>
        /// Détermine si le dernier caractère du chemin <paramref name="path"/> est un caractère de séparation de chemin.
        /// </summary>
        /// <param name="path">Chemin à tester.</param>
        /// <returns><value>true</value> si le dernier caractère est un caractère de séparation de chemin, <value>false</value> sinon.</returns>
        public static bool IsEndingWithPathSeparator(this string path)
        {
            if (string.IsNullOrEmpty(path))
                return false;
            return IsPathSeparator(path[path.Length - 1]);
        }

        /// <summary>
        /// Détermine si une chaîne n'est composée uniquement que de lettres et de chiffres.
        /// </summary>
        /// <param name="text">Chaîne à examiner.</param>
        /// <returns><value>true</value> si la chaîne <paramref name="text"/> n'est pas vide et composée uniquement de lettres et de chiffres, <value>false</value> sinon.</returns>
        public static bool IsOnlyComposedOfDigitsOrLetters(this string text)
        {
            if (string.IsNullOrEmpty(text))
                return false;
            foreach (char c in text)
            {
                if (!char.IsLetterOrDigit(c))
                    return false;
            }
            return true;
        }

        /// <summary>
        /// Détermine si le caractère <paramref name="c"/> est un caractère de séparation de chemin.
        /// </summary>
        /// <param name="c">Caractère à tester.</param>
        /// <returns><value>true</value> si <paramref name="c"/> est un caractère de séparation de chemin, <value>false</value> sinon.</returns>
        public static bool IsPathSeparator(this char c)
        {
            return (c == '/' || c == '\\');
        }

        /// <summary>
        /// Détermine si le caractère <paramref name="c"/> est une voyelle.
        /// </summary>
        /// <param name="c">Caractère à tester.</param>
        /// <returns><value>true</value> si <paramref name="c"/> est une voyelle, <value>false</value> sinon.</returns>
        public static bool IsVowel(this char c)
        {
            return "aeiouyàâäéèêëôöùûüAEIOUYÀÂÄÉÈÊËÔÖÙÛÜ".IndexOf(c) >= 0;
        }

        /// <summary>
        /// Tronque la chaîne de caractères actuelle si sa longueur dépasse <paramref name="maxLength"/> caractères.
        /// </summary>
        /// <param name="text"></param>
        /// <param name="maxLength">Longueur maximale de la chaîne.</param>
        /// <returns>Chaîne <paramref name="text"/> éventuellement tronquée.</returns>
        public static string Limit(this string text, int maxLength)
        {
            int length = (text == null) ? 0 : text.Length;
            if (length < 1)
                return text;
            if (maxLength < 1)
                return string.Empty;
            if (length <= maxLength)
                return text;
            return text?.Substring(0, maxLength);
        }

        /// <summary>
        /// Extrait la date et l'heure représentées dans la chaîne de caractères.
        /// </summary>
        /// <param name="value">Chaîne à convertir.</param>
        /// <param name="utc">Indique si la chaîne <paramref name="value"/> représente une date au format UTC (si <value>true</value>), ou local (si <value>false</value>).</param>
        /// <returns>Date représentée dans <paramref name="value"/>, ou <value>null</value> si la chaîne ne représentait pas de date.</returns>
        public static DateTime? ToDate(this string value, bool utc = false)
        {
            string v = value.TrimmedOrNull();
            if (string.IsNullOrEmpty(v))
                return null;
            DateTime date;
            if (utc && DateTime.TryParseExact(v, DATE_FORMATS, EN_US, DateTimeStyles.AssumeUniversal, out date))
                return date;
            if (!utc && DateTime.TryParseExact(v, DATE_FORMATS, EN_US, DateTimeStyles.AssumeLocal, out date))
                return date;
            return null;
        }

        /// <summary>
        /// Extrait le nombre décimal représenté dans la chaîne de caractères.
        /// </summary>
        /// <param name="value">Chaîne à convertir.</param>
        /// <param name="trim">Indique si la fonction doit ignorer les éventuels espaces situés au début ou à la fin de la chaîne.</param>
        /// <returns>Nombre décimal représenté dans la chaîne de caractères, ou <value>null</value> si la chaîne ne représentait pas de nombre décimal.</returns>
        public static double? ToDouble(this string value, bool trim = true)
        {
            string v = trim ? value?.Trim() : value;
            if (string.IsNullOrEmpty(v) || v.Equals("NaN", StringComparison.InvariantCultureIgnoreCase))
                return null;
            double result;
            if (double.TryParse(value, NumberStyles.Any, EN_US.NumberFormat, out result) ||
                double.TryParse(value, NumberStyles.Any, FR_FR.NumberFormat, out result) ||
                double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out result)
                )
                return result;
            return null;
        }

        /// <summary>
        /// Supprime les blancs au début et à la fin d'une chaîne.
        /// </summary>
        /// <param name="text">Texte à traiter.</param>
        /// <returns>La chaîne sans les blancs au début et en fin, ou <value>null</value> si la chaîne est nulle, vide ou ne contient que des blancs.</returns>
        public static string TrimmedOrNull(this string text)
        {
            if (string.IsNullOrWhiteSpace(text))
                return null;
            return text.Trim();
        }

        #endregion

    }



}
