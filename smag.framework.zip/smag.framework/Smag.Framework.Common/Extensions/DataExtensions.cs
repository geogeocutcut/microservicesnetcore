﻿using System;
using System.Data;
using System.Text;

namespace Smag.Framework.Common.Extensions
{



    /// <summary>
    /// Extensions de classes pour les DataRow, DataTable, ..
    /// </summary>
    public static class DataExtensions
    {

        /// <summary>
        /// Obtient la date stockée dans la ligne actuelle à la colonne <paramref name="columnIndex"/>.
        /// </summary>
        /// <param name="row">Ligne du DataSet contenant les données.</param>
        /// <param name="columnIndex">Index (0.) de la colonne.</param>
        /// <returns>Date, ou <value>null</value> si la cellule ne contient pas de date.</returns>
        public static DateTime? GetDate(this DataRow row, int columnIndex)
        {
            try
            {
                string value = GetString(row, columnIndex);
                if (string.IsNullOrEmpty(value))
                    return null;
                DateTime? date;
                if (value.TryConvertTo<DateTime?>(out date))
                    return date;
                return null;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Obtient la chaîne de caractères stockée dans la ligne actuelle à la colonne <paramref name="columnIndex"/>.
        /// </summary>
        /// <param name="row">Ligne du DataSet contenant les données.</param>
        /// <param name="columnIndex">Index (0.) de la colonne.</param>
        /// <returns>Chaîne de caractères, ou <value>null</value> si la cellule ne contient pas de chaîne de caractères.</returns>
        public static string GetString(this DataRow row, int columnIndex)
        {
            try
            {
                object value = row[columnIndex];
                if (value == null)
                    return null;
                return value as string;
            }
            catch
            {
                return null;
            }
        }

    }



}
