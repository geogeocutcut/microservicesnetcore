﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;



namespace Smag.Framework.Common.Extensions
{



    /// <summary>
    /// Extensions de classes pour les dictionnaires.
    /// </summary>
    public static class DictionaryExtensions
    {

        /// <summary>
        /// Ajoute ou met à jour la valeur <paramref name="value"/> pour la clé <paramref name="key"/>.
        /// </summary>
        /// <typeparam name="K">Type de clé.</typeparam>
        /// <typeparam name="V">Type de valeur.</typeparam>
        /// <param name="dico">Dictionnaire contenant les données.</param>
        /// <param name="key">Clé.</param>
        /// <param name="value">Nouvelle valeur.</param>
        public static void AddOrSet<K, V>(this IDictionary<K, V> dico, K key, V value)
        {
            if (dico != null)
            {
                if (dico.ContainsKey(key))
                    dico[key] = value;
                else
                    dico.Add(key, value);
            }
        }

        /// <summary>
        /// Extrait une date à partir du dictionnaire <paramref name="dico"/>.
        /// </summary>
        /// <typeparam name="K">Type des clés.</typeparam>
        /// <typeparam name="V">Type des valeurs.</typeparam>
        /// <param name="dico">Dictionnaire contenant les valeurs classées par clés.</param>
        /// <param name="keys">Nom(s) de la valeur à extraire.</param>
        /// <returns>Valeur associée à la première clé correspondante, ou <value>null</value> si aucune clé ne correspond.</returns>
        public static DateTime? GetDate<K, V>(this IDictionary<K, V> dico, params K[] keys)
        {
            return GetFirstOrDefaultAndConvert<K, V, DateTime?>(dico, keys);
        }

        /// <summary>
        /// Obtient la 1ère valeur correspondant à l'une des clés <paramref name="keys"/> fournies.
        /// </summary>
        /// <typeparam name="K">Type des clés.</typeparam>
        /// <typeparam name="V">Type des valeurs.</typeparam>
        /// <param name="dico">Dictionnaire contenant les valeurs classées par clés.</param>
        /// <param name="keys">Clés à rechercher.</param>
        /// <returns>Valeur de la 1ère clé de <paramref name="keys"/> présente dans <paramref name="dico"/>; si aucune clé n'est trouvée, alors la valeur par défaut sera renvoyée.</returns>
        public static V GetFirstOrDefault<K, V>(this IDictionary<K, V> dico, params K[] keys)
        {
            if (dico == null || keys == null)
                return default(V);
            foreach (K key in keys)
            {
                V value;
                if (dico.TryGetValue(key, out value))
                    return value;
            }
            return default(V);
        }

        /// <summary>
        /// Obtient la 1ère valeur correspondant à l'une des clés <paramref name="keys"/> fournies, et la convertit en un objet de type <typeparamref name="R"/>.
        /// </summary>
        /// <typeparam name="K">Type des clés.</typeparam>
        /// <typeparam name="V">Type des valeurs.</typeparam>
        /// <typeparam name="R">Type de la valeur de retour.</typeparam>
        /// <param name="dico">Dictionnaire contenant les valeurs classées par clés.</param>
        /// <param name="keys">Clés à rechercher.</param>
        /// <returns>Valeur de la 1ère clé de <paramref name="keys"/> présente dans <paramref name="dico"/>; si aucune clé n'est trouvée, alors la valeur par défaut sera renvoyée.</returns>
        public static R GetFirstOrDefaultAndConvert<K, V, R>(this IDictionary<K, V> dico, params K[] keys)
        {
            if (dico == null || keys == null)
                return default(R);
            foreach (K key in keys)
            {
                V value;
                if (!dico.TryGetValue(key, out value))
                    continue;
                R convertedValue;
                if (!value.TryConvertTo<R>(out convertedValue, true))
                    break;
                return convertedValue;
            }
            return default(R);
        }

        /// <summary>
        /// Extrait du JSON à partir du dictionnaire <paramref name="dico"/>.
        /// </summary>
        /// <typeparam name="K">Type des clés.</typeparam>
        /// <typeparam name="V">Type des valeurs.</typeparam>
        /// <param name="dico">Dictionnaire contenant les valeurs classées par clés.</param>
        /// <param name="keys">Nom(s) de la valeur à extraire.</param>
        /// <returns>Valeur associée à la première clé correspondante, ou <value>null</value> si aucune clé ne correspond.</returns>
        public static JObject GetJObject<K, V>(this IDictionary<K, V> dico, params K[] keys)
        {
            return GetFirstOrDefaultAndConvert<K, V, JObject>(dico, keys);
        }

        /// <summary>
        /// Extrait une chaîne de caractères à partir du dictionnaire <paramref name="dico"/>.
        /// </summary>
        /// <typeparam name="K">Type des clés.</typeparam>
        /// <typeparam name="V">Type des valeurs.</typeparam>
        /// <param name="dico">Dictionnaire contenant les valeurs classées par clés.</param>
        /// <param name="keys">Nom(s) de la valeur à extraire.</param>
        /// <returns>Valeur associée à la première clé correspondante, ou <value>null</value> si aucune clé ne correspond.</returns>
        public static string GetString<K, V>(this IDictionary<K, V> dico, params K[] keys)
        {
            return GetFirstOrDefaultAndConvert<K, V, string>(dico, keys);
        }

    }



}
