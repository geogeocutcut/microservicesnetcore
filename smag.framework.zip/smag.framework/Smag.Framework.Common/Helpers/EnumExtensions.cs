﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace Smag.Framework.Common.Helpers
{
    public static class EnumExtensions
    {
        public static string ShortName(this Enum enu)
        {
            var attr = GetDisplayAttribute(enu);
            return attr != null
                ? attr.ShortName
                : enu.ToString();
        }

        public static string Name(this Enum enu)
        {
            var attr = GetDisplayAttribute(enu);
            return attr != null
                ? attr.Name
                : enu.ToString();
        }

        public static string Description(this Enum enu)
        {
            var attr = GetDisplayAttribute(enu);
            return attr != null
                ? attr.Description
                : enu.ToString();
        }

        private static DisplayAttribute GetDisplayAttribute(object value)
        {
            var type = value.GetType();
            if (!type.IsEnum)
                throw new ArgumentException($"Type {type} is not an enum");

            // Get the enum field.
            var field = type.GetField(value.ToString());
            return field?.GetCustomAttribute<DisplayAttribute>();
        }
    }
}