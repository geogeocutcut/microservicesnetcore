﻿
using System.Collections.Generic;

namespace Smag.Framework.Common.Mapper
{
    public abstract class AbstractGenericMapper<TEntityData, TEntity> : IGenericMapper<TEntityData, TEntity>
    {
        public AbstractGenericMapper()
        {
        }


        public TEntity Transform(TEntityData source)
        {
            if (source == null) return CreateDefault<TEntity>();
            TEntity result = DoTransformation(source);
            return result;
        }
        public TEntityData Transform(TEntity source)
        {
            if (source == null) return CreateDefault<TEntityData>();
            TEntityData result = DoTransformation(source);
            return result;
        }

        public IList<TEntity> Transform(IList<TEntityData> sources)
        {
            IList<TEntity> result = new List<TEntity>();
            if (sources != null)
            {
                foreach(TEntityData source in sources)
                {
                    result.Add(Transform(source));
                }
            }
            return result;
        }
        public IList<TEntityData> Transform(IList<TEntity> sources)
        {
            IList<TEntityData> result = new List<TEntityData>();
            if (sources != null)
            {
                foreach (TEntity source in sources)
                {
                    result.Add(Transform(source));
                }
            }
            return result;
        }

        public object Transform(object source)
        {
            throw new System.NotImplementedException();
        }

        protected T CreateDefault<T>()
        {
            return default(T);
        }

        protected abstract TEntity DoTransformation(TEntityData source);
        protected abstract TEntityData DoTransformation(TEntity source);
    }
}
