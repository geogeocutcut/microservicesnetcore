﻿

namespace Smag.Framework.Common.Mapper
{
    public interface IMapper
    {
        object Transform(object source);
    }
}
