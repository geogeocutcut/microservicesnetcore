﻿
using System.Collections.Generic;

namespace Smag.Framework.Common.Mapper
{
    public interface IGenericMapper<TEntity, TEntityDTO> : IMapper
    {
        TEntityDTO Transform(TEntity source);
        TEntity Transform(TEntityDTO source);


        IList<TEntityDTO> Transform(IList<TEntity> sources);
        IList<TEntity> Transform(IList<TEntityDTO> sources);
    }
}
