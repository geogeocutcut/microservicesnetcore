﻿using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.CompilerServices;
using System.Text;

namespace Smag.Framework.Common.Test
{
    public class TestBase<T> where T : class
    {
        private HttpClient _client;
        private string _jwt;
        private string _testUri;

        public TestBase(string jwt, string testUri)
        {
            _jwt = jwt;
            _testUri = testUri;
            _client = new HttpClient();

            _client.DefaultRequestHeaders.Accept.Clear();
            _client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/x-www-form-urlencoded"));
            _client.DefaultRequestHeaders.Add("Bearer", "token_wso2");
            _client.DefaultRequestHeaders.Add("SmagAuthorization", "Bearer " + _jwt);
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        public static string GetCurrentMethod()
        {
            StackTrace st = new StackTrace();
            StackFrame sf = st.GetFrame(1);

            return sf.GetMethod().Name;
        }

        public void Create(T dto)
        {
            try
            {
                string content = JsonConvert.SerializeObject(dto);

                HttpResponseMessage response = _client.PostAsync(_testUri, new StringContent(content, Encoding.UTF8, "application/json")).Result;

                if (response.IsSuccessStatusCode)
                    Console.WriteLine("[" + GetCurrentMethod() + "] : Success !");
                else
                    Console.WriteLine("[" + GetCurrentMethod() + "] : Fail !");

            }
            catch (Exception e)
            {
                Console.WriteLine("The test called " + GetCurrentMethod() + "failed. \n " + e.Message);
            }
        }

        public T Read(string id)
        {
            try
            {
                HttpResponseMessage response = _client.GetAsync(_testUri + "?id=" + id).Result;

                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("[" + GetCurrentMethod() + "] : Success !");
                    return JsonConvert.DeserializeObject<T>(response.Content.ReadAsStringAsync().Result);
                }
                else
                {
                    Console.WriteLine("[" + GetCurrentMethod() + "] : Fail !");
                    return null;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("The test called " + GetCurrentMethod() + "failed. \n " + e.Message);
                return null;
            }
        }

        public void Update(T dto, string id)
        {
            try
            {
                string content = JsonConvert.SerializeObject(dto);
                HttpResponseMessage response = _client.PostAsync(_testUri+"/Update?id=" + id, new StringContent(content, Encoding.UTF8, "application/json")).Result;

                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("[" + GetCurrentMethod() + "] : Success !");
                }
                else
                    Console.WriteLine("[" + GetCurrentMethod() + "] : Fail !");
            }
            catch (Exception e)
            {
                Console.WriteLine("The test called " + GetCurrentMethod() + "failed. \n " + e.Message);
            }
        }

        public void Delete(string id)
        {
            try
            {
                HttpResponseMessage response = _client.GetAsync(_testUri + "/Delete?id=" + id).Result;

                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("[" + GetCurrentMethod() + "] : Success !");
                }
                else
                    Console.WriteLine("[" + GetCurrentMethod() + "] : Fail !");

            }
            catch (Exception e)
            {
                Console.WriteLine("The test called " + GetCurrentMethod() + "failed. \n " + e.Message);
            }
        }

        public void GetCount()
        {
            try
            {
                HttpResponseMessage response = _client.GetAsync(_testUri + "/GetCount").Result;

                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("[" + GetCurrentMethod() + "] : Success !");
                }
                else
                    Console.WriteLine("[" + GetCurrentMethod() + "] : Fail !");

            }
            catch (Exception e)
            {
                Console.WriteLine("The test called " + GetCurrentMethod() + "failed. \n " + e.Message);
            }
        }

    }
}
