﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Http;
using Newtonsoft.Json;
using Smag.Framework.Common.Extensions;
using Smag.Framework.Common.Logs;



namespace Smag.Framework.Common.Services
{



    public static class WebServiceHelper
    {

        #region Méthodes statiques privées

        /// <summary>
        /// Extrait un résultat et le convertit dans le type <typeparamref name="R"/> demandé.
        /// </summary>
        /// <typeparam name="R">Type de données du résultat.</typeparam>
        /// <param name="content">Résultat d'un appel Web.</param>
        /// <param name="deserializeJsonResult">Indique si le résultat est un objet au format JSON.</param>
        /// <returns>Résultat.</returns>
        private static R GetResult<R>(HttpContent content, bool deserializeJsonResult)
        {
            try
            {
                if (deserializeJsonResult)
                {
                    string jsonResult = content.ReadAsStringAsync().Result;
                    return JsonConvert.DeserializeObject<R>(jsonResult);
                }
                else
                {
                    return content.ReadAsAsync<R>().Result;
                }
            }
            catch (Exception ex)
            {
                throw new InvalidCastException(string.Format("Impossible de convertir le résultat en {0}.", typeof(R).Name), ex);
            }
        }

        #endregion

        #region Méthodes statiques publiques

        /// <summary>
        /// Appelle, via GET, une méthode Web ne renvoyant rien.
        /// </summary>
        /// <param name="url">Adresse de la méthode Web à contacter.</param>
        /// <param name="header">Valeurs à passer dans l'en-tête HTTP.</param>
        /// <param name="parameters">Dictionnaire associant à chaque nom de paramètre une valeur. Si ce dictionnaire est vide ou s'il est <value>null</value> alors aucun paramètre ne sera transmis à la méthode Web.</param>
        public static void Get(string url, Dictionary<string, string> header, Dictionary<string, string> parameters)
        {
            Send(url, HttpMethod.Get, header, parameters, null, null);
        }

        /// <summary>
        /// Appelle, via GET, une méthode Web renvoyant un objet.
        /// </summary>
        /// <typeparam name="R">Type de l'objet retourné.</typeparam>
        /// <param name="url">Adresse de la méthode Web à contacter.</param>
        /// <param name="header">Valeurs à passer dans l'en-tête HTTP.</param>
        /// <param name="parameters">Dictionnaire associant à chaque nom de paramètre une valeur. Si ce dictionnaire est vide ou s'il est <value>null</value> alors aucun paramètre ne sera transmis à la méthode Web.</param>
        /// <param name="deserializeJsonResult">Indique si le résultat de la méthode Web est au format JSON et doit donc être désérialisé.</param>
        public static R Get<R>(string url, Dictionary<string, string> header, Dictionary<string, string> parameters, bool deserializeJsonResult)
        {
            HttpContent content = Send(url, HttpMethod.Get, header, parameters, null, null);
            return GetResult<R>(content, deserializeJsonResult);
        }

        /// <summary>
        /// Appelle, via POST, une méthode Web ne renvoyant rien et prenant soit aucun paramètre, soit un objet JSON en paramètre.
        /// </summary>
        /// <param name="url">Adresse de la méthode Web à contacter.</param>
        /// <param name="header">Valeurs à passer dans l'en-tête HTTP.</param>
        /// <param name="parameters">Objet à sérialiser via JSON et à envoyer à la méthode Web. Si <value>null</value>, alors aucun paramètre ne sera envoyé à la méthode Web.</param>
        public static void Post(string url, Dictionary<string, string> header, object parameters)
        {
            Send(url, HttpMethod.Post, header, null, null, parameters);
        }

        /// <summary>
        /// Appelle, via POST, une méthode Web renvoyant un objet et prenant soit aucun paramètre, soit un objet JSON en paramètre.
        /// </summary>
        /// <typeparam name="R">Type de l'objet retourné.</typeparam>
        /// <param name="url">Adresse de la méthode Web à contacter.</param>
        /// <param name="header">Valeurs à passer dans l'en-tête HTTP.</param>
        /// <param name="parameters">Objet à sérialiser via JSON et à envoyer à la méthode Web. Si <value>null</value>, alors aucun paramètre ne sera envoyé à la méthode Web.</param>
        /// <param name="deserializeJsonResult">Indique si le résultat de la méthode Web est au format JSON et doit donc être désérialisé.</param>
        public static R Post<R>(string url, Dictionary<string, string> header, object parameters, bool deserializeJsonResult)
        {
            HttpContent content = Send(url, HttpMethod.Post, header, null, null, parameters);
            return GetResult<R>(content, deserializeJsonResult);
        }

        /// <summary>
        /// Appelle une méthode Web.
        /// </summary>
        /// <param name="url">Adresse de la méthode Web à contacter.</param>
        /// <param name="method">Méthode d'envoie des données : Get, Post, ..</param>
        /// <param name="header">Paramètres à envoyer via l'en-tête HTTP.</param>
        /// <param name="dataUrl">Paramètres à envoyer via l'URL.</param>
        /// <param name="dataForm">Paramètres à envoyer via un formulaire.</param>
        /// <param name="dataJson">Paramètres à envoyer au format JSON.</param>
        /// <returns>Statut de l'appel.</returns>
        /// <remarks>Déclenche une exception en cas d'erreur.</remarks>
        public static HttpContent Send(string url, HttpMethod method, Dictionary<string, string> header, Dictionary<string, string> dataUrl, Dictionary<string, string> dataForm, object dataJson)
        {
            try
            {
                // Construit l'URL.
                if (dataUrl != null && dataUrl.Count > 0)
                {
                    char sep = url.Contains("?") ? '&' : '?';
                    StringBuilder newUrl = new StringBuilder(url);
                    foreach (var p in dataUrl)
                    {
                        newUrl.Append(sep);
                        newUrl.Append(HttpUtility.UrlEncode(p.Key));
                        newUrl.Append('=');
                        newUrl.Append(HttpUtility.UrlEncode(p.Value));
                        sep = '&';
                    }
                    url = newUrl.ToString();
                }

                // Construit le body.
                HttpContent content = null;
                if (dataForm != null && dataForm.Count > 0)
                {
                    content = new FormUrlEncodedContent(dataForm);
                }
                if (dataJson != null)
                {
                    if (content != null)
                        throw new Exception("Les données ne peuvent être transmises à la fois par 'form' et par 'json'.");
                    string jsonData = JsonConvert.SerializeObject(dataJson);
                    content = new StringContent(jsonData, Encoding.UTF8, "application/json");
                }

                // Envoie les données à la méthode Web.
                using (var client = new HttpClient())
                {
                    // En-tête HTTP.
                    client.DefaultRequestHeaders.Accept.Clear();
                    if (header != null && header.Count > 0)
                    {
                        foreach (var h in header)
                            client.DefaultRequestHeaders.Add(h.Key, h.Value);
                    }

                    // Prépare la requête.
                    HttpRequestMessage request = new HttpRequestMessage(method, url)
                    {
                        Content = content
                    };

                    // Exécute la requête.
                    HttpResponseMessage response = client.SendAsync(request).Result;

                    // Traite la réponse.
                    if (!response.IsSuccessStatusCode)
                        throw new HttpResponseException(response);
                    return response.Content;
                }
            }
            catch (Exception ex)
            {
                ex.Log();
                string message = ex.GetReason().Replace("\n", "\n\t");
                throw new Exception(string.Format("L'appel {0} à la méthode Web \"{1}\" a échoué :\n\t{2}", method.ToString().ToUpper(), url, message), null);
            }
        }

        #endregion

    }   // public static class WebServiceHelper



}   // namespace Smag.Framework.Common.Services
