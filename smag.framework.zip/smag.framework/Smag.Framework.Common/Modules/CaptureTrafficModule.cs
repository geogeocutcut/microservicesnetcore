﻿using Smag.Framework.Common.Logs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Smag.Framework.Common.Modules
{
    public class CaptureTrafficModule : IHttpModule
    { 
        private static volatile List<string> excludeKey = new List<string>()
        {  "Cache-Control",
            "Connection",
            "Content-Length",
            "Content-Type",
            "Accept",
            "Accept-Encoding",
            "Accept-Language",
            "Host",
            "User-Agent",
            "Origin",
            "Postman-Token",
            "Content-Length",
            "Cookie",
            "Max-Forwards",
            "X-WAWS-Unencoded-URL",
            "IS-SERVICE-TUNNELED",
            "X-ARR-LOG-ID",
            "DISGUISED-HOST",
            "X-SITE-DEPLOYMENT-ID",
            "ApplicationInsights-RequestTrackingTelemetryModule-RootRequest-Id",
            "CLIENT-IP",
            "X-Forwarded-For",
            "WAS-DEFAULT-HOSTNAME",
            "X-ARR-SSL",
            "Request-Id",
            "x-ms-request-id"

        };

        public void Init(HttpApplication context)
        {
            context.BeginRequest += new EventHandler(context_BeginRequest);
            context.EndRequest += new EventHandler(context_EndRequest);
            context.Error += new EventHandler(Context_Error);
        }

        private void Context_Error(object sender, EventArgs e)
        {
            HttpContext ctx = HttpContext.Current;
            Exception exception = ctx.Server.GetLastError();
            try
            {
                string curlRequest = $"Curl.Request.Exception : {CreateCurl(ctx.Request)}";
                Log.Error(curlRequest);
            }
            catch(Exception ex)
            {
                Log.Error("An error occured when we try to create a curl request");
            }

            Log.Exception(exception);
        }

        private string CreateCurl(HttpRequest request)
        {
            StringBuilder strCurl = new StringBuilder();
            strCurl.Append("curl -" + request.HttpMethod);
            foreach (string _headerKey in request.Headers.Keys)
            {
                strCurl.AppendLine($" -H \"{_headerKey}:{request.Headers[_headerKey]}\"");
            }

            byte[] bytes = request.BinaryRead(request.ContentLength);
            if (bytes.Count() > 0)
            {
                strCurl.Append($" -d '{Encoding.ASCII.GetString(bytes)}'");
            }

            strCurl.Append($" '{request.Url.AbsoluteUri}'");


            return strCurl.ToString();
        }
        void context_BeginRequest(object sender, EventArgs e)
        {
            try
            {
                HttpApplication app = sender as HttpApplication;
                string path = app.Context.Request.Path;

                bool isExtension = System.IO.Path.GetExtension(path).StartsWith(".");
                if (path != "/" && !isExtension && !app.Request.Url.ToString().Contains("swagger"))
                {
                    OutputFilterStream filter = new OutputFilterStream(app.Response.Filter);
                    app.Response.Filter = filter;

                    StringBuilder request = new StringBuilder();
                    request.AppendLine();
                    request.AppendLine(app.Request.HttpMethod + " " + app.Request.Url);
                    request.AppendLine("HEADER :");

                    foreach (string key in app.Request.Headers.Keys)
                    {
                        if (!excludeKey.Contains(key))
                            request.AppendLine("    " + key + ": " + app.Request.Headers[key]);
                    }


                    byte[] bytes = app.Request.BinaryRead(app.Request.ContentLength);
                    if (bytes.Count() > 0)
                    {
                        request.AppendLine("BODY :");
                        request.Append(Encoding.ASCII.GetString(bytes));
                    }
                    app.Request.InputStream.Position = 0;
                    Log.Request(request.ToString());
                }
            }
            catch(Exception ex)
            {
                Log.Error($"CaptureTrafficModule.Error : {ex.Message}");
            }
        }

        void context_EndRequest(object sender, EventArgs e)
        {
            try
            {
                HttpApplication app = sender as HttpApplication;
                string path = app.Context.Request.Path;

                bool isExtension = System.IO.Path.GetExtension(path).StartsWith(".");
                if (path != "/" && !isExtension && !app.Request.Url.ToString().Contains("swagger"))
                {
                    if (app.Response.Filter is OutputFilterStream)
                        Log.Request(((OutputFilterStream)app.Response.Filter).ReadStream(),Level.Debug);
                }
            }
            catch (Exception ex)
            {
                Log.Error($"CaptureTrafficModule.Error : {ex.Message}");
            }

        }


        public void Dispose()
        {
            //Does nothing
        }

        internal class OutputFilterStream : Stream
        {
            private volatile object _lockObj = new object();

            private readonly Stream InnerStream;
            private readonly MemoryStream CopyStream;

            public OutputFilterStream(Stream inner)
            {
                this.InnerStream = inner;
                this.CopyStream = new MemoryStream();
            }

            public string ReadStream()
            {
                lock (this._lockObj)
                {
                    if (this.CopyStream.Length <= 0L ||
                        !this.CopyStream.CanRead ||
                        !this.CopyStream.CanSeek)
                    {
                        return String.Empty;
                    }

                    long pos = this.CopyStream.Position;
                    this.CopyStream.Position = 0L;
                    try
                    {
                        return new StreamReader(this.CopyStream).ReadToEnd();
                    }
                    finally
                    {
                        try
                        {
                            this.CopyStream.Position = pos;
                        }
                        catch {
                            Log.Info("An error occured when trying to set stream position");
                        }
                    }
                }
            }


            public override bool CanRead
            {
                get { return this.InnerStream.CanRead; }
            }

            public override bool CanSeek
            {
                get { return this.InnerStream.CanSeek; }
            }

            public override bool CanWrite
            {
                get { return this.InnerStream.CanWrite; }
            }

            public override void Flush()
            {
                this.InnerStream.Flush();
            }

            public override long Length
            {
                get { return this.InnerStream.Length; }
            }

            public override long Position
            {
                get { return this.InnerStream.Position; }
                set { this.CopyStream.Position = this.InnerStream.Position = value; }
            }

            public override int Read(byte[] buffer, int offset, int count)
            {
                return this.InnerStream.Read(buffer, offset, count);
            }

            public override long Seek(long offset, SeekOrigin origin)
            {
                this.CopyStream.Seek(offset, origin);
                return this.InnerStream.Seek(offset, origin);
            }

            public override void SetLength(long value)
            {
                this.CopyStream.SetLength(value);
                this.InnerStream.SetLength(value);
            }

            public override void Write(byte[] buffer, int offset, int count)
            {
                this.CopyStream.Write(buffer, offset, count);
                this.InnerStream.Write(buffer, offset, count);
            }
        }

    }


}
