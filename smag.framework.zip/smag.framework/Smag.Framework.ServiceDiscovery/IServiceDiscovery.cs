﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smag.Framework.ServiceDiscovery
{
    public interface IServiceDiscovery
    {

        string Get(string key);

        void Register(string key, string url);

        void UnRegister(string key);
    }
}
