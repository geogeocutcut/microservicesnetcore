﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;

namespace Smag.Framework.ServiceDiscovery
{
    public class RedisServiceDiscovery:IServiceDiscovery
    {
        private static readonly object _Olock = new object();
        private static Dictionary<string, string> serviceCache;
        private IDatabase _redisStore = RedisConnectorHelper.Connection.GetDatabase();
        private static Dictionary<string, string> _ServiceCache
        {
            get
            {
                if (serviceCache == null)
                {
                    lock (_Olock)
                    {
                        if (serviceCache == null)
                        {
                            serviceCache = new Dictionary<string, string>();
                        }
                    }
                }
                return serviceCache;
            }
        }
        
        // Structuration key : <env>/<domain>/<concept>/<version>/<method>
        // <env> : dev, validation, préprod, prod
        // <domain> : atland, agreo, jarvis

        // Url : url absolue

        public string Get(string key)
        {
            string url = string.Empty;
            if(_ServiceCache.TryGetValue(key,out url))
            {
                return url;
            }

            var redisValue = _redisStore.StringGet(key);
            if (!redisValue.IsNullOrEmpty)
            {
                _ServiceCache[key] = redisValue;
                return redisValue;
            }
            return null;
        }
        
        public void Register(string key, string url)
        {
            _ServiceCache[key] = url;
            _redisStore.StringSet(key, url);
        }

        public void UnRegister(string key)
        {
            _ServiceCache.Remove(key);
            _redisStore.KeyDelete(key);
        }
    }
}
