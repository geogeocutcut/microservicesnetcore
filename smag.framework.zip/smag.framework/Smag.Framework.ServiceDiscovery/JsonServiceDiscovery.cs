﻿using Newtonsoft.Json;
using Smag.Framework.KeyManager;
using System;
using System.Collections.Generic;
using System.Configuration;

using System.IO;


namespace Smag.Framework.ServiceDiscovery
{
    public class JsonServiceDiscovery : IServiceDiscovery
    {

        private static readonly object _Olock = new object();
        private static IDictionary<string, string> serviceDictionary;
        private static IDictionary<string, string> _ServiceDictionary
        {
            get
            {
                if (serviceDictionary == null)
                {
                    lock (_Olock)
                    {
                        if (serviceDictionary == null)
                        {
                            Initialize();
                        }
                    }
                }
                return serviceDictionary;
            }
        }


        public static void Initialize(string filePathName)
        {
            if (serviceDictionary == null)
            {
                lock (_Olock)
                {
                    if (serviceDictionary == null)
                    {
                        string json = System.IO.File.ReadAllText(filePathName);
                        serviceDictionary = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);

                    }
                }
            }
        }

        private static void Initialize()
        {
            var filePathName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Settings.GetWithManagerType("JsonServiceDicoveryFilePathName", MType.WebConfig));

            string json = File.ReadAllText(filePathName);
            serviceDictionary = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
        }

        public string Get(string key)
        {
            return _ServiceDictionary[key];
        }

        public void Register(string key, string url)
        {
            throw new NotImplementedException();
        }

        public void UnRegister(string key)
        {
            throw new NotImplementedException();
        }
    }
}
