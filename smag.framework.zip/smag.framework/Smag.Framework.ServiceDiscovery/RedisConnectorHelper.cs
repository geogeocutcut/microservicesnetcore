﻿using Smag.Framework.KeyManager;
using StackExchange.Redis;
using System;
using System.Configuration;

namespace Smag.Framework.ServiceDiscovery
{
    public class RedisConnectorHelper
    {
        static RedisConnectorHelper()
        {
            RedisConnectorHelper.lazyConnection = new Lazy<ConnectionMultiplexer>(() =>
            {
                var configOptions = new ConfigurationOptions();
                configOptions.EndPoints.Add(Settings.GetWithManagerType("redisConnectionString", MType.WebConfig));
                return ConnectionMultiplexer.Connect(configOptions);
            });
        }

        private static Lazy<ConnectionMultiplexer> lazyConnection;

        public static ConnectionMultiplexer Connection
        {
            get
            {
                return lazyConnection.Value;
            }
        }
    }
}
