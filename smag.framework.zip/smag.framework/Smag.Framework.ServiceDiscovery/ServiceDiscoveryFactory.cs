﻿using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using System;
using System.Configuration;
using Unity;

namespace Smag.Framework.ServiceDiscovery
{
    public static class ServiceDiscoveryFactory
    {
        private static IUnityContainer _container;
        private static object syncRoot = new Object();
        private static bool isLoaded = false;

        public static IServiceDiscovery GetServiceDiscovery()
        {
            if (_container == null || isLoaded == false)
            {
                lock (syncRoot)
                {
                    if (_container == null)
                    {
                        InitializeContainer();
                        isLoaded = true;
                    }
                }
            }
            return _container.Resolve<IServiceDiscovery>();
        }

        private static void InitializeContainer()
        {
            _container = new UnityContainer();
            _container.LoadConfiguration((UnityConfigurationSection)ConfigurationManager.GetSection("unityServiceDiscoveryFactory"));
        }
    }
}
