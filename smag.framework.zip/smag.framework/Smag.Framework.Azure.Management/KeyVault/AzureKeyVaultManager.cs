﻿using Microsoft.Azure.KeyVault;
using Microsoft.Azure.KeyVault.Models;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Smag.Framework.KeyManager;
using System;
using System.Configuration;
using System.Threading.Tasks;

namespace Smag.Framework.Azure.Management.KeyVault
{
    /// <summary>
    /// This class is designed to manage Azure KeyVault. Currently, we provide only KeyVault secret management here.
    ///
    /// It is necessary to have in the configuration file two settings : AzureClientId and AzureClientSecret
    /// These values can be found under :
    ///     (en) Azure dashboard -> Azure Active Directory -> App registrations -> View all applications
    ///     (fr) Azure dashboard -> Azure Active Directory -> Inscriptions des applications -> Afficher toutes les applications
    /// ** Client secret is generated and displayed only for the first time during its creation, then will be hidden forever
    ///
    /// ex :
    /// <add key="AzureClientId" value="my azure client id" />
    /// <add key="AzureClientSecret" value="my azure client secret" />
    /// </summary>
    public static class AzureKeyVaultManager
    {
        #region some configuration constants

        //error code when a secret is not found in Azure
        private const string SecretNotFoundErrorCode = "SecretNotFound";


        private const string AzureClientSecretKeyName = "AzureClientSecret";

        #endregion some configuration constants

        /// <summary>
        /// Get a Azure KeyVault secret base on the secret identifier
        /// </summary>
        /// <param name="secretIdentifier">identifier of the secret</param>
        /// <param name="returnNullWhenNotFound">indicator whether we should throw an not found exception or just return a null value, if an "Not found" exception arrived during the get</param>
        /// <returns>secret value if found, or null</returns>
        public static string GetSecret(string secretIdentifier, bool returnNullWhenNotFound = true)
        {
            AzureServiceTokenProvider azureServiceTokenProvider = new AzureServiceTokenProvider();
            if (string.IsNullOrEmpty(secretIdentifier))
                throw new ArgumentException(nameof(secretIdentifier));

             var keyVaultClient = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(azureServiceTokenProvider.KeyVaultTokenCallback));
            
                try
                {
                    return keyVaultClient.GetSecretAsync(secretIdentifier).ConfigureAwait(false).GetAwaiter().GetResult().Value;
                }
                catch (KeyVaultErrorException ex)
                {
                    //when a secret does not exist, the previous call will throw an exception with a error code starts with "SecretNotFound"
                    //in this case, we don't need to throw an exception, but just continue the execution to create a new secret
                    var errorCode = ((KeyVaultErrorException)ex.InnerException)?.Body.Error.Code;

                    if (returnNullWhenNotFound//if it's allowed to return null value in case of exception
                        && errorCode != null && errorCode.StartsWith(SecretNotFoundErrorCode))
                        return null;

                    throw;
                }
            
        }

        /// <summary>
        /// Create a new Azure KeyVault secret into an existing Azure Vault
        /// </summary>
        /// <param name="azureVaultBaseUrl">Azure url for an existing vault</param>
        /// <param name="secretName">Name of the secret to be created</param>
        /// <param name="secretValue">Value of the secret to be created</param>
        /// <param name="createNewVersion">Indicator of whether to create a new version or not if a same secret exists with a different value was found.</param>
        /// <returns>Azure vault url for fetching the secret</returns>
        public static string SetSecret(string azureVaultBaseUrl, string secretName, string secretValue, bool createNewVersion = true)
        {
            AzureServiceTokenProvider azureServiceTokenProvider = new AzureServiceTokenProvider();
            //input verification
            if (string.IsNullOrEmpty(azureVaultBaseUrl))
                throw new ArgumentException(nameof(azureVaultBaseUrl));

            if (string.IsNullOrEmpty(secretName))
                throw new ArgumentException(nameof(secretName));

            if (string.IsNullOrEmpty(secretValue))
                throw new ArgumentException(nameof(secretValue));

            using (var keyVaultClient = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(azureServiceTokenProvider.KeyVaultTokenCallback)))
            //using (var keyVaultClient = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(new AzureServiceTokenProvider().KeyVaultTokenCallback)))
            {
                string newSecretIdentifier = null;
                var shouldCreate = true;

                //try to get azure secret with input arguments (null if not found)
                var existingSecret = GetExistingSecretOrNull(azureVaultBaseUrl, secretName);

                //if a secret with a same name has been found
                if (!string.IsNullOrEmpty(existingSecret?.Value))
                {
                    //it's the same secret value in the existing one => no need to create new secret, just reuse the old one
                    if (existingSecret.Value.Equals(secretValue))
                    {
                        shouldCreate = false;
                        newSecretIdentifier = existingSecret.Id;
                    }
                    else
                    {
                        //otherwise, if user indicates to create a new version, we leave the shouldCreate to be true

                        //if user refuse to create a new version => exception
                        if (!createNewVersion)
                            throw new Exception("A same Azure KeyVault secret with a different value has already been added previously");
                    }
                }

                if (shouldCreate)
                    newSecretIdentifier = keyVaultClient.SetSecretAsync(azureVaultBaseUrl, secretName, secretValue).Result?.Id;

                return newSecretIdentifier;
            }
        }

        public static void DeleteSecret(string vaultBaseUrl, string secretName)
        {
            if (string.IsNullOrEmpty(vaultBaseUrl))
                throw new ArgumentException(nameof(vaultBaseUrl));

            if (string.IsNullOrEmpty(secretName))
                throw new ArgumentException(nameof(secretName));

            AzureServiceTokenProvider azureServiceTokenProvider = new AzureServiceTokenProvider();

            using (var keyVaultClient = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(azureServiceTokenProvider.KeyVaultTokenCallback)))
            {
                var deletedSecretBundle = keyVaultClient.DeleteSecretAsync(vaultBaseUrl, secretName).Result;
            }
        }

        /// <summary>
        /// Try to get an existing secret if exists, otherwise, return a null
        /// </summary>
        /// <param name="azureVaultBaseUrl">azure Vault base url</param>
        /// <param name="secretName">name of the secret to get</param>
        /// <returns></returns>
        private static SecretBundle GetExistingSecretOrNull(string azureVaultBaseUrl, string secretName)
        {

            AzureServiceTokenProvider azureServiceTokenProvider = new AzureServiceTokenProvider();
            using (var keyVaultClient = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(azureServiceTokenProvider.KeyVaultTokenCallback)))
                //try to see whether a secret exists with the same information
                try
                {
                    return keyVaultClient.GetSecretAsync(azureVaultBaseUrl, secretName).Result;
                }
                catch (Exception ex)
                {
                    //when a secret does not exist, the previous call will throw an exception with a error code starts with "SecretNotFound"
                    //in this case, we don't need to throw an exception, but just continue the execution to create a new secret

                    if (!(ex.InnerException is KeyVaultErrorException keyVaultErrorException))
                    {
                        throw;
                    }

                    var errorCode = keyVaultErrorException.Body.Error.Code;

                    if (errorCode == null || !errorCode.StartsWith(SecretNotFoundErrorCode))
                        throw;

                    return null;
                }
        }
    }
}