﻿
namespace Smag.Framework.Operational
{
    public interface IOProxyProvider
    {
        TProxy GetProxy<TProxy>(string name = "") where TProxy : class;
    }
}
