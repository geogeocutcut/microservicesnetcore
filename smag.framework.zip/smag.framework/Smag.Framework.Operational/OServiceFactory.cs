﻿using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using Smag.Framework.Authentication;
using System;
using System.Configuration;

namespace Smag.Framework.Operational
{
    public static class OServiceFactory
    {
        private static IUnityContainer _container;
        private static object syncRoot = new Object();
        private static bool isLoaded = false;
        public static IOServiceProvider GetServiceProvider()
        {

            if (_container == null || isLoaded == false)
            {
                lock (syncRoot)
                {
                    if (_container == null)
                    {
                        InitializeContainer();
                        isLoaded = true;
                    }
                }
            }
            return _container.Resolve<IOServiceProvider>();

        }
        public static TService GetService<TService>(AuthenticationContext ctx = null) where TService: class
        {

            return ctx == null?GetServiceProvider().GetService<TService>() : GetServiceProvider().GetService<TService>(ctx);

        }

        private static void InitializeContainer()
        {
            _container = new UnityContainer();
            var section = (UnityConfigurationSection)ConfigurationManager.GetSection("unityServiceFactory");
            _container.LoadConfiguration(section);
        }
    }
}
