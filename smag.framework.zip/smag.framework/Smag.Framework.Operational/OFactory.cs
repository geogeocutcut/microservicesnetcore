﻿using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using System.Configuration;
using System;
using System.Security.Claims;
using System.Security.Principal;
using Smag.Framework.Authentication;
using Unity;
using Unity.Resolution;

namespace Smag.Framework.Operational
{
    public static class OFactory
    {
        private static IUnityContainer _container;
        private static object syncRoot = new Object();
        private static bool isLoaded = false;



        public static IOProxyProvider GetProxyProvider(AuthenticationContext authCtxt)
        {

            if (_container == null || isLoaded == false)
            {
                lock (syncRoot)
                {
                    if (_container == null)
                    {
                        InitializeContainer();
                        isLoaded = true;
                    }
                }
            }
            return _container.Resolve<IOProxyProvider>(
                        new DependencyOverrides
                        {
                            {typeof(AuthenticationContext),authCtxt}
                        });

        }



        private static void InitializeContainer()
        {
            _container = new UnityContainer();
            _container.LoadConfiguration((UnityConfigurationSection)ConfigurationManager.GetSection("unityOProxyFactory"));
            _container.LoadConfiguration((UnityConfigurationSection)ConfigurationManager.GetSection("unityOServiceFactory"));
        }


        public static IOServiceProvider GetServicesProvider()
        {
            if (_container == null || isLoaded == false)
            {
                lock (syncRoot)
                {
                    if (_container == null)
                    {
                        InitializeContainer();
                        isLoaded = true;
                    }
                }
            }
            return _container.Resolve<IOServiceProvider>();
        }

        public static IService GetServiceInMemory<IService>()
        {
            var authCtxt = new AuthenticationContext(null as ClaimsIdentity);
            return GetServicesProvider().GetService<IService>(GetProxyProvider(authCtxt));

        }

        public static IService GetService<IService>(IIdentity identity)
        {
            var authContext = (identity == null || !(identity is ClaimsIdentity claimsIdentity))
                ? new AuthenticationContext()
                : new AuthenticationContext(claimsIdentity);

            return GetServicesProvider().GetService<IService>(GetProxyProvider(authContext));
        }

        public static IService GetService<IService>(IIdentity identity,bool IsauthInService)
        {
            var authContext = (identity == null || !(identity is ClaimsIdentity claimsIdentity))
                ? new AuthenticationContext()
                : new AuthenticationContext(claimsIdentity);

            return GetServicesProvider().GetService<IService>(GetProxyProvider(authContext),authContext);
        }

        public static IService GetService<IService>(AuthenticationContext authCtxt)
        {
            return GetServicesProvider().GetService<IService>(GetProxyProvider(authCtxt));
        }

        public static IService GetService<IService>(IOProxyProvider provider)
        {
            return GetServicesProvider().GetService<IService>(provider);
        }
    }
}
