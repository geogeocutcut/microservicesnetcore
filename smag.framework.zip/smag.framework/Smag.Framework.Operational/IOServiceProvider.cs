﻿

using Smag.Framework.Authentication;

namespace Smag.Framework.Operational
{
    public interface IOServiceProvider
    {
        TService GetService<TService>(IOProxyProvider provider);

        TService GetService<TService>(IOProxyProvider provider,AuthenticationContext authCtxt);
    }
}
