﻿

namespace Smag.Framework.Services.Provider
{
    public interface IServicesProvider
    {
        Service GetService<Service>() where Service : class;
    }
}
