﻿using Smag.Framework.Common.Extensions;
using Smag.Framework.Common.Logs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smag.Framework.Services.Services
{
    public class Image : IComparable<Image>
    {

        #region Constantes

        /// <summary>
        /// Couleur principale de l'image.
        /// </summary>
        private enum Color
        {

            /// <summary>
            /// Version noire.
            /// </summary>
            Black,

            /// <summary>
            /// Version grise.
            /// </summary>
            Gray,

            /// <summary>
            /// Version blanche.
            /// </summary>
            White
        }

        #endregion

        #region Variables membres

        /// <summary>
        /// Données de l'image en attente d'être sauvegardées.
        /// </summary>
        private byte[] m_data;

        /// <summary>
        /// Indique si les données de l'image ont été chargées à partir du fichier physique dans <see cref="m_data"/>.
        /// </summary>
        private bool m_dataLoaded;

        /// <summary>
        /// Indique si l'image existe sous 3 versions : blanche (par défaut), gris et noir.
        /// </summary>
        private bool m_hasGrayAndBlackVariants;

        /// <summary>
        /// Identifiant de l'image.
        /// </summary>
        private string m_id;

        #endregion

        #region Constructeurs

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="parent">Objet parent contenant l'image.</param>
        /// <param name="hasGrayAndBlackVariants">Indique si l'image existe sous 3 versions : blanche (par défaut), gris et noir.</param>
        public Image(IAuditableEntityWithImage parent, bool hasGrayAndBlackVariants)
        {
            Parent = parent;
            m_dataLoaded = false;
            m_hasGrayAndBlackVariants = hasGrayAndBlackVariants;
            m_id = Guid.NewGuid().ToString();
        }

        #endregion

        #region Propriétés

        /// <summary>
        /// Données de l'image en attente d'être sauvegardées.
        /// </summary>
        public byte[] Data
        {
            get
            {
                if (m_data != null)
                    return m_data;
                if (!m_dataLoaded)
                {
                    try
                    {
                        m_dataLoaded = true;
                        string path = GetFullPath(false, Color.White);
                        if (!string.IsNullOrEmpty(path) && File.Exists(path))
                            m_data = File.ReadAllBytes(path);
                        if (m_data != null)
                            return m_data;
                    }
                    catch (Exception ex)
                    {
                        ex.Log();
                    }
                }
                if (Parent == null)
                    return null;
                return Parent.ImageByDefault;
            }
            set
            {
                m_data = value;
            }
        }

        /// <summary>
        /// Identifiant de l'image.
        /// </summary>
        public string Id
        {
            get
            {
                return m_id;
            }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                    m_id = value.Trim();
            }
        }

        /// <summary>
        /// Objet parent.
        /// </summary>
        private IAuditableEntityWithImage Parent { get; set; }

        /// <summary>
        /// Adresse complète de l'image ("http://***.png").
        /// </summary>
        public string Url
        {
            get
            {
                return GetFullPath(true, Color.White);
            }
        }

        /// <summary>
        /// Adresse complète de la version noire de l''image ("http://***_black.png").
        /// </summary>
        public string UrlBlack
        {
            get
            {
                if (!m_hasGrayAndBlackVariants)
                    return null;
                return GetFullPath(true, Color.Black);
            }
        }

        /// <summary>
        /// Adresse complète de la version grise de l'image ("http://***_gray.png").
        /// </summary>
        public string UrlGray
        {
            get
            {
                if (!m_hasGrayAndBlackVariants)
                    return null;
                return GetFullPath(true, Color.Gray);
            }
        }

        #endregion

        #region Méthodes statiques

        /// <summary>
        /// Obtient le chemin physique du fichier de l'image stockée dans l'un des sous-répertoires du répertoire "Images" de l'API Partenaire.
        /// </summary>
        /// <typeparam name="T">Type d'objet pour lequel on cherche le chemin de l'image.</typeparam>
        /// <param name="imagesUrl">Adresse (URL) de base des images.</param>
        /// <param name="imagesPath">Chemin physique du répertoire contenant toutes les images.</param>
        /// <param name="directory">Chemin relatif du répertoire contenant les images des objets de type <typeparamref name="T"/>.</param>
        /// <param name="fileNameWithoutExtension">Nom de l'image, sans l'extension de fichier.</param>
        /// <param name="full">Indique si la fonction doit retourner un chemin complet (<value>true</value>) ou relatif (<value>false</value>).</param>
        /// <returns>Chemin physique de l'image.</returns>
        public static string GetFilePath<T>(string imagesUrl, string imagesPath, string directory, string fileNameWithoutExtension, bool full)
        {
            return GetPath(typeof(T), imagesUrl, imagesPath, directory, fileNameWithoutExtension, false, full, Color.White);
        }

        /// <summary>
        /// Obtient le chemin d'une image stockée dans l'un des sous-répertoires du répertoire "Images" de l'API Partenaire.
        /// </summary>
        /// <param name="parentType">Type d'objet pour lequel on cherche le chemin de l'image.</param>
        /// <param name="imagesUrl">Adresse (URL) de base des images.</param>
        /// <param name="imagesPath">Chemin physique du répertoire contenant toutes les images.</param>
        /// <param name="directory">Chemin relatif du répertoire contenant les images des objets de type <paramref name="parentType"/>.</param>
        /// <param name="fileNameWithoutExtension">Nom de l'image, sans l'extension de fichier.</param>
        /// <param name="url">Indique si le chemin à retourner est physique ("D:\..") ou s'il s'agit d'une URL ("http://..").</param>
        /// <param name="full">Indique si la fonction doit retourner un chemin/adresse complet (<value>true</value>) ou relatif (<value>false</value>).</param>
        /// <param name="color">Variante colorisée de l'image (si différent de <value>White</value>).</param>
        /// <returns>Chemin de l'image.</returns>
        private static string GetPath(Type parentType, string imagesUrl, string imagesPath, string directory, string fileNameWithoutExtension, bool url, bool full, Color color)
        {
            try
            {
                // Obtient le chemin relatif de l'image.
                string relativePath;
                {
                    // Détermine dans quelle répertoire est stockée l'image.
                    if (string.IsNullOrEmpty(directory))
                    {
                        string subExceptionMessage;
                        if (parentType == null)
                            subExceptionMessage = "L'image n'a pas de parent.";
                        else
                            subExceptionMessage = string.Format("Le parent de type {0} de l'image ne définit aucun répertoire.", parentType.Name);
                        throw new Exception("Impossible de déterminer dans quel répertoire est stockée l'image actuelle.", new Exception(subExceptionMessage));
                    }
                    if (!directory.IsEndingWithPathSeparator())
                        directory += "/";

                    // Détermine quel est le nom du fichier.
                    string fileName;
                    switch (color)
                    {
                        case Color.Black:
                            fileName = string.Format("{0}_black.png", fileNameWithoutExtension);
                            break;

                        case Color.Gray:
                            fileName = string.Format("{0}_gray.png", fileNameWithoutExtension);
                            break;

                        default:
                            fileName = string.Format("{0}.png", fileNameWithoutExtension);
                            break;
                    }

                    // Construit le chemin relatif.
                    string path = directory + fileName;
                    relativePath = url ? path.Replace(@"\", "/") : path.Replace("/", @"\");
                    if (string.IsNullOrEmpty(relativePath))
                        return null;
                }
                if (!full)
                    return relativePath;

                // Obtient le chemin de la racine.
                string root;
                if (url)
                {
                    root = imagesUrl;
                    if (string.IsNullOrEmpty(root))
                        throw new Exception("L'URL des images n'a pas été trouvée dans le fichier de configuration.");
                }
                else
                {
                    root = imagesPath;
                    if (string.IsNullOrEmpty(root))
                        throw new Exception("Le chemin physique du répertoire contenant les images n'a pas été trouvée dans le fichier de configuration.");
                }
                if (!root.IsEndingWithPathSeparator())
                    root += "/";

                // Vérifie que le chemin de base est valide.
                if (!url && !Directory.Exists(root.Replace("/", @"\")))
                    throw new Exception(string.Format("Le répertoire de base des images (\"{0}\") n'existe pas.", root.Replace("/", @"\")));

                // Construit le chemin complet.
                string fullPath = root + relativePath;
                return url ? fullPath.Replace(@"\", "/") : fullPath.Replace("/", @"\");
            }
            catch (Exception ex)
            {
                // Erreur.
                ex.Log();
                return null;
            }
        }

        /// <summary>
        /// Obtient l'adresse de l'image stockée dans l'un des sous-répertoires du répertoire "Images" de l'API Partenaire.
        /// </summary>
        /// <typeparam name="T">Type d'objet pour lequel on cherche le chemin de l'image.</typeparam>
        /// <param name="imagesUrl">Adresse (URL) de base des images.</param>
        /// <param name="imagesPath">Chemin physique du répertoire contenant toutes les images.</param>
        /// <param name="directory">Chemin relatif du répertoire contenant les images des objets de type <typeparamref name="T"/>.</param>
        /// <param name="fileNameWithoutExtension">Nom de l'image, sans l'extension de fichier.</param>
        /// <param name="full">Indique si la fonction doit retourner une adresse complète (<value>true</value>) ou relative (<value>false</value>).</param>
        /// <returns>Adresse de l'image.</returns>
        public static string GetUrl<T>(string imagesUrl, string imagesPath, string directory, string fileNameWithoutExtension, bool full)
        {
            return GetPath(typeof(T), imagesUrl, imagesPath, directory, fileNameWithoutExtension, true, full, Color.White);
        }

        #endregion

        #region Méthodes

        /// <summary>
        /// Compare l'image actuelle avec celle indiquée.
        /// </summary>
        /// <param name="other">Autre image à comparer.</param>
        public int CompareTo(Image other)
        {
            string url = GetRelativePath(true, Color.White);
            string otherUrl = other?.GetRelativePath(true, Color.White);
            if (string.IsNullOrEmpty(url))
                return string.IsNullOrEmpty(otherUrl) ? 0 : -1;
            else if (string.IsNullOrEmpty(otherUrl))
                return 1;
            else
                return string.Compare(url, otherUrl, true);
        }

        /// <summary>
        /// Obtient le chemin complet de l'image actuelle.
        /// </summary>
        /// <param name="url">Indique si le chemin à retourner est physique ("D:\..") ou s'il s'agit d'une URL ("http://..").</param>
        /// <param name="color">Couleur de l'image.</param>
        /// <returns>Chemin complet de l'image actuelle, ou <value>null</value> si ce n'est pas possible.</returns>
        private string GetFullPath(bool url, Color color)
        {
            return GetPath(Parent?.GetType(), Parent?.ImagesUrl, Parent?.ImagesPath, Parent?.ImageDirectory, Id, url, true, color);
        }

        /// <summary>
        /// Obtient le chemin relatif de l'image actuelle.
        /// </summary>
        /// <param name="url">Indique si le chemin à retourner est physique ("D:\..") ou s'il s'agit d'une URL ("http://..").</param>
        /// <param name="color">Couleur de l'image.</param>
        /// <returns>Chemin relatif de l'image actuelle, ou <value>null</value> si ce n'est pas possible.</returns>
        private string GetRelativePath(bool url, Color color)
        {
            return GetPath(Parent?.GetType(), Parent?.ImagesUrl, Parent?.ImagesPath, Parent?.ImageDirectory, Id, url, false, color);
        }

        /// <summary>
        /// Sauvegarde physiquement l'image actuelle, si son contenu a été modifié via un appel à la méthode <see cref="Upload(byte[], bool)"/>.
        /// </summary>
        /// <returns><value>true</value> si l'image a été sauvegardée ou écrasée physiquement, <value>false</value> si aucune donnée n'a été sauvegardée.</returns>
        /// <remarks>Une exception sera générée en cas d'erreur.</remarks>
        public bool Save()
        {
            if (Data == null || Data.Length < 1)
                return false;

            // Obtient le chemin physique l'image actuelle.
            string filePath = GetFullPath(false, Color.White);
            if (string.IsNullOrEmpty(filePath))
                throw new Exception("Le chemin de l'image cible n'est pas valide.");

            // Supprime l'ancien fichier et crée le répertoire si nécessaire.
            string directory = Path.GetDirectoryName(filePath);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                Directory.CreateDirectory(directory);
            if (File.Exists(filePath))
                File.Delete(filePath);

            // Sauvegarde les données.
            using (var ms = new MemoryStream(Data))
            {
               System.Drawing.Image.FromStream(ms).Save(filePath);
            }

            // Succès.
            if (!File.Exists(filePath))
                throw new Exception(string.Format("Échec de la sauvegarde de l'image \"{0}\".", filePath));
            return true;
        }

        /// <summary>
        /// Donne une version chaîne de l'instance de la classe actuelle.
        /// </summary>
        /// <returns>Version chaîne de l'instance actuelle.</returns>
        public override string ToString()
        {
            return Id;
        }

        #endregion

    }
}
