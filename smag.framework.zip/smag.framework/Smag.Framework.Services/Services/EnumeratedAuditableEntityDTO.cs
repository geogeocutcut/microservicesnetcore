﻿using Smag.Framework.Common.Extensions;
using System;



namespace Smag.Framework.Services.Services
{



    public abstract class EnumeratedAuditableEntityDTO<E> : AuditableEntityDTO, IEquatable<EnumeratedAuditableEntityDTO<E>>
        where E : struct
    {

        #region Variables membres

        /// <summary>
        /// Code.
        /// </summary>
        protected string m_code;

        /// <summary>
        /// Valeur énumérée.
        /// </summary>
        protected E? m_value;

        #endregion

        #region Méthodes

        /// <summary>
        /// Détermine si l'objet actuel est identique à celui indiqué.
        /// </summary>
        /// <param name="other">Objet à comparer.</param>
        /// <returns><value>true</value> si les 2 objets sont identiques, <value>false</value> sinon.</returns>
        public bool Equals(EnumeratedAuditableEntityDTO<E> other)
        {
            if (other == null)
                return false;
            if (Value.HasValue && other.Value.HasValue)
                return (Value.Value.Equals(other.Value.Value));
            return (Value.HasValue == other.Value.HasValue);
        }

        /// <summary>
        /// Convertit un code en valeur énumérée.
        /// </summary>
        /// <param name="code">Code.</param>
        /// <returns>Valeur énumérée correspondant au code, ou <value>null</value> si aucune valeur ne correspond.</returns>
        protected static E? FromCode(string code)
        {
            return EnumExtensions.FromCode<E>(code);
        }

        /// <summary>
        /// Convertit une valeur énumérée en code.
        /// </summary>
        /// <param name="value">Valeur énumérée.</param>
        /// <returns>Code correspondant à la valeur énumérée.</returns>
        protected static string ToCode(E? value)
        {
            if (value.HasValue)
                return value.Value.GetCode();
            return null;
        }

        #endregion

        #region Propriétés

        /// <summary>
        /// Code.
        /// </summary>
        public string Code
        {
            get
            {
                return m_code;
            }
            set
            {
                m_code = value;
                m_value = FromCode(value);
            }
        }

        /// <summary>
        /// Valeur énumérée.
        /// </summary>
        public E? Value
        {
            get
            {
                return m_value;
            }
            set
            {
                m_code = ToCode(value);
                m_value = value;
            }
        }

        #endregion

    }   // public abstract class EnumeratedAuditableEntityDTO<E>



}
