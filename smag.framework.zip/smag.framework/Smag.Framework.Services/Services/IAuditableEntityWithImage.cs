﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smag.Framework.Services.Services
{
    public interface IAuditableEntityWithImage
    {

        /// <summary>
        /// Image.
        /// </summary>
        Image Image { get; }

        /// <summary>
        /// Sous-répertoire contenant l'image.
        /// </summary>
        [JsonIgnore]
        string ImageDirectory { get; }

        /// <summary>
        /// Chemin physique du répertoire contenant toutes les images.
        /// </summary>
        [JsonIgnore]
        string ImagesPath { get; }

        /// <summary>
        /// Adresse (URL) de base des images.
        /// </summary>
        [JsonIgnore]
        string ImagesUrl { get; }

        [JsonIgnore]
        byte[] ImageByDefault { get; }

    }
}
