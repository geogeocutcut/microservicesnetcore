﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smag.Framework.Services.Services
{
    public abstract class AuditableEntityDTO
    {

        #region Constantes

        /// <summary>
        /// Identifiant Jarvis de l'utilisateur qui effectue les opérations sur la base de données.
        /// </summary>
        private const string USER_FDAGUER = "53c37f56-66bc-48c0-85e5-bdc5e601ec8b";

        #endregion

        #region Variables membres

        /// <summary>
        /// Identifiant Jarvis de l'utilisateur ayant créé l'objet actuel.
        /// </summary>
        private string m_createdBy;

        /// <summary>
        /// Date à laquelle l'objet a été créé.
        /// </summary>
        private DateTime? m_createdDate;

        /// <summary>
        /// Identifiant Jarvis de l'utilisateur ayant modifié l'objet actuel.
        /// </summary>
        private string m_updatedBy;

        /// <summary>
        /// Date à laquelle l'objet a été mis à jour.
        /// </summary>
        private DateTime? m_updatedDate;

        #endregion

        #region Propriétés

        /// <summary>
        /// Date à laquelle l'objet a été créé.
        /// </summary>
        public DateTime CreatedDate
        {
            get
            {
                return m_createdDate ?? DateTime.Now;
            }
            set
            {
                m_createdDate = value;
            }
        }

        /// <summary>
        /// Identifiant Jarvis de l'utilisateur ayant créé l'objet actuel.
        /// </summary>
        public string CreatedBy
        {
            get
            {
                if (string.IsNullOrEmpty(m_createdBy))
                    return USER_FDAGUER;
                return m_createdBy;
            }
            set
            {
                m_createdBy = value;
            }
        }

        /// <summary>
        /// Date à laquelle l'objet a été supprimé.
        /// </summary>
        public DateTime? DeletedDate { get; set; }

        /// <summary>
        /// Identifiant Jarvis de l'utilisateur ayant supprimé l'objet actuel.
        /// </summary>
        public string DeletedBy { get; set; }

        /// <summary>
        /// Date à laquelle l'objet a été mis à jour.
        /// </summary>
        public DateTime UpdatedDate
        {
            get
            {
                return m_updatedDate ?? CreatedDate;
            }
            set
            {
                m_updatedDate = value;
            }
        }

        /// <summary>
        /// Identifiant Jarvis de l'utilisateur ayant modifié l'objet actuel.
        /// </summary>
        public string UpdatedBy
        {
            get
            {
                if (string.IsNullOrEmpty(m_updatedBy))
                    return USER_FDAGUER;
                return m_updatedBy;
            }
            set
            {
                m_updatedBy = value;
            }
        }

        #endregion

    }
}
