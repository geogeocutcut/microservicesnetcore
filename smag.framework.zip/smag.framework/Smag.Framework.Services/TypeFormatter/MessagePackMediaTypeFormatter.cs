﻿using MsgPack;
using MsgPack.Serialization;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Smag.Framework.Services.TypeFormatter
{
    public class MessagePackMediaTypeFormatter : MediaTypeFormatter
    {
        private const string mime = "application/x-msgpack";

        Func<Type, bool> IsAllowedType = (t) =>
        {
            if (!t.IsAbstract && !t.IsInterface && t != null && !t.IsNotPublic)
                return true;

            return false;
        };

        public MessagePackMediaTypeFormatter()
        {
            SupportedMediaTypes.Add(new MediaTypeHeaderValue(mime));
        }

        public override bool CanReadType(Type type)
        {
            if (type == null) throw new ArgumentNullException("type is null");

            return IsAllowedType(type);
        }

        public override bool CanWriteType(Type type)
        {
            if (type == null) throw new ArgumentNullException("Type is null");

            return IsAllowedType(type);
        }

        public override Task WriteToStreamAsync(Type type, object value, Stream stream, HttpContent content, TransportContext transportContext)
        {
            if (type == null) throw new ArgumentNullException("type is null");
            if (stream == null) throw new ArgumentNullException("Write stream is null");

            var tcs = new TaskCompletionSource<object>();

            if (typeof(System.Collections.IEnumerable).IsAssignableFrom(type))
            {
                value = (value as IEnumerable<object>).ToList();
            }

            SerializationContext serializationContext = new SerializationContext(PackerCompatibilityOptions.Classic);
            serializationContext.SerializationMethod = SerializationMethod.Map;
            var serializer = MessagePackSerializer.Get<dynamic>(serializationContext);
            
            serializer.Pack(stream, value);

            tcs.SetResult(null);

            return tcs.Task;
        }

        public override Task<object> ReadFromStreamAsync(Type type, Stream stream, HttpContent content, IFormatterLogger formatterLogger)
        {
            var tcs = new TaskCompletionSource<object>();
            if (content.Headers != null && content.Headers.ContentLength == 0)
                return Task.FromResult<object>(null);

            try
            {
                SerializationContext serializationContext = new SerializationContext(PackerCompatibilityOptions.Classic);
                serializationContext.SerializationMethod = SerializationMethod.Map;

                var serializer = MessagePackSerializer.Get(type, serializationContext);


                object result;

                using (var unpacker = Unpacker.Create(stream))
                {
                    unpacker.Read();
                    result = serializer.UnpackFrom(unpacker);
                }

                tcs.SetResult(result);
            }
            catch (Exception e)
            {
                if (formatterLogger == null) throw;
                formatterLogger.LogError(String.Empty, e.Message);
                tcs.SetResult(GetDefaultValueForType(type));
            }

            return tcs.Task;
        }
    }
}