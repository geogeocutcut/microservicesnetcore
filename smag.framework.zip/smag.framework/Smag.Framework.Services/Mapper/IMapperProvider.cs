﻿

namespace Smag.Framework.Services.Mapper
{
    public interface IMapperProvider
    {
        TMapper GetMapper<TMapper>();
    }
}
