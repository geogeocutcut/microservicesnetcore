﻿using Microsoft.Practices.Unity;
using Smag.Framework.Configuration;
using System;
using Unity;

namespace Smag.Framework.Services.Mapper
{

    public static class MapperFactory
    {

        private static IUnityContainer _container;
        private static IMapperProvider _mapperProvider;
        private static object syncRoot = new Object();
        private static bool isLoaded = false;

        public static IMapperProvider GetMapperProvider()
        {
            if (_container == null || isLoaded == false)
            {
                lock (syncRoot)
                {
                    if (_container == null)
                    {
                        InitializeContainer();
                        isLoaded = true;
                    }
                }
            }
            if (_mapperProvider == null)
            {
                lock (syncRoot)
                {
                    if (_mapperProvider == null)
                        _mapperProvider = _container.Resolve<IMapperProvider>();
                }
            }
            return _mapperProvider;
        }

        public static TMapper GetMapper<TMapper>()
        {
            return GetMapperProvider().GetMapper<TMapper>();
        }

        private static void InitializeContainer()
        {
             //  _container = Unity.LoadFromConfigurationSection("unityMapperFactory");
        }

    }



}
