﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smag.Framework.Services.Authentication
{
    public static class AuthenticationParameterValue
    {

        public static string SmagAuthorizationHeaderKey { get; } = "SmagAuthorization";

        private static string _environment = string.Empty;
        private static string Environment
        {
            get
            {
                if(string.IsNullOrEmpty(_environment))
                    _environment = ConfigurationManager.AppSettings.Get("Environment");
                return _environment;
            }
        }
        public static string ClientId
        {
            get
            {
                switch (Environment)
                {
                    case "dev": return Properties.Resources.ClientId_develop;
                    case "validation": return Properties.Resources.ClientId_release;
                    case "preprod": return Properties.Resources.ClientId_staging;
                    case "prod": return Properties.Resources.ClientId_production;
                    default: return Properties.Resources.ClientId_develop;
                }
            }
        }
        public static string Secret
        {
            get
            {
                switch (Environment)
                {
                    case "dev": return Properties.Resources.Secret_develop;
                    case "validation": return Properties.Resources.Secret_release;
                    case "preprod": return Properties.Resources.Secret_staging;
                    case "prod": return Properties.Resources.Secret_production;
                    default: return Properties.Resources.Secret_develop;
                }
            }
        }
        public static string Issuer
        {
            get
            {
                switch (Environment)
                {
                    case "dev": return Properties.Resources.Issuer_develop;
                    case "validation": return Properties.Resources.Issuer_release;
                    case "preprod": return Properties.Resources.Issuer_staging;
                    case "prod": return Properties.Resources.Issuer_production;
                    default: return Properties.Resources.Issuer_develop;
                }
            }
        }
    }
}
