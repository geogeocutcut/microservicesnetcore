﻿using Microsoft.IdentityModel.Tokens;
using Smag.Framework.Common;
using Smag.Framework.Common.Extensions;
using Smag.Framework.Configuration;
using Smag.Framework.KeyManager;
using System;
using System.Configuration;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Authentication;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http.Filters;

namespace Smag.Framework.Services.Authentication
{
    public class SmagAuthenticationFilter : Attribute, IAuthenticationFilter
    {
        #region Variables membres



        #endregion Variables membres

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut.
        /// </summary>
        public SmagAuthenticationFilter()
        {
        }

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="config">Configuration de l'authentification de l'application Jarvis.</param>
        public SmagAuthenticationFilter(OAuthClient config)
        {
        }

        #endregion Constructeurs

        #region Méthodes

        public bool AllowMultiple
        {
            get
            {
                return false;
            }
        }

        public Task AuthenticateAsync(HttpAuthenticationContext context, CancellationToken cancellationToken)
        {
            if (context.SkipAuthentication())
                return Task.FromResult(0);

            HttpRequestMessage req = context.Request;

            var headerPair = req.Headers.FirstOrDefault(o => o.Key == AuthenticationParameterValue.SmagAuthorizationHeaderKey);

            if (headerPair.Key == null)
                throw new AuthenticationException($"No Smag Authorization header was present. Expecting {AuthenticationParameterValue.SmagAuthorizationHeaderKey}: Bearer xxxxxx");

            var header = headerPair.Value.FirstOrDefault();

            if (header == null)
                throw new AuthenticationException($"No Smag Authorization header was present. Expecting this header key : {AuthenticationParameterValue.SmagAuthorizationHeaderKey}");

            string customSmagHeader = header.ToString();

            AuthenticationHeaderValue authorization = null;

            if (!AuthenticationHeaderValue.TryParse(customSmagHeader, out authorization) || authorization == null || authorization.Scheme != "Bearer")
                throw new AuthenticationException($"The Smag Authorization header is in the wrong format. Expecting {AuthenticationParameterValue.SmagAuthorizationHeaderKey}: Bearer {{JWT}}");

            if (string.IsNullOrEmpty(authorization.Parameter))
                throw new AuthenticationException("Missing Json Web Token");

            if (string.IsNullOrEmpty(authorization.Parameter.Replace("Bearer ", "")))
                throw new AuthenticationException("Missing credentials");

            string jwt = authorization.Parameter.Replace("Bearer ", "");
            ClaimsPrincipal claimsPrincipal = null;

            try
            {
                SecurityToken securityToken;
                var tokenHandler = new JwtSecurityTokenHandler();
                var validationParameters = new TokenValidationParameters()
                {
                    ValidAudience = AuthenticationParameterValue.ClientId,
                    ValidIssuer = AuthenticationParameterValue.Issuer,
                    IssuerSigningKey = new X509SecurityKey(new X509Certificate2(GetRessource()))
                };

                claimsPrincipal = tokenHandler.ValidateToken(jwt, validationParameters, out securityToken);

                if (HttpContext.Current != null)
                {
                    HttpContext.Current.User = Thread.CurrentPrincipal;
                }
            }
            catch (SecurityTokenValidationException ex)
            {
                throw new AuthenticationException("Invalid Json Web Token" + ex.Message);
            }
            catch (Exception ex)
            {
                throw new ServiceException("Authentication Error", "An error occured while reading the Json Web Token " + ex.Message);
            }

            var newIdentity = claimsPrincipal.Identity as ClaimsIdentity;
            newIdentity.AddClaim(new Claim("Token", jwt));

            HttpContext.Current.User = claimsPrincipal;
            HttpContext.Current.Application.Add("Token", jwt);

            return Task.FromResult(0);
        }

        public Task ChallengeAsync(HttpAuthenticationChallengeContext context, CancellationToken cancellationToken)
        {
            return Task.FromResult(0);
        }

        public byte[] GetRessource()
        {
            string env = ConfigurationManager.AppSettings.Get("Environment");

            switch (env)
            {
                case "dev": return Properties.Resources.mysmag_portal_dev;
                case "validation": return Properties.Resources.mysmag_portal_validation;
                case "preprod": return Properties.Resources.mysmag_portal_preprod;
                case "prod": return Properties.Resources.mysmag_portal_prod;

                default: return Properties.Resources.mysmag_portal_dev;
            }

        }

        #endregion Méthodes
    }
}