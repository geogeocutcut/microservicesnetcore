﻿using System.Collections.Generic;

namespace Smag.Framework.Services.Client
{
    public class HttpHeaderHelper
    {
        /// <summary>
        /// preparer a dico for http headers
        /// As suggested in the name of this function, it's currently a specific method for adding informations such as token and api key, and only for SMAG use cases
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        public static IDictionary<string, string> BuildSmagHttpHeader(string token = null)
        {
            var headers = new Dictionary<string, string>
            {
                
                
            };

            if (!string.IsNullOrEmpty(token))
                headers.Add("SmagAuthorization", $"Bearer {token}");

                headers.Add("Ocp-Apim-Trace", "false");

            return headers;
        }
    }
}