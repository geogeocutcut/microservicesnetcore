﻿using Smag.Framework.ServiceDiscovery;
using System;
using System.Collections.Generic;
using System.Net.Http;

namespace Smag.Framework.Services.Client
{
    /// <summary>
    /// this class is only used for holding a root uri endpoint
    /// a Build method is provide for building a ExecutableSecureHttpClient based on the root uri
    /// </summary>
    public class SecureHttpClientRoot
    {
        private IDictionary<string, string> _headers;
        private IServiceDiscovery _serviceDiscovery;
        private readonly string _rootEndPointUri;

        public SecureHttpClientRoot(string rootEndPointUri)
        {
            if (string.IsNullOrEmpty(rootEndPointUri))
                throw new ArgumentException(nameof(rootEndPointUri));

            _rootEndPointUri = rootEndPointUri + (rootEndPointUri.EndsWith("/") ? "" : "/");
        }

        /// <summary>
        /// add headers if necessary
        /// </summary>
        /// <param name="headers"></param>
        /// <returns></returns>
        public SecureHttpClientRoot WithHeaders(IDictionary<string, string> headers)
        {
            _headers = headers;
            return this;
        }

        /// <summary>
        /// add service discovery if necessary
        /// </summary>
        /// <param name="serviceDiscovery"></param>
        /// <returns></returns>
        public SecureHttpClientRoot WithServiceDiscovery(IServiceDiscovery serviceDiscovery)
        {
            _serviceDiscovery = serviceDiscovery;
            return this;
        }

        /// <summary>
        /// build a executable secure http client with the full endpoint and headers if exist
        /// </summary>
        /// <param name="complementUri">the complement uri to add after the root endpoint uri</param>
        /// <returns></returns>
        public ExecutableSecureHttpClient Build(string complementUri = null)
        {
            return new ExecutableSecureHttpClient($"{_rootEndPointUri}{complementUri}", _headers);
        }

        /// <summary>
        /// using ServiceDiscovery to  build a executable secure http client with the full endpoint and headers if exist
        /// </summary>
        /// <param name="serviceDiscoveryKey">the key to find in ServiceDiscovery</param>
        /// <param name="paramValues">additional parameters to be integrated into final uri</param>
        /// <returns></returns>
        public ExecutableSecureHttpClient BuildWithServiceDiscovery(string serviceDiscoveryKey, string[] paramValues = null)
        {
            if (_serviceDiscovery == null)
                throw new Exception("ServiceDiscovery not set yet");

            if (string.IsNullOrEmpty(serviceDiscoveryKey))
                throw new ArgumentException(nameof(serviceDiscoveryKey));

            var completeUri = paramValues == null ? _serviceDiscovery.Get(serviceDiscoveryKey) : string.Format(_serviceDiscovery.Get(serviceDiscoveryKey), paramValues);

            return new ExecutableSecureHttpClient($"{_rootEndPointUri}{completeUri}", _headers);
        }
    }
}