﻿using MsgPack.Serialization;
using Newtonsoft.Json;
using Smag.Framework.Common.Exceptions;
using Smag.Framework.Common.Logs;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using Unity.Interception.Utilities;

namespace Smag.Framework.Services.Client
{
    public class ExecutableSecureHttpClient
    {
        public const string CORRELATION_KEY = "X-Correlation-ID";
        public const string SUBSCRIPTION_PRODUCT_KEY = "Ocp-Apim-Subscription-Key";
        public const string SECONDARY_SUBSCRIPTION_PRODUCT_KEY = "Ocp-Apim-Subscription-Key-Secondary";

        public string SmagOcpApimSmagExtended
        {
            get
            {
                string env = ConfigurationManager.AppSettings.Get("Environment");

                switch (env)
                {
                    case "dev": return Properties.Resources.Ocp_Apim_Subscription_Key_develop;
                    case "validation": return Properties.Resources.Ocp_Apim_Subscription_Key_release;
                    case "preprod": return Properties.Resources.Ocp_Apim_Subscription_Key_staging;
                    case "prod": return Properties.Resources.Ocp_Apim_Subscription_Key_production;
                    default: return Properties.Resources.Ocp_Apim_Subscription_Key_develop;
                }
            }
        }

        //http headers to add for request
        private readonly IDictionary<string, string> _headers;

        //the final uri to call
        private readonly Uri _fullUri;

        public ExecutableSecureHttpClient(string fullUri, IDictionary<string, string> headers = null)
        {
            _headers = headers;
            _fullUri = new Uri(fullUri);
        }

        #region Get

        public T Get<T>() => JsonConvert.DeserializeObject<T>(SendGet());

        private string SendGet([CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            using (var requestMessage = BuildHttpRequestMessageWithHeaders(HttpMethod.Get, _fullUri))
                return HttpCall(requestMessage, callerFilePath, callerName, callerLineNumber);
        }

        public async Task<T> GetAsync<T>()
            => await SendGetAsync<T>();

        private async Task<T> SendGetAsync<T>([CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            using (var requestMessage = BuildHttpRequestMessageWithHeaders(HttpMethod.Get, _fullUri))
                return await HttpCallAsync<T>(requestMessage, callerFilePath, callerName, callerLineNumber);
        }

        #endregion Get

        #region Put

        public T Put<T>(Dictionary<string, string> parameters, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            var content = parameters == null ? null : new FormUrlEncodedContent(parameters);
            return JsonConvert.DeserializeObject<T>(SendPut(content));
        }

        public T Put<T>(object obj, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            var json = JsonConvert.SerializeObject(obj);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var res = SendPut(content);
            var entity = JsonConvert.DeserializeObject<T>(res);
            return entity;
        }

        public void Put(object obj, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            var stringContent = new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
            SendPut(stringContent);
        }

        private string SendPut(HttpContent content = null, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            using (var requestMessage = BuildHttpRequestMessageWithHeaders(HttpMethod.Put, _fullUri, content))
                return HttpCall(requestMessage, callerFilePath, callerName, callerLineNumber);
        }

        public async Task<T> PutAsync<T>(object obj, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            var content = new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
            return await SendPutAsync<T>(content);
        }

        private async Task<T> SendPutAsync<T>(HttpContent content = null, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            using (var requestMessage = BuildHttpRequestMessageWithHeaders(HttpMethod.Put, _fullUri, content))
                return await HttpCallAsync<T>(requestMessage, callerFilePath, callerName, callerLineNumber);
        }

        #endregion Put

        #region Post

        public T Post<T>(Dictionary<string, string> parameters, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            var content = parameters == null ? null : new FormUrlEncodedContent(parameters);
            return JsonConvert.DeserializeObject<T>(SendPost(content));
        }

        public T Post<T>(object obj, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            var content = new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
            return JsonConvert.DeserializeObject<T>(SendPost(content));
        }

        public T Post<T>([CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            return JsonConvert.DeserializeObject<T>(SendPost());
        }

        public void Post(object obj, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            var stringContent = new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
            SendPost(stringContent);
        }

        private string SendPost(HttpContent content = null, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            using (var requestMessage = BuildHttpRequestMessageWithHeaders(HttpMethod.Post, _fullUri, content))
                return HttpCall(requestMessage, callerFilePath, callerName, callerLineNumber);
        }

        public async Task<T> PostAsync<T>(object obj, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            var content = new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
            return await SendPostAsync<T>(content);
        }

        public async Task PostAsync(object obj, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            var stringContent = new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
            await SendPostAsync(stringContent);
        }

        private async Task<T> SendPostAsync<T>(HttpContent content = null, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            using (var requestMessage = BuildHttpRequestMessageWithHeaders(HttpMethod.Post, _fullUri, content))
                return await HttpCallAsync<T>(requestMessage, callerFilePath, callerName, callerLineNumber);
        }

        private async Task SendPostAsync(HttpContent content = null, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            using (var requestMessage = BuildHttpRequestMessageWithHeaders(HttpMethod.Post, _fullUri, content))
                await HttpCallAsync(requestMessage, callerFilePath, callerName, callerLineNumber);
        }

        #endregion Post

        #region Delete

        public void Delete() => SendDelete();

        private string SendDelete([CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            using (var requestMessage = BuildHttpRequestMessageWithHeaders(HttpMethod.Delete, _fullUri))
                return HttpCall(requestMessage, callerFilePath, callerName, callerLineNumber);
        }

        public async Task DeleteAsync()
            => await SendDeleteAsync();

        private async Task SendDeleteAsync([CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            using (var requestMessage = BuildHttpRequestMessageWithHeaders(HttpMethod.Delete, _fullUri))
                await HttpCallAsync<Task>(requestMessage, callerFilePath, callerName, callerLineNumber);
        }

        #endregion Delete

        private static string HttpCall(HttpRequestMessage requestMessage, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            try
            {
                Log.Info($"---{requestMessage.Method.Method} : {requestMessage.RequestUri.AbsoluteUri}---");

                using (var response = HttpClientFactory.GetClient().SendAsync(requestMessage, default(CancellationToken)).Result)
                {
                    if (!response.IsSuccessStatusCode)
                    {
                        Log.Debug($"{requestMessage.Method.Method} : {callerFilePath}, {callerName}, line number : {callerLineNumber} return error status");
                        throw new HttpCallException(
                            $"{requestMessage.Method.Method} : {requestMessage.RequestUri.AbsoluteUri} error",
                            $"{(int)response.StatusCode} {response.StatusCode} : {response.ReasonPhrase}");
                    }

                    return response.Content?.ReadAsStringAsync().Result;
                }
            }
            catch (AggregateException ae)
            {
                foreach (var e in ae.Flatten().InnerExceptions)
                    Log.Error($"{e.GetType().Name}:\n {e.Message}");

                throw;
            }
        }

        private static async Task<T> HttpCallAsync<T>(HttpRequestMessage requestMessage, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            try
            {
                Log.Info($"---{requestMessage.Method.Method} : {requestMessage.RequestUri.AbsoluteUri}---");

                using (var response = await HttpClientFactory.GetClient().SendAsync(requestMessage, default(CancellationToken)))
                {
                    if (!response.IsSuccessStatusCode)
                    {
                        Log.Debug($"{requestMessage.Method.Method} : {callerFilePath}, {callerName}, line number : {callerLineNumber} return error status");
                        throw new HttpCallException(
                            $"{requestMessage.Method.Method} : {requestMessage.RequestUri.AbsoluteUri} error",
                            $"{(int)response.StatusCode} {response.StatusCode} : {response.ReasonPhrase}");
                    }

                    return JsonConvert.DeserializeObject<T>(await response.Content.ReadAsStringAsync());

                }
            }
            catch (AggregateException ae)
            {
                foreach (var e in ae.Flatten().InnerExceptions)
                    Log.Error($"{e.GetType().Name}:\n {e.Message}");

                throw;
            }
        }

        private static async Task HttpCallAsync(HttpRequestMessage requestMessage, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            try
            {
                Log.Info($"---{requestMessage.Method.Method} : {requestMessage.RequestUri.AbsoluteUri}---");

                using (var response = await HttpClientFactory.GetClient().SendAsync(requestMessage, default(CancellationToken)))
                    if (!response.IsSuccessStatusCode)
                    {
                        Log.Debug($"{requestMessage.Method.Method} : {callerFilePath}, {callerName}, line number : {callerLineNumber} return error status");
                        throw new HttpCallException(
                            $"{requestMessage.Method.Method} : {requestMessage.RequestUri.AbsoluteUri} error",
                            $"{(int)response.StatusCode} {response.StatusCode} : {response.ReasonPhrase}");
                    }
            }
            catch (AggregateException ae)
            {
                foreach (var e in ae.Flatten().InnerExceptions)
                    Log.Error($"{e.GetType().Name}:\n {e.Message}");

                throw;
            }
        }

        /// <summary>
        /// build a new httpRequestMessage with headers
        /// </summary>
        private HttpRequestMessage BuildHttpRequestMessageWithHeaders(HttpMethod method, Uri uri, HttpContent content = null)
        {
            var httpRequestMessage = new HttpRequestMessage(method, uri);

            #region Add Correlation ID : API Manager

            try
            {
                string resultCorrelation;
                string resultSub = HttpContext.Current.Request.Headers[SUBSCRIPTION_PRODUCT_KEY];
                string resultSecondarySub = HttpContext.Current.Request.Headers[SECONDARY_SUBSCRIPTION_PRODUCT_KEY];

                if (!string.IsNullOrEmpty(HttpContext.Current.Request.Headers[CORRELATION_KEY]))
                    resultCorrelation = HttpContext.Current.Request.Headers.GetValues(CORRELATION_KEY).First();
                else
                    resultCorrelation = httpRequestMessage.GetCorrelationId().ToString();

                if (string.IsNullOrEmpty(resultSub))
                    Log.Info("the Ocp-Apim-Subscription-Key wasn't found!");

                if (string.IsNullOrEmpty(resultSecondarySub))
                {
                    httpRequestMessage.Headers.Add(SECONDARY_SUBSCRIPTION_PRODUCT_KEY, resultSub);
                    httpRequestMessage.Headers.Add(SUBSCRIPTION_PRODUCT_KEY, SmagOcpApimSmagExtended);
                }
                else
                {
                    httpRequestMessage.Headers.Add(SUBSCRIPTION_PRODUCT_KEY, resultSub);
                    httpRequestMessage.Headers.Add(SECONDARY_SUBSCRIPTION_PRODUCT_KEY, resultSecondarySub);
                }


                httpRequestMessage.Headers.Add(CORRELATION_KEY, resultCorrelation);
            }
            catch (Exception ex)
            {
                Log.Exception(ex);
            }

            #endregion Add Correlation ID : API Manager

            _headers?.ForEach(x => httpRequestMessage.Headers.Add(x.Key, x.Value));

            if ((method == HttpMethod.Post || method == HttpMethod.Put) && content != null)
                httpRequestMessage.Content = content;

            return httpRequestMessage;
        }
    }
}