﻿using Newtonsoft.Json;
using Smag.Framework.Authentication;
using Smag.Framework.Common.Logs;
using Smag.Framework.ServiceDiscovery;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Text;
using System.Web;

namespace Smag.Framework.Services.Client
{
    public class SecureHttpClient
    {
        private bool __build = false;
        private bool __initialized = false;

        private static ConcurrentDictionary<string, SecureHttpClient> _dictionaySecureEndPoint { get; } = new ConcurrentDictionary<string, SecureHttpClient>();

        private string _smagAuthorization { get; set; } = string.Empty;

        private IServiceDiscovery _serviceDiscovery;

        private string _rootUri;

        private HttpClient _client { get; set; }

        private string _completeUrl { get; set; } = string.Empty;

        public static SecureHttpClient Initialize(AuthenticationContext authCtxt, string rootUri, IServiceDiscovery serviceDiscovery)
        {
            if (authCtxt == null)
                throw new ArgumentNullException(nameof(authCtxt));

            if (string.IsNullOrEmpty(rootUri))
                throw new ArgumentException();

            return new SecureHttpClient()
            {
                //if rootUri does not have backslash in the end, we add one
                _rootUri = rootUri + (rootUri.EndsWith("/") ? "" : "/"),
                _serviceDiscovery = serviceDiscovery,
                _smagAuthorization = authCtxt.Token,
                __initialized = true
            };
        }

        public static SecureHttpClient Initialize(string token, string rootUri) => Initialize(new AuthenticationContext { Token = token }, rootUri, null);

        /// <summary>
        ///
        /// </summary>
        /// <param name="apiEndpoint">
        ///     if the SecureHttpClient has been initialized with a ServiceDiscovery, we will try to find the endPoint base by the ServiceDiscoverty.
        ///     Otherwise, we will directly do a string concat based on the root uri and the apiEndpoint
        /// </param>
        /// <returns></returns>
        public SecureHttpClient Build(string apiEndpoint)
        {
            if (!__initialized)
                throw new Exception("Vous devez faire appel à la méthode Initialize() dans le constructeur");

            var endPoint = _serviceDiscovery != null ? _serviceDiscovery.Get(apiEndpoint) : apiEndpoint;
            _completeUrl = $"{_rootUri}{endPoint}";

            SecureHttpClient secureClient = null;
            if (!_dictionaySecureEndPoint.TryGetValue(_completeUrl, out secureClient))
            {
                secureClient = (SecureHttpClient)MemberwiseClone();
                secureClient.__build = true;
                secureClient._client = new HttpClient() { BaseAddress = new Uri(_completeUrl) };
                _dictionaySecureEndPoint.TryAdd(_completeUrl, secureClient);
            }

            //update token if necessary
            if (secureClient._smagAuthorization == null || !secureClient._smagAuthorization.Equals(_smagAuthorization))
                secureClient._smagAuthorization = _smagAuthorization;

            return secureClient;
        }

        public T Post<T>(Dictionary<string, string> parameters, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            var content = parameters == null ? null : new FormUrlEncodedContent(parameters);
            return JsonConvert.DeserializeObject<T>(Send(content));
        }

        public T Post<T>(object obj, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            var content = new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
            return JsonConvert.DeserializeObject<T>(Send(content));
        }

        public T Post<T>([CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            return JsonConvert.DeserializeObject<T>(Send());
        }

        public void Post(object obj, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            var stringContent = new StringContent(JsonConvert.SerializeObject(obj), Encoding.UTF8, "application/json");
            Send(stringContent);
        }

        private string Send(HttpContent content = null, [CallerFilePath] string callerFilePath = null, [CallerMemberName] string callerName = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            if (!__initialized || !__build)
                throw new Exception("Vous devez faire appel à la méthode Initialize() & Build() avant de faire un post");

            using (var requestMessage = new HttpRequestMessage(HttpMethod.Post, _completeUrl))
            {
                Log.Info("SecureHttpClient completeUrl : " + _completeUrl);
                requestMessage.Headers.Add("SmagAuthorization", $"Bearer {_smagAuthorization}");

                requestMessage.Headers.Add("Ocp-Apim-Trace", "false");

                if (string.IsNullOrEmpty(HttpContext.Current.Request.Headers["Ocp-Apim-Subscription-Key"]))
                    Log.Info("ERROR Ocp-Apim-Subscription-Key NOT FOUND ");
                    
                if (content != null)
                {
                    Log.Info("SecureHttpClient content : " + content);
                    requestMessage.Content = content;
                }

                ServicePointManager.SecurityProtocol = ServicePointManager.SecurityProtocol | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12; 

                using (HttpResponseMessage response = _client.SendAsync(requestMessage).Result)
                {
                    if (!response.IsSuccessStatusCode)
                    {


                        Log.Debug("Post  : " + (callerFilePath != null ? callerFilePath : "") + ", " + callerName + ", " + " line number : " + callerLineNumber + " return error status");
                        throw new Exception("Post  : " + callerName + ", return error status");
                    }
                    return response.Content != null ? response.Content.ReadAsStringAsync().Result : null;
                }
            }
        }
    }
}