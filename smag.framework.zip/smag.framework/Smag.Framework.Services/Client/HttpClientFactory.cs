﻿using System.Net;
using System.Net.Http;

namespace Smag.Framework.Services.Client
{
    public class HttpClientFactory
    {
        private static volatile HttpClient _client;

        private static volatile object _lockObj = new object();

        static HttpClientFactory()
        {
            if (_client == null)
                lock (_lockObj)
                    if (_client == null)
                    {
                        ServicePointManager.SecurityProtocol = ServicePointManager.SecurityProtocol | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                        ServicePointManager.DefaultConnectionLimit = 100;
                        _client = new HttpClient();
                       // _client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/x-msgpack"));

                    }
}

        public static HttpClient GetClient() => _client;
    }
}