﻿using Smag.Framework.Common;
using Smag.Framework.KeyManager;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace Smag.Framework.Services.AttributeFilters
{
    public class MaintenanceFilterAttribute : Attribute, IActionFilter
    {

        public MaintenanceFilterAttribute()
        {

        }
        public Task<HttpResponseMessage> ExecuteActionFilterAsync(HttpActionContext actionContext, CancellationToken cancellationToken, Func<Task<HttpResponseMessage>> continuation)
        {
            bool isMaintenance = Boolean.Parse(Settings.GetWithManagerType("MaintenanceEnabled", MType.WebConfig) ??"false");
            string Title = Settings.GetWithManagerType("MaintenanceTitle", MType.WebConfig) ??"";
            string Message = Settings.GetWithManagerType("MaintenanceMessage", MType.WebConfig) ??"";

            if (isMaintenance)
            {
                throw new ServiceException("maintenance_exception", Title + "_" + Message);
            }
        
            return continuation(); 
        }

        public bool AllowMultiple
        {
            get { return true; }
        }
    }
}