﻿
using System.Collections.Generic;

namespace Smag.Framework.Specification
{
    public abstract class AbstractCompositeSpecification : ISpecification
    {
        public string Name { get; set; }

        public string Message { get; set; }

        public AbstractCompositeSpecification()
        {
            Name = this.GetType().ToString();
        }

        public abstract BusinessResult IsSatisfiedBy(Dictionary<string, object> data);
        public ISpecification And(ISpecification otherSpecification) => new AndSpecification(this, otherSpecification);
        public ISpecification Or(ISpecification otherSpecification) => new OrSpecification(this, otherSpecification);
        public ISpecification Not() => new NotSpecification(this);
    }
}