﻿using System.Collections.Generic;

namespace Smag.Framework.Specification
{
    public class NotSpecification : AbstractCompositeSpecification
    {
        private ISpecification _condition;
        public NotSpecification(ISpecification spec)
        {
            _condition = spec;
        }
        public override BusinessResult IsSatisfiedBy(Dictionary<string, object> data)
        {
            BusinessResult br = new BusinessResult();
            if(_condition.IsSatisfiedBy(data).IsSuccess)
            {
                br.Violations.Add(new BusinessViolation {
                    Level = BusinessLevel.Error,
                    Message = "Specification Not " + Name + " isn't satisfied"
                });
            }
            return br;
        }
    }
}
