﻿

namespace Smag.Framework.Specification
{
    public enum BusinessLevel
    {
        BlockingError,
        Error,
        Warning,
        Info
    }
}
