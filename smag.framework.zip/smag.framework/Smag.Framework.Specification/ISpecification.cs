﻿using System.Collections.Generic;

namespace Smag.Framework.Specification
{

    /// <summary>
    /// Définit un comportement général pour la définition d'une règle de gestion
    /// https://en.wikipedia.org/wiki/Specification_pattern
    //  http://blog.xebia.fr/2009/12/29/le-pattern-specification-pour-la-gestion-de-vos-regles-metier/
    /// </summary>
    public interface ISpecification
    {
        /// <summary>
        /// // Détermine si la règle métier est respectée
        /// </summary>
        BusinessResult IsSatisfiedBy(Dictionary<string, object> data);

        /// <summary>
        /// Chainage de règles en ET
        /// </summary>
        ISpecification And(ISpecification otherSpecification);

        /// <summary>
        /// Chainage de règles en OU
        /// </summary>
        ISpecification Or(ISpecification otherSpecification);

        /// <summary>
        /// Contraire d'une règle
        /// </summary>
        ISpecification Not();
    }
}