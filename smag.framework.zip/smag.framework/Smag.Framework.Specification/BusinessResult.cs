﻿using System.Collections.Generic;
using System.Linq;

namespace Smag.Framework.Specification
{
    public class BusinessResult
    {
        public List<BusinessViolation> Violations
        {
            get
            {
                return violations;
            }
            set
            {
                violations = value;
            }
        }

        private List<BusinessViolation> violations;
        public bool IsSuccess {
            get {
                return !violations.Any(x=>x.Level==BusinessLevel.Error);
            }
        }


        public bool HasBlockingError
        {
            get
            {
                return violations.Any(x => x.Level == BusinessLevel.BlockingError);
            }
        }
        public string Messages
        {
            get
            {
                string mess = "";
                foreach(BusinessViolation v in violations)
                {
                    mess+=(string.IsNullOrEmpty(mess) ? "" : "\n")+v.Message;
                }
                return mess;
            }
        }
        public BusinessResult()
        {
            violations = new List<BusinessViolation>();
        }
        
    }
}
