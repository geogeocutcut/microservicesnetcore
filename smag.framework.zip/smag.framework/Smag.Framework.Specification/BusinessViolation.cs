﻿

namespace Smag.Framework.Specification
{
    public class BusinessViolation
    {
        public string Message { get; set; }

        public BusinessLevel Level { get; set; }
        
    }
}
