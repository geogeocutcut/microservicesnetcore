﻿using System.Collections.Generic;

namespace Smag.Framework.Specification
{
    /// <summary>
    /// Opérateur AND pour les spécifications
    /// </summary>
    public class AndSpecification : AbstractCompositeSpecification
    {
        private ISpecification _conditionLeft;
        private ISpecification _conditionRight;

        public AndSpecification(ISpecification left, ISpecification right)
        {
            _conditionLeft = left;
            _conditionRight = right;
        }

        public override BusinessResult IsSatisfiedBy(Dictionary<string, object> data)
        {
            BusinessResult resultSpecification = new BusinessResult();
            var br1 = _conditionLeft.IsSatisfiedBy(data);
            var br2 = _conditionRight.IsSatisfiedBy(data);
            if (!br1.IsSuccess || !br2.IsSuccess)
            {
                resultSpecification.Violations.AddRange(br1.Violations);
                resultSpecification.Violations.AddRange(br2.Violations);
            }

            
            return resultSpecification;
        }
    }
}