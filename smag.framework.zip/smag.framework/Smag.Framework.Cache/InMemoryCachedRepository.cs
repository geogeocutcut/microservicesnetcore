﻿using Smag.Framework.Common.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace Smag.Framework.Cache
{
    public class InMemoryCachedRepository<TId, TEntity> : ICachedRepository<TId, TEntity> where TEntity : BaseEntity<TId>
    {
        private static CachedData<IDictionary<TId, TEntity>> _data=new CachedData<IDictionary<TId, TEntity>>();
        private object lockObj = new object();

        public void Delete(TId id)
        {
            lock(lockObj)
            {
                if (_data.Data.Keys.Contains(id))
                {
                    _data.Data.Remove(id);
                }
            }
        }

        public IList<TEntity> FindBy(Expression<Func<TEntity, bool>> predicate)
        {
            return _data.Data.Values.Where(predicate.Compile()).ToList();
        }

        public IList<TEntity> GetAll()
        {
            return _data.Data.Values.ToList();
        }

        public TEntity GetById(TId id)
        {
            TEntity data;
            if (_data.Data == null)
                return null;
            _data.Data.TryGetValue(id, out data);
            return data;
        }

        public TEntity Upsert(TEntity entity)
        {
            lock (lockObj)
            {
                if(_data.Data == null)
                {
                    _data.Data = new Dictionary<TId, TEntity>();
                }
                _data.Data[entity.Id] = entity;
            }
            return entity;
        }
    }
}
