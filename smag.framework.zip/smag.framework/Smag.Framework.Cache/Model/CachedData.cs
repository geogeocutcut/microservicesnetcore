﻿

using System;

namespace Smag.Framework.Cache
{
    public class CachedData<TData>
    {
        public DateTime ExpirationDate { get; set; }
        public TData Data { get; set; }
    }
}
