﻿using Smag.Framework.Common.Model;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace Smag.Framework.Cache
{
    public interface ICachedRepository<TId,TEntity> where TEntity:BaseEntity<TId>
    {
        IList<TEntity> GetAll();
        TEntity Upsert(TEntity entity);
        void Delete(TId id);
        TEntity GetById(TId id);
        IList<TEntity> FindBy(Expression<Func<TEntity, bool>> predicate);
    }
}
