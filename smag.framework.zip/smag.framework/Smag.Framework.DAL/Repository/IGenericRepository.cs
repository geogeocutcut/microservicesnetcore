﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace Smag.Framework.DAL.Repository
{
    public interface IGenericRepository<TId, TEntity>
    {
        IList<TEntity> GetAll();
        TEntity GetById(TId id);

        TEntity Insert(TEntity entity);
        TEntity Update(TEntity entity);
        TEntity Upsert(TEntity entity);

        void Delete(TEntity entity);
        void DeleteById(TId id);

        IList<TEntity> FindBy(Expression<Func<TEntity, bool>> predicate);
        int GetCountAll();
        int GetCountBy(Expression<Func<TEntity, bool>> predicate);
    }
}
