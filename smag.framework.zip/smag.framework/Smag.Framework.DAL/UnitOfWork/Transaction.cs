﻿
namespace Smag.Framework.DAL.UnitOfWork
{
    public class Transaction:ITransaction
    {
        private IUnitOfWork _uow;
        public Transaction(IUnitOfWork uow)
        {
            _uow = uow;
        }

        public void Commit()
        {
            _uow.Commit();
        }


        public void Rollback()
        {
            _uow.Rollback();
        }


        public void Dispose()
        {
            _uow.Commit();
        }
    }
}
