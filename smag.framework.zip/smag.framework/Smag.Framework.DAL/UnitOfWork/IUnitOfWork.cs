﻿
namespace Smag.Framework.DAL
{
    public interface IUnitOfWork
    {
        bool InMemory { get; set; }
        ITransaction Begin();
        void Commit();
        void Rollback();
        TRepository GetRepository<TRepository>();

    }
}
