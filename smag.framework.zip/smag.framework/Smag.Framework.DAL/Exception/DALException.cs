﻿using System;
using System.Runtime.Serialization;

namespace Smag.Framework.DAL
{
    public class DALException : Exception,ISerializable
    {
        public DALException()
        { }
        public DALException(string message):base(message)
        { }
        public DALException(string message,Exception innerException) : base(message, innerException)
        { }

        protected DALException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        { }
    }
}
