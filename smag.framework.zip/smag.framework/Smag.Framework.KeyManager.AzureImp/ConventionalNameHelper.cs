﻿namespace Smag.Framework.KeyManager.AzureImp
{
    /// <summary>
    /// This class defined a naming convention for Azure configuration names.
    /// </summary>
    public static class ConventionalNameHelper
    {
        private const string AzureVaultUrlBaseKeyName = "AzureVaultUrl";

        //this is a predefined naming convention for extending configuration key name
        //we currently adopted a simple pattern with the input setting key name as prefix, and the base key name as suffix
        private const string ConventionalNamePattern = "{0}_{1}";

        //Ex : if we have "PartyData" as input key, we will build "PartyData_AzureVaultUrl" as the real key name to be used
        public static string GetAzureConventionalConfigurationName(string initKey)
            => string.Format(ConventionalNamePattern, initKey, AzureVaultUrlBaseKeyName);
    }
}