﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Smag.Framework.TestingMock.Common
{
    public class TestRepository
    {
        public T Get<T>(object u)
        {
            return new JavaScriptSerializer().Deserialize<T>(new JavaScriptSerializer().Serialize(u));
        }
    }
}
