﻿using Newtonsoft.Json;
using Smag.Framework.DAL;
using Smag.Framework.DAL.UnitOfWork;
using System;

namespace Smag.Framework.TestingMock.Data
{
    public abstract class AbstractUnitOfWork<TDataBase> : IUnitOfWork
    {
        private TDataBase _databaseSystem;

        public TDataBase Db { get; set; }
        private string jsonDB = "";


        private bool _isOpen;
        
        public bool TransactionOpen
        {
            get
            {
                return _isOpen;
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public bool InMemory { get; set; } = false;
        public string InMemoryAssemblyName { get; set; } = string.Empty;

        public AbstractUnitOfWork(TDataBase database)
        {
            _databaseSystem = database;
        }
        public void Commit()
        {
            if (_isOpen)
            {
                jsonDB = JsonConvert.SerializeObject(Db);

                if (string.IsNullOrEmpty(jsonDB))
                    throw new Exception("Erreur dans la DALContext de TU : La BDD de TU est mal serializée.");

                _isOpen = false;
            }
            else
                throw new Exception("Erreur dans la DALContext de TU : La transaction n'est pas ouverte.");

        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }

        public ITransaction Begin()
        {
            if (Db == null) // Si la base est nulle, on désérialize depuis le fichier JSON
                Db = _databaseSystem;

            _isOpen = true;

            return new Transaction(this);
        }

        public void Rollback()
        {
            if (_isOpen)
            {
                Db = _databaseSystem;
            }
            else
                throw new Exception("Impossible de rollback une transaction qui n'a pas été ouverte.");

            _isOpen = false;
        }

        public abstract TRepository GetRepository<TRepository>();
    }
}
