﻿using Microsoft.Azure.Services.AppAuthentication;
using NHibernate.Connection;
using System.Data.Common;
using System.Data.SqlClient;

namespace Smag.Framework.DAL.NHImpl.ConnectionProvider
{
    /// <summary>
    /// provider a sql connection by using Azure AD
    /// </summary>
    class AzureConnectionProvider : DriverConnectionProvider
    {
        public override System.Data.IDbConnection GetConnection()
        {
            var connection = (SqlConnection)Driver.CreateConnection();
            try
            {
                connection.ConnectionString = ConnectionString;

                if (!ConnectionString.ToUpper().Contains("USER ID="))
                {
                    connection.AccessToken = new AzureServiceTokenProvider()
                        .GetAccessTokenAsync("https://database.windows.net/")
                        .GetAwaiter().GetResult();
                }

                connection.Open();
            }
            catch (DbException)
            {
                connection.Dispose();
                throw;
            }

            return connection;
        }
    }
}
