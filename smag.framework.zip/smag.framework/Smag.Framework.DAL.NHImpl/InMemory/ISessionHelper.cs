﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NHibernate;


namespace Smag.Framework.DAL.NHImpl.InMemory
{
    public interface ISessionHelper
    {
        ISession OpenSession();
    }
}
