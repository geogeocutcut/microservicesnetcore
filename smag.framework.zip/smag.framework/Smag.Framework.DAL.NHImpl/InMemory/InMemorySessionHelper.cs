﻿using NHibernate;
using NHibernate.Cfg;
using NHibernate.Dialect;
using NHibernate.Driver;
using NHibernate.Mapping;
using NHibernate.Tool.hbm2ddl;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Smag.Framework.DAL.NHImpl.InMemory
{
    public class InMemorySessionHelper : ISessionHelper, IDisposable

    {
        private const string Connectionstring = "Data Source=:memory:";

        private readonly NHibernate.Cfg.Configuration _config;
        private readonly ISessionFactory _sessionFactory;
        private SQLiteConnection _connection;

        public InMemorySessionHelper(Assembly assembly)
        {
            
            _config = new NHibernate.Cfg.Configuration()
                .DataBaseIntegration(db =>
                {
                    db.Dialect<SQLiteDialect>();
                    db.Driver<SQLite20Driver>();
                    db.ConnectionString = Connectionstring;
                    db.LogFormattedSql = true;
                    db.LogSqlInConsole = true;
                })
                .AddAssembly(assembly);
                
           


            foreach (PersistentClass pc in _config.ClassMappings)
            {

                if (pc.Table.Name.Contains("."))
                    pc.Table.Name = pc.Table.Name.Split('.')[1];

                pc.Table.Name = pc.Table.Name.Replace("[", "").Replace("]", "");

            }


            _sessionFactory = _config.BuildSessionFactory();
        }

        public void Dispose()
        {
            _connection?.Dispose();
        }

        public ISession OpenSession()
        {
            return _sessionFactory.OpenSession(GetConnection());
        }

        private SQLiteConnection GetConnection()
        {
            if (_connection == null)
            {
                _connection = new SQLiteConnection(Connectionstring);
                _connection.Open();

                SchemaExport se = new SchemaExport(_config);
                se.Execute(true, true, false, _connection, null);
            }

            return _connection;
        }
    }
}
