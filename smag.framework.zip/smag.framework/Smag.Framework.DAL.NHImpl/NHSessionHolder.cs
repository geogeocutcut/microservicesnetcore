﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using NHibernate;
using NHibernate.Cfg;
using Smag.Framework.Common.Logs;
using Smag.Framework.DAL.NHImpl.ConnectionProvider;
using ConfigurationNH = NHibernate.Cfg.Configuration;

namespace Smag.Framework.DAL.NHImpl
{
    public static class NHSessionHolder
    {

        private static ISessionFactory GlobalSessionFactory;
        private static IDictionary<string, ISessionFactory> SessionFactories = new Dictionary<string, ISessionFactory>();
        private static object syncRoot = new Object();

        private static ISessionFactory BuildSessionFactory()
        {
            ConfigurationNH Config = new ConfigurationNH();
            try
            {
                ConfigurationNH config = Config.Configure();

                var conn = ConfigurationManager.AppSettings.Get("DefaultConnection");
                config.DataBaseIntegration(db => db.ConnectionProvider<AzureConnectionProvider>());

                if (!string.IsNullOrEmpty(conn))
                {
                    Config.AddProperties(new Dictionary<string, string> { { NHibernate.Cfg.Environment.ConnectionString, conn } });
                }

                //Config.SetProperty(NHibernate.Cfg.Environment.BatchStrategy,typeof(NonVerifyingBatcherFactory).AssemblyQualifiedName);
                ISessionFactory factory = Config.BuildSessionFactory();
                return factory;
            }
            catch (Exception ex)
            {
                ex.Log(null, Level.Fatal);
                throw new DALException("Unable to create SessionFactory.", ex);
            }
        }
        private static void BuildSessionFactories(string fileName)
        {

            try
            {
                ConfigurationNH config = new ConfigurationNH();
                config.Configure(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fileName));
                ISessionFactory factory = config.BuildSessionFactory();
                SessionFactories[fileName] = factory;

            }
            catch (Exception ex)
            {
                SessionFactories = null;
                ex.Log(null, Level.Fatal);
                throw new DALException("Unable to create SessionFactory.", ex);
            }
        }

        public static ISessionFactory GetSessionFactory()
        {
            if (GlobalSessionFactory == null)
            {
                lock (syncRoot)
                {
                    if (GlobalSessionFactory == null)
                    {
                        GlobalSessionFactory = BuildSessionFactory();
                    }
                }
            }

            return GlobalSessionFactory;
        }

        public static ISessionFactory GetSessionFactory(string fileName)
        {
            ISessionFactory sessionFactory;
            if (!SessionFactories.TryGetValue(fileName, out sessionFactory))
            {
                lock (syncRoot)
                {
                    if (!SessionFactories.TryGetValue(fileName, out sessionFactory))
                    {
                        BuildSessionFactories(fileName);
                    }
                }
            }

            return SessionFactories[fileName];
        }

    }
}
