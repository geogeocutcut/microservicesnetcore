﻿
using NHibernate.Collection.Generic;
using Smag.Framework.Common.Logs;
using System;
using System.Linq;
using System.Reflection;

namespace NHibernate.Proxy
{
    public static class NHProxyRemoverExtension
    {
        public static void UnProxy(this object objt)
        {
            for (int i = 0; i < objt.GetType().GetProperties().Count(); i++)
            {
                try
                {
                    PropertyInfo propertyInfo = objt.GetType().GetProperties()[i];
                    var propValue = propertyInfo.GetValue(objt, null);
                    if (propValue.IsProxy())
                    {
                        propertyInfo.SetValue(objt, null);
                    }

                    //Lists
                    else if (propValue.GetType().IsGenericType && propValue.GetType().GetGenericTypeDefinition() == typeof(PersistentGenericBag<>))
                    {
                        try
                        {
                            int count = (int)(propValue.GetType().GetProperty("Count").GetValue(propValue));
                        }
                        catch { propertyInfo.SetValue(objt, null); }
                    }

                    else if (propValue.GetType().Assembly.GetName().Name != "mscorlib" &&
                        propValue.GetType().Assembly.GetName().Name != "NHibernate")
                    {
                        // user-defined!
                        propValue.UnProxy();
                    }
                }
                catch
                {
                    Log.Error("An error occured when trying to execute Unproxy's method.");
                }
            }
        }
    }
}