﻿namespace Smag.Framework.DAL.NHImpl
{



    /// <summary>
    /// Configure une session NHibernate.
    /// </summary>
    public interface ISessionFactoryConfiguratorNH
    {

        /// <summary>
        /// Initialise la configuration d'une session NHibernate.
        /// </summary>
        /// <param name="config">Configuration de NHibernate.</param>
        void Configure(ref NHibernate.Cfg.Configuration config);

        /// <summary>
        /// Obtient la chaîne de connexion utilisée dans NHibernate.
        /// </summary>
        /// <returns>Chaîne de connexion utilisée dans NHibernate.</returns>
        string GetConnectionString();

    }



}
