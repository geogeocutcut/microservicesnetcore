﻿using NHibernate;
using NHibernate.Linq;
using Smag.Framework.Common.Logs;
using Smag.Framework.Common.Model;
using Smag.Framework.DAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace Smag.Framework.DAL.NHImpl
{



    public abstract class GenericRepositoryNHBase<TId, T> : IGenericRepository<TId, T>
      where T : AuditableEntity<TId>
    {
        private ISession _ctxt;

        public ISession Ctxt
        {
            get
            {
                return _ctxt;
            }
        }
        public GenericRepositoryNHBase(ISession ctxt)
        {
            _ctxt = ctxt;
        }

        public virtual IList<T> GetAll()
        {
            try
            {
                return FindAll().ToList();
            }
            catch (Exception ex)
            {
                ex.Log();
                throw new DALException("Error occured while getting all data");
            }
        }

        public virtual IList<T> FindBy(Expression<Func<T, bool>> predicate)
        {
            try
            {
                return FindAll().Where(predicate).ToList();

            }
            catch (Exception ex)
            {
                ex.Log();
                throw new DALException("Error occured while retrieving data");
            }
        }
        public virtual int GetCountBy(Expression<Func<T, bool>> predicate)
        {
            try
            {
                return FindAll().Where(predicate).Count();

            }
            catch (Exception ex)
            {
                ex.Log();
                throw new DALException("Error occured while retrieving data");
            }
        }

        public virtual int GetCountAll()
        {
            try
            {
                return FindAll().Count();

            }
            catch (Exception ex)
            {
                ex.Log();
                throw new DALException("Error occured while retrieving data");
            }
        }

        public virtual T GetById(TId id)
        {
            try
            {
                return Ctxt.Get<T>(id);
            }
            catch (Exception ex)
            {
                ex.Log();
                throw new DALException("Error occured while retrieving data");
            }
        }

        public virtual T Insert(T entity)
        {
            try
            {
                if (String.IsNullOrEmpty(entity.UniqueIdentifier))
                {
                    entity.UniqueIdentifier = Guid.NewGuid().ToString();
                }
                Ctxt.Save(entity);
                return entity;
            }
            catch (Exception ex)
            {
                ex.Log();
                throw new DALException("Error occured while creating data");
            }
        }

        public virtual void Delete(T entity)
        {
            try
            {
                Ctxt.Delete(entity);

            }
            catch (Exception ex)
            {
                ex.Log();
                throw new DALException("Error occured while deleting data");
            }
        }

        public virtual T Update(T entity)
        {
            try
            {
                Ctxt.Update(entity);
                return entity;
            }
            catch (Exception ex)
            {
                ex.Log();
                throw new DALException("Error occured while updating data");
            }
        }

        public virtual T Upsert(T entity)
        {
            try
            {
                if (String.IsNullOrEmpty(entity.UniqueIdentifier))
                {
                    entity.UniqueIdentifier = Guid.NewGuid().ToString();
                }
                Ctxt.SaveOrUpdate(entity);
                return entity;

            }
            catch (Exception ex)
            {
                ex.Log();
                throw new DALException("Error occured while upserting data");
            }
        }


        public virtual void DeleteById(TId id)
        {
            try
            {
                T entityToDelete = GetById(id);
                Delete(entityToDelete);
            }
            catch (Exception ex)
            {
                ex.Log();
                throw new DALException("Error occured while deleting data");
            }
        }

        private IQueryable<T> FindAll()
        {
            return Ctxt.Query<T>();
        }
    }
}