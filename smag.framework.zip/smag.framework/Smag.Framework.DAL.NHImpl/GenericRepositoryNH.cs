﻿using NHibernate;
using NHibernate.Linq;
using Smag.Framework.Common.Model;
using Smag.Framework.DAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace Smag.Framework.DAL.NHImpl
{



    public abstract class GenericRepositoryNH<TId, T> : GenericRepositoryNHBase<TId, T>,IGenericRepository<TId, T> where T : AuditableEntity<TId>
    {

        public GenericRepositoryNH(ISession ctxt):base(ctxt)
        {
        }

        public virtual void Delete( T entity, string dbUserId)
        {
            try
            {
                if (!entity.DeletedDate.HasValue)
                {
                    entity.DeletedBy = dbUserId;
                    entity.DeletedDate = DateTime.Now;
                    Ctxt.Update(entity);
                }
            }
            catch (Exception ex)
            {
                throw new DALException("An error occured while deleting data.", ex);
            }
        }

        public virtual void DeleteById(TId id, string dbUserId)
        {
            T entityToDelete = GetById(id);
            Delete( entityToDelete, dbUserId);
        }


        protected virtual IQueryable<T> Fetch(IQueryable<T> query)
        {
            return query;
        }

        protected abstract T GetById(IQueryable<T> query, TId id);

        protected IQueryable<T> FindAll(bool removeDeleted)
        {
            var items = Ctxt.Query<T>();
            return Fetch(removeDeleted ? items.Where(x => !x.DeletedDate.HasValue) : items);
        }

        public virtual IList<T> FindBy(Expression<Func<T, bool>> predicate, bool removeDeleted = true)
        {
            try
            {
                return FindAll( removeDeleted).Where(predicate).ToList();
            }
            catch (Exception ex)
            {
                throw new DALException("An error occured while retrieving data.", ex);
            }
        }

        public virtual IList<T> GetAll(bool removeDeleted = true)
        {
            try
            {
                return FindAll(removeDeleted).ToList();
            }
            catch (Exception ex)
            {
                throw new DALException("An error occured while getting all data.", ex);
            }
        }

        public T GetById(TId id, bool removeDeleted = true)
        {
            try
            {
                return GetById(FindAll(removeDeleted), id);
            }
            catch (Exception ex)
            {
                throw new DALException("An error occured while retrieving data.", ex);
            }
        }

        public virtual T Insert(T entity, string dbUserId)
        {
            try
            {
                if (string.IsNullOrEmpty(entity.UniqueIdentifier))
                    entity.UniqueIdentifier = Guid.NewGuid().ToString();
                entity.CreatedBy = dbUserId;
                entity.CreatedDate = DateTime.Now;
                entity.UpdatedBy = dbUserId;
                entity.UpdatedDate = entity.CreatedDate;
                Ctxt.Save(entity);
                return entity;
            }
            catch (Exception ex)
            {
                throw new DALException("An error occured while creating data.", ex);
            }
        }

        public virtual T Update(T entity, string dbUserId)
        {
            try
            {
                entity.UpdatedBy = dbUserId;
                entity.UpdatedDate = DateTime.Now;
                Ctxt.Update(entity);
                return entity;
            }
            catch (Exception ex)
            {
                throw new DALException("An error occured while updating data.", ex);
            }
        }

        public virtual T Upsert(T entity, string dbUserId)
        {
            try
            {
                if (string.IsNullOrEmpty(entity.UniqueIdentifier))
                    entity.UniqueIdentifier = Guid.NewGuid().ToString();
                if (!entity.CreatedDate.HasValue)
                {
                    entity.CreatedBy = dbUserId;
                    entity.CreatedDate = DateTime.Now;
                }
                entity.UpdatedBy = dbUserId;
                entity.UpdatedDate = DateTime.Now;
                Ctxt.SaveOrUpdate(entity);
                return entity;
            }
            catch (Exception ex)
            {
                throw new DALException("An error occured while upserting data.", ex);
            }
        }

    }



}