﻿namespace Smag.Framework.KeyManager
{
    public abstract class KeyManager : IKeyManager
    {
        public abstract string Get(string key);

        public MType Key { get; }

        protected KeyManager(MType key) => Key = key;
    }
}