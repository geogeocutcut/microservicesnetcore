﻿namespace Smag.Framework.Hadoop.Model
{
    public class TraceRootFile
    {
        public FileStatuses FileStatuses { get; set; }
    }
}
