﻿using System.Collections.Generic;

namespace Smag.Framework.Hadoop.Model
{
    public class FileStatuses
    {
        public List<FileStatus> FileStatus { get; set; }
    }
}
