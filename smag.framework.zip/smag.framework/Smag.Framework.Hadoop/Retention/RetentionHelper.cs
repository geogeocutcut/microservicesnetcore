﻿using log4net;
using Newtonsoft.Json;
using Smag.Framework.Common;
using Smag.Framework.Common.Logs;
using Smag.Framework.Hadoop.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;

namespace Smag.Framework.Hadoop.Retention
{
    public static class RetentionHelper
    {
        private static Dictionary<string, List<string>> CacheDictionaryIn { get; set; }
        private static IWebHdfsClient _client;
        private static int _maxWeight = 52428800;
        private static int _currentWeight = 0;
        private static int _threadCount = 0;


        static RetentionHelper()
        {
            CacheDictionaryIn = new Dictionary<string, List<string>>();
            _maxWeight = int.Parse(ConfigurationManager.AppSettings.Get("CacheSizeMb"));
            _client = new WebHdfsClient(); // TODO: A IOCer

            Log.Debug("Instanciation du retention helper");
        }


        public static void AddToRetention(string path, string value)
        {
            Thread.CurrentThread.Name = _threadCount++.ToString();
            Log.Info("- Le Thread " + Thread.CurrentThread.Name + " arrive dans la classe statique");

            if (string.IsNullOrEmpty(path) || string.IsNullOrEmpty(value))
            {
                throw new ServiceException("Erreur TraceCache", "L'un des paramètres ne peut pas être nul");
            }

            try
            {
                Log.Info("- Thread " + Thread.CurrentThread.Name + " est en train d'attendre le lock du Add......................");

                // Je lock le dico car il est static et est appelé par plein de threads en même temps. 
                lock (CacheDictionaryIn)
                {
                    Log.Info("- Thread " + Thread.CurrentThread.Name + " vient de passer dans le lock du Add (et lock donc à son tour)");

                    if (CacheDictionaryIn.Keys.Contains(path))
                        CacheDictionaryIn[path].Add(value);
                    else
                        CacheDictionaryIn.Add(path, new List<string>() { value });

                    _currentWeight += (value.Length * sizeof(Char) * 2); // on augmente la taille théorique du cache en octets

                    Log.Debug("Poids total du cache : " + _currentWeight);

                }
                Log.Info("- Thread " + Thread.CurrentThread.Name + " vient de sortir du Add et de delocker le dico IN");


                if (_currentWeight >= _maxWeight)
                    FlushCache();
            }
            catch (Exception exc)
            {
               exc.Log();
                throw new ServiceException(exc.Message + " CacheDictionaryIn : " + CacheDictionaryIn?.FirstOrDefault().Value?.Count(), exc.StackTrace); ;
            }
        }


        #region Delegates

        private static void FlushCache()
        {
            Log.Debug("**** Flush du cache. ****");

            // Si le cache arrive à X poids
            Dictionary<string, List<string>> CacheDictionaryOut = null;

            Log.Info("- Thread " + Thread.CurrentThread.Name + " vient de rentrer dans flushCache() et attend devant le lock du flush...........................");

            try
            {

                lock (CacheDictionaryIn)
                {
                    Log.Info("- Thread " + Thread.CurrentThread.Name + " vient de rentrer dans le lock du flush et locke a son tour le dico");
                    Log.Debug("Début du deversement de dico.");
                    Stopwatch sw = new Stopwatch();
                    sw.Start();
                    // On deverse le dico d'entrée dans un dico de sortie pour éviter de locker la variable 
                    CacheDictionaryOut = new Dictionary<string, List<string>>(CacheDictionaryIn);
                    sw.Stop();

                    Log.Debug("Fin du deversement de dico. Temps de traitement : " + sw.Elapsed);

                    // On vide l'ancien dico pour qu'il puisse continuer à être rempli en parallèle du flush
                    CacheDictionaryIn = new Dictionary<string, List<string>>();
                    _currentWeight = 0;
                }

                Log.Info("- Thread " + Thread.CurrentThread.Name + " vient de sortir du lock du dico dans le flush");


                // On fusionne la liste en une seule string pour créer un seul fichier big data
                foreach (var file in CacheDictionaryOut)
                {
                    if (CacheDictionaryOut == null || file.Value == null || file.Value.Count == 0)
                        throw new ServiceException("Erreur lors de l'ouverture du dico OUT", "Le dictionnaire out est soit nul, soit vide");


                    Log.Debug("file.Value.Count " + file.Value.Count);


                    string bigFile = JsonConvert.SerializeObject(file.Value);
                    Random rnd = new Random();
                    string fileName = DateTime.Now.Ticks.ToString() + "_" + rnd.Next(0, int.MaxValue) + ".json";

                    
                    Stopwatch sw = new Stopwatch();
                    Log.Debug("Début de la requete HDFS.");
                    sw.Start();
                    Task.Run(() => _client.CreateTrace(file.Key + "/" + DateTime.Now.Year.ToString() + "/" + DateTime.Now.Month.ToString() + "/" + DateTime.Now.Day.ToString() + "/" + fileName, bigFile));
                    sw.Stop();
                    Log.Debug("Fin de la requete HDFS. Temps de traitement : " + sw.Elapsed);
                }

            }
            catch (OutOfMemoryException exc)
            {
                throw new ServiceException("OUTOFMEMORY " + exc.Message, exc.StackTrace);
            }
            catch (Exception exc)
            {
                throw new ServiceException(exc.Message, exc.StackTrace);
            }
            

            return;
        }

        #endregion

    }
}
