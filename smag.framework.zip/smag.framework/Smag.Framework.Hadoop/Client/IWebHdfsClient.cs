﻿using System.Threading.Tasks;

namespace Smag.Framework.Hadoop.Client
{
    public interface IWebHdfsClient
    {
        Task<string> GetTrace(string path);
        Task<string> GetAllTraces(string path);
        Task<bool> CreateTrace(string path, string content);
    }
}
