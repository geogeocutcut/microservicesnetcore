﻿using Smag.Framework.Common;
using Smag.Framework.Common.Logs;
using System;
using System.Configuration;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Smag.Framework.Hadoop.Client
{
    public class WebHdfsClient : IWebHdfsClient
    {
        //private Uri _serverUrl;
        private string _user;

        private static HttpClientHandler _handler = new HttpClientHandler() { AllowAutoRedirect = false };
        private static HttpClient _client;

        private static HttpClient GetClient
        {
            get
            {
                _client = new HttpClient(_handler) { BaseAddress = new Uri(ConfigurationManager.AppSettings.Get("WebHdfsUri")) };
                _client.DefaultRequestHeaders.Accept.Clear();
                return _client;
            }
        }

  

        public WebHdfsClient()
        {
            try
            {
                _user = ConfigurationManager.AppSettings.Get("HdfsUser");
            }
            catch (Exception e)
            {
                throw new ServiceException("Une erreur s'est produite lors de la lecture du WebConfig", e.Message + "\n" + e.StackTrace);
            }
        }


        #region API Calls

        public async Task<string> GetTrace(string path)
        {
            var response = _client.GetAsync(path + "?user.name=" + _user + "& op=OPEN").Result;

            if (!response.IsSuccessStatusCode)
                return null;

            return await response.Content.ReadAsStringAsync();
        }


        public async Task<string> GetAllTraces(string path)
        {
            var response = _client.GetAsync(path + "?user.name=" + _user + "&op=LISTSTATUS").Result;

            if (!response.IsSuccessStatusCode)
                return null;

            var json = await response.Content.ReadAsStringAsync();

            return json;
        }


        public async Task<bool> CreateTrace(string path, string content)
        {
            HttpResponseMessage response = null;

            try
            {
                Log.Info("- Thread " + Thread.CurrentThread.Name + "va effectuer une méthode async HttpClient (redirection)");
                response = await GetClient.PutAsync(path + "?user.name=" + _user + "&op=CREATE", new StringContent(""));
                Log.Info("- Thread " + Thread.CurrentThread.Name + "a fini une méthode async HttpClient (redirection)");

                return await HandleRedirection(response, content);
            }
            catch (Exception exc)
            {
                Log.Error("***** EXCEPTION WebHDFSClient********* Thread: " + Thread.CurrentThread.Name + " Message: " + exc.Message);
                throw;
            }
            finally
            {
                response?.Dispose();
            }

        }

        #endregion


        #region Helpers

        public async Task<bool> HandleRedirection(HttpResponseMessage response, string content)
        {
            if (response.StatusCode == HttpStatusCode.OK)
                return true;

            if (response.StatusCode != HttpStatusCode.TemporaryRedirect)
                return false;

            if (!response.Headers.Contains("Location"))
                return false;

            var formatedPath = response.Headers.Location.Scheme + "://" +
                response.Headers.Location.Host.Split('-')[1] + "." +
                response.Headers.Location.Host.Split('-')[2] + "." +
                response.Headers.Location.Host.Split('-')[3] + "." +
                response.Headers.Location.Host.Split('-')[4].Split('.')[0] + ":" +
                response.Headers.Location.Port;



            HttpResponseMessage response2 = null;

            try
            {
                Log.Info("- Thread " + Thread.CurrentThread.Name + " va instancier un HttpClient pour le deuxieme create");
                using (var client = new HttpClient(new HttpClientHandler()))
                {
                    Log.Info("- Thread " + Thread.CurrentThread.Name + " a instancié un HttpClient pour le deuxieme create");
                    client.BaseAddress = new Uri(formatedPath);
                    response2 = await client.PutAsync(response.Headers.Location.AbsolutePath + response.Headers.Location.Query, new StringContent(content));
                }
                Log.Info("- Thread " + Thread.CurrentThread.Name + " a dispose un HttpClient pour le deuxieme create");

                return response2.IsSuccessStatusCode;
            }
            catch (Exception exc)
            {
                Log.Error("***** EXCEPTION WebHDFSClient********* Thread: " + Thread.CurrentThread.Name + " Message: " + exc.Message);
                throw;
            }
            finally
            {
                
                response2?.Dispose();
            }
        }

        #endregion

    }
}
