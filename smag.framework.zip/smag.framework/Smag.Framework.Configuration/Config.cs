﻿using Newtonsoft.Json;
using Smag.Framework.Common.Extensions;
using Smag.Framework.Common.Logs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.Hosting;



namespace Smag.Framework.Configuration
{



    /// <summary>
    /// Stocke toute la configuration.
    /// </summary>
    public abstract class Config : IDisposable
    {

        #region Variables statiques

        /// <summary>
        /// Convertisseurs JSON.
        /// </summary>
        private static JsonConverter[] s_converters;

        #endregion

        #region Constructeurs

        /// <summary>
        /// Constructeur statique.
        /// </summary>
        static Config()
        {
            s_converters = new JsonConverter[]
            {
                new JsonConverters.UriConverter(),
                new JsonConverters.VersionConverter()
            };
        }

        /// <summary>
        /// Constructeur.
        /// </summary>
        protected Config()
        {
            APIs = new Dictionary<JarvisApp, Uri>();
            ConnectionStrings = new SortedDictionary<Database, string>();
            OAuth = new Dictionary<JarvisApp, OAuthClient>();
            WebServices = new List<WebService>();
            Config.Instance = this;
        }

        /// <summary>
        /// Appelé lorsque l'instance actuelle va être libérée du GC.
        /// </summary>
        public void Dispose()
        {
            if (Config.Instance == this)
                Config.Instance = null;
        }

        #endregion

        #region Propriétés statiques

        /// <summary>
        /// Obtient l'instance de la configuration.
        /// </summary>
        public static Config Instance { get; protected set; }

        #endregion

        #region Propriétés

        /// <summary>
        /// Adresse (URL) de chaque application Jarvis.
        /// </summary>
        [JsonIgnore]
        public IDictionary<JarvisApp, Uri> APIs { get; private set; }

        /// <summary>
        /// Adresse (URL) de chaque application Jarvis.
        /// </summary>
        [JsonProperty("APIs")]
        internal IDictionary<string, string> APIs_
        {
            get
            {
                if (APIs.Count < 1)
                    return null;
                SortedDictionary<string, string> urls = new SortedDictionary<string, string>();
                foreach (var u in APIs)
                    urls.Add(u.Key.GetCode(), u.Value.AbsoluteUri);
                return urls;
            }
            set
            {
                APIs.Clear();
                if (value != null)
                {
                    foreach (var a in value)
                    {
                        JarvisApp? app = EnumExtensions.FromCode<JarvisApp>(a.Key);
                        if (!app.HasValue)
                        {
                            Log.Error("Unknown Jarvis application '{0}'.", a.Key ?? "");
                            continue;
                        }
                        Uri url;
                        if (!Uri.TryCreate(a.Value, UriKind.Absolute, out url))
                        {
                            Log.Error("Invalid absolute URL '{0}'.", a.Value ?? "");
                            continue;
                        }
                        APIs.Add(app.Value, url);
                    }
                }
            }
        }

        /// <summary>
        /// Chaînes de connexion aux bases de données.
        /// </summary>
        public SortedDictionary<Database, string> ConnectionStrings
        {
            get;
            private set;
        }

        /// <summary>
        /// Chemin physique du répertoire contenant toutes les images.
        /// </summary>
        public string ImagesPath { get; set; }

        /// <summary>
        /// Adresse (URL) de base des images.
        /// </summary>
        public string ImagesUrl { get; set; }

        /// <summary>
        /// Configuration de l'authentification des applications Jarvis.
        /// </summary>
        [JsonIgnore]
        public IDictionary<JarvisApp, OAuthClient> OAuth { get; private set; }

        /// <summary>
        /// Configuration de l'authentification des applications Jarvis.
        /// </summary>
        [JsonProperty("OAuth")]
        internal IDictionary<string, OAuthClient> OAuth_
        {
            get
            {
                if (OAuth.Count < 1)
                    return null;
                SortedDictionary<string, OAuthClient> authentifiedClients = new SortedDictionary<string, OAuthClient>();
                foreach (var oac in OAuth)
                    authentifiedClients.Add(oac.Key.GetCode(), oac.Value);
                return authentifiedClients;
            }
            set
            {
                OAuth.Clear();
                if (value != null)
                {
                    foreach (var oac in value)
                    {
                        JarvisApp? app = EnumExtensions.FromCode<JarvisApp>(oac.Key);
                        if (app.HasValue)
                            OAuth.Add(app.Value, oac.Value);
                        else
                            Log.Error("Unknown Jarvis application '{0}'.", oac.Key ?? "");
                    }
                }
            }
        }

        /// <summary>
        /// Services Web.
        /// </summary>
        public List<WebService> WebServices
        {
            get;
            private set;
        }

        #endregion

        #region Méthodes statiques

        /// <summary>
        /// Retourne le chemin complet du fichier/répertoire indiqué.
        /// </summary>
        /// <param name="path">Chemin relatif du fichier/répertoire.</param>
        /// <param name="directory"><value>true</value> si <paramref name="path"/> est un chemin de répertoire, <value>false</value> s'il s'agit d'un chemin de fichier.</param>
        /// <returns>Chemin complet du fichier/répertoire.</returns>
        protected static string GetFullPath(string path, bool directory)
        {
            if (string.IsNullOrWhiteSpace(path))
                return null;
            if (!Path.IsPathRooted(path))
            {
                if (!string.IsNullOrEmpty(HostingEnvironment.ApplicationPhysicalPath))
                    path = Path.Combine(HostingEnvironment.ApplicationPhysicalPath, path);
                if (!Path.IsPathRooted(path))
                {
                    string serverRoot = GetRootDirectory();
                    if (!string.IsNullOrEmpty(serverRoot))
                        path = Path.Combine(serverRoot, path);
                }
            }
            path = Path.GetFullPath(path);
            if (directory && !path.IsEndingWithPathSeparator())
                path += "\\";
            return path.Replace("/", "\\");
        }

        /// <summary>
        /// Obtient le chemin du répertoire où se trouve l'exécutable.
        /// </summary>
        /// <returns>Répertoire de l'exécutable.</returns>
        protected static string GetRootDirectory()
        {
            // Utilise le chemin du serveur HTTP.
            try
            {
                string root = HttpContext.Current?.Server?.MapPath("~");
                if (!string.IsNullOrEmpty(root))
                    return root;
            }
            catch
            {
                Log.Error("An error occured when trying to retrieve the root directory");
            }

            // Utilise le chemin de l'assembly appelante.
            try
            {
                Assembly a = Assembly.GetEntryAssembly();
                if (a != null && !string.IsNullOrEmpty(a.Location))
                {
                    string root = Path.GetDirectoryName(a.Location);
                    if (!string.IsNullOrEmpty(root))
                        return root;
                }
            }
            catch {
                Log.Error("An error occured when trying to retrieve the recursive root directory.");
            }

            // Échec.
            return null;
        }

        /// <summary>
        /// Extrait la configuration stockée dans le fichier indiqué.
        /// </summary>
        /// <param name="configFilePath">Chemin du fichier de configuration.</param>
        /// <returns>La configuration stockée dans le fichier.</returns>
        protected static C Load<C>(string configFilePath)
            where C : Config
        {
            try
            {
                // Vérifie que le chemin du fichier de configuration est valide.
                if (string.IsNullOrEmpty(configFilePath))
                    throw new ArgumentException("Le chemin du fichier de configuration doit être indiqué.", "configFilePath");
                string configFileFullPath = GetFullPath(configFilePath, false);
                if (!File.Exists(configFileFullPath))
                    throw new Exception(string.Format("Le fichier de configuration \"{0}\" n'existe pas.", configFileFullPath));

                // Lit le fichier.
                string jsonData = File.ReadAllText(configFileFullPath, Encoding.UTF8);
                if (string.IsNullOrEmpty(jsonData))
                    throw new Exception(string.Format("Le fichier de configuration \"{0}\" est pas vide.", configFileFullPath));

                // Désérialise le fichier.
                C config = JsonConvert.DeserializeObject<C>(jsonData, s_converters);
                if (config == null)
                    throw new Exception(string.Format("Le fichier de configuration \"{0}\" n'est pas valide.", configFileFullPath));

                // Restaure les liens entre les services Web et leurs méthodes.
                foreach (var ws in config.WebServices)
                    foreach (var m in ws.WebMethods)
                        m.WebService = ws;

                // Succès.
                return config;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Échec lors de la lecture du fichier de configuration \"{0}\" : {1}", configFilePath ?? "NULL", ex.GetExtendedMessage()));
            }
        }

        #endregion

        #region Méthodes

        /// <summary>
        /// Référence l'URL d'une API Jarvis.
        /// </summary>
        /// <param name="app">Application Jarvis.</param>
        /// <param name="url">Adresse complète de l'application.</param>
        /// <returns>Adresse ajoutée.</returns>
        public Uri AddApiUrl(JarvisApp app, string url)
        {
            if (string.IsNullOrWhiteSpace(url))
                throw new ArgumentNullException("url");
            Uri uri;
            if (!Uri.TryCreate(url, UriKind.Absolute, out uri))
                throw new ArgumentException(string.Format("Invalid absolute URL '{0}'.", url ?? ""), "url");
            APIs.AddOrSet(app, uri);
            return uri;
        }


        /// <summary>
        /// Ajoute un service Web.
        /// </summary>
        /// <param name="name">Nom du service Web.</param>
        /// <param name="url">Adresse de base du service Web.</param>
        /// <returns>Service Web créé.</returns>
        public WebService AddWebService(string name, string url)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentException("Le nom du service Web doit être indiqué.", "name");

            // Recherche si le service Web est déjà référencé.
            WebService webService = GetWebService(name);
            if (webService != null)
                return webService;

            // Ajoute un nouveau service Web.
            webService = new WebService(name, url);
            WebServices.Add(webService);
            return webService;
        }

        /// <summary>
        /// Obtient l'adresse complète d'une application Jarvis <paramref name="app"/> ou d'une de ses méthodes Web <paramref name="webMethod"/>.
        /// </summary>
        /// <param name="app">Application Jarvis.</param>
        /// <param name="webMethod">[optionnel] Adresse relative de la méthode Web.</param>
        /// <returns>Adresse complète de l'application Jarvis <paramref name="app"/> ou de sa méthode Web <paramref name="webMethod"/>.</returns>
        public Uri GetApiUri(JarvisApp app, string webMethod = null)
        {
            Uri baseUrl;
            if (!APIs.TryGetValue(app, out baseUrl))
                return null;
            if (string.IsNullOrWhiteSpace(webMethod))
                return baseUrl;
            return new Uri(baseUrl, webMethod.Trim());
        }

        /// <summary>
        /// Obtient l'adresse complète d'une application Jarvis <paramref name="app"/> ou d'une de ses méthodes Web <paramref name="webMethod"/>.
        /// </summary>
        /// <param name="app">Application Jarvis.</param>
        /// <param name="webMethod">[optionnel] Adresse relative de la méthode Web.</param>
        /// <returns>Adresse complète de l'application Jarvis <paramref name="app"/> ou de sa méthode Web <paramref name="webMethod"/>.</returns>
        public string GetApiUrl(JarvisApp app, string webMethod = null)
        {
            Uri baseUrl;
            if (!APIs.TryGetValue(app, out baseUrl))
                return null;
            if (string.IsNullOrWhiteSpace(webMethod))
                return baseUrl.AbsoluteUri;
            return new Uri(baseUrl, webMethod.Trim()).AbsoluteUri;
        }

        /// <summary>
        /// Recherche un service Web.
        /// </summary>
        /// <param name="name">Nom du service Web à rechercher.</param>
        /// <param name="ignoreCase">Indique si la rechercher est sensible à la casse.</param>
        /// <returns>Service Web correspondant au nom indiqué, ou <value>null</value> s'il est introuvable.</returns>
        public WebService GetWebService(string name, bool ignoreCase = false)
        {
            if (string.IsNullOrEmpty(name))
                return null;
            return WebServices.SingleOrDefault(ws => string.Compare(ws.Name, name, ignoreCase) == 0);
        }

        /// <summary>
        /// Sauvegarde la configuration actuelle dans un fichier.
        /// </summary>
        /// <param name="configFilePath">Chemin du fichier de configuration.</param>
        public void Save(string configFilePath)
        {
            try
            {
                if (string.IsNullOrEmpty(configFilePath))
                    throw new ArgumentException("Le chemin du fichier de configuration n'est pas valide.", "configFilePath");
                string jsonData = JsonConvert.SerializeObject(this, Formatting.Indented, s_converters);
                string configFileFullPath = GetFullPath(configFilePath, false);
                string configDirectory = Path.GetDirectoryName(configFileFullPath);
                if (!string.IsNullOrEmpty(configDirectory) && !Directory.Exists(configDirectory))
                    Directory.CreateDirectory(configDirectory);
                File.WriteAllText(configFileFullPath, jsonData, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Échec lors de la sauvegarde du fichier de configuration \"{0}\" : {1}", configFilePath ?? "NULL", ex.GetExtendedMessage()));
            }
        }

        /// <summary>
        /// Détermine si JSON peut sérialiser les adresses (URL) de chaque application Jarvis.
        /// </summary>
        /// <returns><value>true</value> si <see cref="APIs_"/> peut être sérialisé, <value>false</value> sinon.</returns>
        public bool ShouldSerializeAPIs_()
        {
            return (APIs.Count > 0);
        }

        /// <summary>
        /// Détermine si JSON peut sérialiser la liste des connexions.
        /// </summary>
        /// <returns><value>true</value> si <see cref="ConnectionStrings"/> peut être sérialisée, <value>false</value> sinon.</returns>
        public bool ShouldSerializeConnectionStrings()
        {
            return (ConnectionStrings.Count > 0);
        }

        /// <summary>
        /// Détermine si JSON peut sérialiser le chemin physique du répertoire contenant toutes les images.
        /// </summary>
        /// <returns><value>true</value> si <see cref="ImagesPath"/> peut être sérialisé, <value>false</value> sinon.</returns>
        public bool ShouldSerializeImagesPath()
        {
            if (string.IsNullOrWhiteSpace(ImagesPath))
                return false;
            ImagesPath = ImagesPath.Replace("\\", "/");
            return true;
        }

        /// <summary>
        /// Détermine si JSON peut sérialiser l'adresse (URL) de base des images.
        /// </summary>
        /// <returns><value>true</value> si <see cref="ImagesUrl"/> peut être sérialisé, <value>false</value> sinon.</returns>
        public bool ShouldSerializeImagesUrl()
        {
            return !string.IsNullOrWhiteSpace(ImagesUrl);
        }

        /// <summary>
        /// Détermine si JSON peut sérialiser la configuration de l'authentification des applications Jarvis.
        /// </summary>
        /// <returns><value>true</value> si <see cref="OAuth_"/> peut être sérialisé, <value>false</value> sinon.</returns>
        public bool ShouldSerializeOAuth_()
        {
            return (OAuth.Count > 0);
        }

        /// <summary>
        /// Détermine si JSON peut sérialiser la liste des services Web.
        /// </summary>
        /// <returns><value>true</value> si <see cref="WebServices"/> peut être sérialisée, <value>false</value> sinon.</returns>
        public bool ShouldSerializeWebServices()
        {
            return (WebServices.Count > 0);
        }

        #endregion

    }   // public class Config



}   // namespace Smag.Framework.Configuration
