﻿using Microsoft.Practices.Unity.Configuration;
using Smag.Framework.Common.Extensions;
using Smag.Framework.Common.Logs;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml;
using Unity;

namespace Smag.Framework.Configuration
{



    /// <summary>
    /// Permet de contrôler le chargement des modules utilisant Unity.
    /// </summary>
    public abstract class Unity
    {

        #region Variables membres

        /// <summary>
        /// Pour chaque section Unity connue, indique la liste des assemblies qui y font références.
        /// </summary>
        private IDictionary<string, IList<string>> m_knownSections;

        #endregion

        #region Méthodes privées

        /// <summary>
        /// Obtient la liste des assemblies référencées soit directement par l'assembly <paramref name="assembly"/>, soit par ses enfants.
        /// </summary>
        /// <param name="assembly">Assembly.</param>
        /// <returns>Liste des assemblies référencées soit directement par l'assembly, soit par ses enfants.</returns>
        private List<string> GetReferencedAssemblies(Assembly assembly, ref List<string> errors)
        {
            // Obtient la liste des assemblies directement référencées par l'assembly.
            Func<AssemblyName, bool> IsSmag = a =>
            {
                return a.Name.StartsWith("Smag", StringComparison.InvariantCultureIgnoreCase);
            };
            List<AssemblyName> assembliesToLookup = assembly.GetReferencedAssemblies().Where(a => IsSmag(a)).ToList();

            // Les assemblies, qui ne sont pas encore utilisées, ne sont pas renvoyées par 'GetReferencedAssemblies()'.
            // On détermine si on peut les charger.
            IEnumerable<string> knownAssemblies = KnownSections.SelectMany(s => s.Value).Distinct();
            foreach (string knownAssembly in knownAssemblies)
            {
                if (assembliesToLookup.Exists(an => (string.Compare(an.Name, knownAssembly, true) == 0)))
                    continue;
                try
                {
                    Assembly a = Assembly.Load(knownAssembly);
                    if (a != null)
                        assembliesToLookup.Add(a.GetName());
                }
                catch
                {
                }
            }

            // Obtient la liste des assemblies référencées par ces assemblies.
            List<string> referencedAssemblies = new List<string>();
            List<string> loadingErrors = new List<string>();
            while (assembliesToLookup.Count > 0)
            {
                try
                {
                    // Ajoute l'assembly actuelle à la liste.
                    AssemblyName loadedAssemblyName = assembliesToLookup.First();
                    referencedAssemblies.Add(loadedAssemblyName.Name);
                    assembliesToLookup.RemoveAt(0);

                    // Charge l'assembly.
                    Assembly loadedAssembly = Assembly.Load(loadedAssemblyName);

                    // Ajoute les sous-assemblies qui ne sont pas déjà référencées.
                    var subAssemblies = loadedAssembly.GetReferencedAssemblies().Where(a => IsSmag(a));
                    foreach (var a in subAssemblies)
                    {
                        if (!referencedAssemblies.Contains(a.Name) && !assembliesToLookup.Contains(a))
                            assembliesToLookup.Add(a);
                    }
                }
                catch (Exception ex)
                {
                    loadingErrors.Add(ex.GetExtendedMessage());
                }
            }

            // Retourne le résultat.
            if (loadingErrors.Count > 0)
                errors.Add(string.Format("Failed to get the referenced assemblies :\n\t{0}", string.Join("\n\t", loadingErrors)));
            referencedAssemblies.Sort();
            return referencedAssemblies.Distinct().ToList();
        }

        /// <summary>
        /// Recherche les sections Unity qui doivent être définies dans le fichier de configuration.
        /// </summary>
        /// <param name="assemblyName">Nom de l'assembly référencées par l'assembly actuelle.</param>
        /// <returns>Liste des sections Unity à définir.</returns>
        private List<string> GetSectionsToDefine(string assemblyName)
        {
            List<string> sections = new List<string>();
            if (!string.IsNullOrEmpty(assemblyName))
            {
                foreach (var section in KnownSections)
                {
                    foreach (string knownSectionAssemblyName in section.Value)
                    {
                        if (string.Compare(assemblyName, knownSectionAssemblyName, true) == 0)
                        {
                            sections.Add(section.Key);
                            break;
                        }
                    }
                }
            }
            return sections;
        }

        #endregion

        #region Méthodes protégées

        /// <summary>
        /// Indique que l'assembly <paramref name="assemblyName"/> référence (contient le fichier de configuration ou utilise) la section Unity <paramref name="sectionName"/>.
        /// </summary>
        /// <param name="assemblyName">Nom de l'assembly.</param>
        /// <param name="sectionName">Nom de la section Unity.</param>
        protected void AddKnownSection(string sectionName, params string[] assemblyNames)
        {
            IList<string> assemblies;
            if (m_knownSections.TryGetValue(sectionName, out assemblies))
            {
                // Met éventuellement à jour la liste des assemblies de cette section.
                foreach (string assemblyName in assemblyNames)
                {
                    if (!assemblies.Contains(assemblyName))
                    {
                        assemblies.Add(assemblyName);
                        m_knownSections[sectionName] = assemblies;
                    }
                }
            }
            else
            {
                // Ajoute une nouvelle section.
                m_knownSections.Add(sectionName, new List<string>(assemblyNames.Distinct()));
            }
        }

        /// <summary>
        /// Initialize la liste des sections connues.
        /// </summary>
        protected abstract void InitializeKnownSections();

        /// <summary>
        /// Détermine si la section indiquée est connue.
        /// </summary>
        /// <param name="sectionName">Nom de la section Unity.</param>
        /// <returns><value>true</value> si la section Unity est connue, <value>false</value> sinon.</returns>
        protected bool IsKnownSection(string sectionName)
        {
            if (string.IsNullOrEmpty(sectionName))
                return false;
            foreach (var knownSectionName in KnownSections.Keys)
            {
                if (string.Compare(knownSectionName, sectionName, true) == 0)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Détermine si la section indiquée est connue.
        /// </summary>
        /// <param name="sectionName">Nom de la section Unity.</param>
        /// <returns><value>true</value> si la section Unity est connue, <value>false</value> sinon.</returns>
        protected bool IsKnownSection(string sectionName, out IList<string> assembliesToReference)
        {
            if (string.IsNullOrEmpty(sectionName))
            {
                assembliesToReference = new List<string>();
                return false;
            }
            foreach (var knownSectionName in KnownSections.Keys)
            {
                if (string.Compare(knownSectionName, sectionName, true) == 0)
                {
                    assembliesToReference = KnownSections[knownSectionName];
                    return true;
                }
            }
            assembliesToReference = new List<string>();
            return false;
        }

        #endregion

        #region Méthodes publiques

        /// <summary>
        /// Détermine si la configuration Unity est valide.
        /// </summary>
        /// <param name="assembly">Assembly appelante, dans laquelle on souhaite utiliser des modules chargés via Unity.</param>
        public void CheckConfiguration(Assembly assembly = null)
        {
            List<string> errors = new List<string>();
            string configFilePath = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile.TrimmedOrNull();
            try
            {
                // Charge le fichier de configuration.
                if (assembly == null)
                    assembly = Assembly.GetCallingAssembly();
                if (!File.Exists(configFilePath))
                    throw new ConfigurationErrorsException(string.Format("Failed to load the configuration file \"{0}\".", configFilePath ?? ""));
                XmlDocument config = new XmlDocument();
                config.Load(configFilePath);

                // Liste les sections Unity définies dans le fichier de configuration.
                var sectionsDefinedInConfigFile = new Dictionary<string, string>();
                foreach (XmlNode xmlSection in config.DocumentElement.SelectNodes("/configuration/configSections/section"))
                {
                    string type = xmlSection.Attributes["type"]?.Value;
                    if (string.IsNullOrEmpty(type) || !type.Contains("UnityConfigurationSection"))
                        continue;
                    string sectionName = xmlSection.Attributes["name"]?.Value;
                    if (string.IsNullOrEmpty(sectionName))
                        continue;
                    XmlNode section = config.DocumentElement.SelectSingleNode(string.Format("/configuration/{0}", sectionName));
                    string configSource = section?.Attributes["configSource"]?.Value;
                    if (string.IsNullOrEmpty(configSource))
                        errors.Add(string.Format("The section \"{0}\" is defined in the \"configuration/configSections\" but is not defined afterward.", sectionName));
                    sectionsDefinedInConfigFile.Add(sectionName, configSource);
                }
                var sectionsNamesDefinedInConfigFile = sectionsDefinedInConfigFile.Keys.Select(n => n.ToLower()).ToList();

                // Détermine si certaines sections sont inutiles et si le fichier de configuration qu'elles définissent est bien accessible.
                List<string> referencedAssemblies = GetReferencedAssemblies(assembly, ref errors);
                foreach (var configSection in sectionsDefinedInConfigFile)
                {
                    // Détermine si la section est connue.
                    IList<string> assembliesToReference;
                    if (!IsKnownSection(configSection.Key, out assembliesToReference))
                    {
                        errors.Add(string.Format("REMOVE the section \"{0}\" : it will be never used.", configSection.Key));
                        continue;
                    }

                    // Détermine s'il manque une assembly à référencer.
                    foreach (string assemblyToReference in assembliesToReference)
                    {
                        if (!referencedAssemblies.Contains(assemblyToReference))
                            errors.Add(string.Format("ADD a reference to the project \"{0}\", as you are defining the section \"{1}\".", assemblyToReference, configSection.Key));
                    }

                    // Détermine si le fichier de configuration Unity existe.
                    if (string.IsNullOrEmpty(configSection.Value))
                    {
                        errors.Add(string.Format("The section \"{0}\" does not define any configuration file.", configSection.Key));
                        continue;
                    }
                    string unityConfigFilePath = Path.Combine(Path.GetDirectoryName(configFilePath), configSection.Value);
                    if (!File.Exists(unityConfigFilePath))
                    {
                        errors.Add(string.Format("The section \"{0}\" defines a configuration file \"{1}\" which has not been deployed.", configSection.Key, configSection.Value));
                        continue;
                    }
                }

                // A partir de la liste des assemblies référencées, détermine s'il n'y a pas de sections manquantes.
                foreach (var referencedAssembly in referencedAssemblies)
                {
                    foreach (string section in GetSectionsToDefine(referencedAssembly))
                    {
                        // La section est-elle bien définie dans le fichier de configuration ?
                        if (!sectionsNamesDefinedInConfigFile.Contains(section.ToLower()))
                            errors.Add(string.Format("ADD the section \"{0}\", as you are referecing the assembly \"{1}\".", section, referencedAssembly));

                        // Essaie de charger la section.
                        try
                        {
                            LoadFromConfigurationSection(section);
                        }
                        catch (Exception ex)
                        {
                            errors.Add(ex.GetExtendedMessage());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                errors.Add(ex.GetExtendedMessage());
            }

            // Génère une exception en cas d'erreur.
            errors = errors.Distinct().ToList();
            if (errors.Count > 0)
            {
                errors.Sort();
                string message = string.Format("{0} :\n\t{1}", configFilePath, string.Join("\n\t", errors));
                Log.Fatal(message);
                throw new ConfigurationErrorsException(message);
            }
        }

        /// <summary>
        /// Charge un conteneur Unity à partir d'une section définie dans le fichier App/Web.config.
        /// </summary>
        /// <param name="sectionName">Nom de la section.</param>
        /// <returns>Conteneur Unity.</returns>
        public static UnityContainer LoadFromConfigurationSection(string sectionName)
        {
            if (string.IsNullOrEmpty(sectionName))
                return null;

            // Charge la section à partir du fichier App/Web.config.
            UnityConfigurationSection configurationSection = null;
            try
            {
                configurationSection = ConfigurationManager.GetSection(sectionName) as UnityConfigurationSection;
                if (configurationSection == null)
                    throw new Exception(string.Format("The section \"{0}\" could not be converted into a \"UnityConfigurationSection\".", sectionName ?? ""));
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Failed to load the section \"{0}\" : {1}", sectionName, ex.GetExtendedMessage()));
            }

            // Crée le conteneur.
            try
            {
                UnityContainer container = new UnityContainer();
                IUnityContainer loadedContainer = container.LoadConfiguration(configurationSection);
                if (loadedContainer == null)
                    throw new Exception("Loading failure.");
                return container;
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Failed to load the Unity container for the section \"{0}\" : {1}", sectionName, ex.GetExtendedMessage()));
            }
        }

        #endregion

        #region Propriétés

        /// <summary>
        /// Liste des sections connues.
        /// </summary>
        protected IDictionary<string, IList<string>> KnownSections
        {
            get
            {
                if (m_knownSections == null)
                {
                    m_knownSections = new Dictionary<string, IList<string>>();
                    InitializeKnownSections();
                }
                return m_knownSections;
            }
        }

        #endregion

    }



}
