﻿using Newtonsoft.Json;
using System;



namespace Smag.Framework.Configuration
{



    /// <summary>
    /// Une méthode Web.
    /// </summary>
    public class WebMethod
    {

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut, utilisé à la désérialisation.
        /// </summary>
        internal WebMethod()
        {
            Name = null;
            Url = null;
            WebService = null;
        }

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="name">Nom de la méthode Web.</param>
        /// <param name="url">Adresse.</param>
        /// <param name="webService">Service Web parent.</param>
        internal WebMethod(string name, string url, WebService webService)
        {
            Name = name;
            Url = url;
            WebService = webService;
        }

        #endregion

        #region Propriétés publiques

        /// <summary>
        /// Adresse complète de la méthode Web actuelle.
        /// </summary>
        [JsonIgnore]
        public Uri FullUrl
        {
            get
            {
                if (string.IsNullOrEmpty(Url))
                    return null;
                string webServiceUrl = WebService?.Url;
                if (string.IsNullOrEmpty(webServiceUrl))
                    return new Uri(Url);
                else
                    return new Uri(new Uri(webServiceUrl), Url);
            }
        }

        /// <summary>
        /// Nom de la méthode Web.
        /// </summary>
        public string Name
        {
            get;
            set;
        }

        /// <summary>
        /// Adresse de la méthode Web.
        /// </summary>
        public string Url
        {
            get;
            set;
        }

        /// <summary>
        /// Service Web.
        /// </summary>
        [JsonIgnore]
        public WebService WebService
        {
            get;
            internal set;
        }

        #endregion

    }   // public class WebMethod



}   // namespace Smag.Framework.Configuration
