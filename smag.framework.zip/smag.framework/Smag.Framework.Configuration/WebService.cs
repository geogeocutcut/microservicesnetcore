﻿using System;
using System.Collections.Generic;
using System.Linq;



namespace Smag.Framework.Configuration
{



    /// <summary>
    /// Un service Web.
    /// </summary>
    public class WebService
    {

        #region Constructeurs

        /// <summary>
        /// Constructeur par défaut, utilisé à la désérialisation.
        /// </summary>
        internal WebService()
        {
            Name = null;
            Url = null;
            WebMethods = new List<WebMethod>();
        }

        /// <summary>
        /// Constructeur.
        /// </summary>
        /// <param name="name">Nom du service Web.</param>
        /// <param name="url">Adresse de base.</param>
        internal WebService(string name, string url)
        {
            Name = name;
            Url = url;
            WebMethods = new List<WebMethod>();
        }

        #endregion

        #region Propriétés publiques

        /// <summary>
        /// Nom du service Web.
        /// </summary>
        public string Name
        {
            get;
            set;
        }

        /// <summary>
        /// Adresse de base du service Web.
        /// </summary>
        public string Url
        {
            get;
            set;
        }

        /// <summary>
        /// Méthodes Web.
        /// </summary>
        public List<WebMethod> WebMethods
        {
            get;
            private set;
        }

        #endregion

        #region Méthodes publiques

        /// <summary>
        /// Ajoute une méthode Web.
        /// </summary>
        /// <param name="name">Nom de la méthode Web.</param>
        /// <param name="url">Adresse relative de la méthode Web.</param>
        /// <returns>La méthode Web créée.</returns>
        public WebMethod AddWebMethod(string name, string url)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentException("Le nom de la méthode Web doit être indiqué.", "name");

            // Recherche si la méthode Web est déjà référencée.
            WebMethod webMethod = GetWebMethod(name);
            if (webMethod != null)
                return webMethod;

            // Ajoute une nouvelle méthode Web.
            webMethod = new WebMethod(name, url, this);
            WebMethods.Add(webMethod);
            return webMethod;
        }

        /// <summary>
        /// Recherche une méthode Web.
        /// </summary>
        /// <param name="name">Nom de la méthode Web à rechercher.</param>
        /// <param name="ignoreCase">Indique si la rechercher est sensible à la casse.</param>
        /// <returns>Méthode Web correspondant au nom indiqué, ou <value>null</value> si elle est introuvable.</returns>
        public WebMethod GetWebMethod(string name, bool ignoreCase = false)
        {
            if (string.IsNullOrEmpty(name))
                return null;
            return WebMethods.SingleOrDefault(wm => string.Compare(wm.Name, name, ignoreCase) == 0);
        }

        /// <summary>
        /// Détermine si JSON peut sérialiser la liste des méthodes Web.
        /// </summary>
        /// <returns><value>true</value> si <see cref="WebMethods"/> peut être sérialisée, <value>false</value> sinon.</returns>
        public bool ShouldSerializeWebMethods()
        {
            return (WebMethods.Count > 0);
        }

        #endregion

    }   // public class WebService



}   // namespace Smag.Framework.Configuration
