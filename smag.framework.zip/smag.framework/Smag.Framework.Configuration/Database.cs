﻿namespace Smag.Framework.Configuration
{



    /// <summary>
    /// Base de données.
    /// </summary>
    public enum Database
    {

        /// <summary>
        /// Base de données d'Agreo.
        /// </summary>
        Agreo,

        /// <summary>
        /// Base de données d'Atland.
        /// </summary>
        Atland,

        /// <summary>
        /// Base de données d'exploitation.
        /// </summary>
        Exploitation,

        /// <summary>
        /// Base de données de IoTA.
        /// </summary>
        IoTA,

        /// <summary>
        /// Base de données de JarvisAuthenticate.
        /// </summary>
        JarvisAuthenticate,

        /// <summary>
        /// Base de données pour le monitoring.
        /// </summary>
        Monitoring

    }   // public enum Database



}   // namespace Smag.Framework.Configuration
