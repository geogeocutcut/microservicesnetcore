﻿using Newtonsoft.Json;
using System;



namespace Smag.Framework.Configuration.JsonConverters
{



    /// <summary>
    /// Sérialise et désérialise un objet System.Version en chaîne JSON.
    /// </summary>
    public class VersionConverter : JsonConverter
    {

        public override bool CanConvert(Type objectType)
        {
            return objectType == typeof(Version);
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            string version = serializer.Deserialize<string>(reader);
            if (!string.IsNullOrEmpty(version))
                return Version.Parse(version);
            return (Version)null;
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            Version version = value as Version;
            serializer.Serialize(writer, version?.ToString());
        }

    }   // public class VersionConverter



}   // namespace Smag.Framework.Configuration.JsonConverters
