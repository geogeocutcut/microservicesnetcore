﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Smag.Framework.Configuration.JsonConverters
{



    /// <summary>
    /// Sérialise et désérialise une URL en chaîne JSON.
    /// </summary>
    public class UriConverter : JsonConverter
    {

        public override bool CanConvert(Type objectType)
        {
            return objectType == typeof(Uri);
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            string url = serializer.Deserialize<string>(reader);
            if (!string.IsNullOrEmpty(url))
                return new Uri(url);
            return (Uri)null;
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            Uri url = value as Uri;
            serializer.Serialize(writer, url?.AbsoluteUri);
        }

    }   // public class UriConverter



}   // namespace Smag.Framework.Configuration.JsonConverters
