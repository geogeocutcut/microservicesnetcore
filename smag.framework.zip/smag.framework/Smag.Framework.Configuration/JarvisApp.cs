﻿using Smag.Framework.Common.Attributes;



namespace Smag.Framework.Configuration
{



  public enum JarvisApp
  {

    /// <summary>
    /// Redirection vers Agricaster. (Smag.IoTA.Partner.Agricaster)
    /// </summary>
    [Code("agricaster")]
    Agricaster,

    /// <summary>
    /// Web API d'authentification. (Smag.Authentication.WebApi.Owin)
    /// </summary>
    [Code("auth")]
    Authentication,

    /// <summary>
    /// Web API appelée par les partenaires IoTA pour envoyer les données des capteurs. (Smag.IOTA.WebApi.External)
    /// </summary>
    [Code("extern")]
    External,

    /// <summary>
    /// Web API appelée par Weathernews pour envoyer les prévisions météo. (Smag.IoTA.ForecastApi)
    /// </summary>
    [Code("forecast")]
    Forecast,

    /// <summary>
    /// Web API de l'application "IoTA Alliance". (Smag.IOTA.Partner.WebApi)
    /// </summary>
    [Code("partner-api")]
    IotaPartnerWebApi,

    /// <summary>
    /// Site Web de l'application "IoTA Alliance". (Smag.IoTA.Partner.WebApp)
    /// </summary>
    [Code("partner-site")]
    IotaPartnerWebSite,

    /// <summary>
    /// Web API de l'application "IoTA". (Smag.IOTA.WebApi)
    /// </summary>
    [Code("iota-api")]
    IotaWebApi,

    /// <summary>
    /// Site Web de l'application "IoTA". (Smag.Mobile.IOTA.WebApp)
    /// </summary>
    [Code("iota-site")]
    IotaWebSite,

    /// <summary>
    /// Logging API. (Smag.Jarvis.Logging.WebApi)
    /// </summary>
    [Code("logging-api")]
    LoggingApi,

    /// <summary>
    /// Monitoring API (Smag.Jarvis.Monitoring.WebApi)
    /// </summary>
    [Code("monitoring-api")]
    MonitoringWebApi,

    /// <summary>
    /// Site du Monitoring. (Smag.Jarvis.Monitoring.WebApp)
    /// </summary>
    [Code("monitoring-site")]
    MonitoringWebSite,

    /// <summary>
    /// Web API du partenaire SMAG
    /// </summary>
    [Code("partner-smag")]
    PartnerSmagApi,

    /// <summary>
    /// Web API de l'application "Weather OAD". (Smag.Weather.OAD.WebApi)
    /// </summary>
    [Code("weather-oad-api")]
    WeatherOadWebApi,

    /// <summary>
    /// Site Web de l'application "Weather OAD". (Smag.Weather.OAD.WebApp)
    /// </summary>
    [Code("weather-oad-site")]
    WeatherOadWebSite

  }


}
