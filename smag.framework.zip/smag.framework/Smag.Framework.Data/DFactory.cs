﻿using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;
using Smag.Framework.Authentication;
using Smag.Framework.DAL;
using System;
using System.Configuration;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using Unity;
using Unity.Resolution;

namespace Smag.Framework.Data
{
    public static class DFactory
    {
        private const string SmagName = "SMAG";
        private const string DalFactoryConfigSection = "unityDALFactory";
        private const string ServiceConfigSection = "unityDServiceFactory";

        private static readonly IUnityContainer Container;
        private static readonly object LockObj = new object();

        /// <summary>
        /// prepare and init a singleton container at the very beginning
        /// </summary>
        static DFactory()
        {
            if (Container == null)
            {
                lock (LockObj)
                {
                    if (Container == null)
                    {
                        Container = new UnityContainer()
                            .LoadConfiguration((UnityConfigurationSection)ConfigurationManager.GetSection(DalFactoryConfigSection))
                            .LoadConfiguration((UnityConfigurationSection)ConfigurationManager.GetSection(ServiceConfigSection));
                    }
                }
            }
        }

        public static IUnitOfWork GetUnitOfWork(AuthenticationContext authCtxt = null,bool InMemory = false)
        {
            if (authCtxt == null)
                return Container.Resolve<IUnitOfWork>();

            string resolveInjectionName = null;
            var dependencyOverrides = new DependencyOverrides();

            //by default, if no identity is given, we will get the default SMAG unit of work
            if (authCtxt.Identity == null)
            {
                resolveInjectionName = SmagName;
                dependencyOverrides.Add(typeof(AuthenticationContext), authCtxt);
            }
            else if (Container.IsRegistered<IUnitOfWork>(authCtxt.Identity.application_type))
            {
                resolveInjectionName = authCtxt.Identity.application_type;
                dependencyOverrides.Add(typeof(AuthenticationContext), authCtxt);
            }
            else if (Container.IsRegistered<IUnitOfWork>(SmagName))
            {
                resolveInjectionName = SmagName;
            }

            IUnitOfWork _unitOfWork = Container.Resolve<IUnitOfWork>(resolveInjectionName, dependencyOverrides);
            _unitOfWork.InMemory = InMemory;
            return _unitOfWork;
        }

        public static TUnitOfWork GetUnitOfWork<TUnitOfWork>() => Container.Resolve<TUnitOfWork>();

        public static IDServiceProvider GetServicesProvider() => Container.Resolve<IDServiceProvider>();

        public static IService GetService<IService>(IIdentity identity)
        {
            var claimsIdentity = identity as ClaimsIdentity;

            var authCtxt = new AuthenticationContext(claimsIdentity);

            return GetService<IService>(authCtxt);

        }

        public static IService GetService<IService>(IIdentity identity,bool isAuth)
        {
            var claimsIdentity = identity as ClaimsIdentity;

            var authCtxt = new AuthenticationContext(claimsIdentity);
           

            return GetServicesProvider().GetService<IService>(GetUnitOfWork(BuildSmagAuthenticationContext(authCtxt)), authCtxt);
        }

        public static IService GetServiceInMemory<IService>()
        {
            var authCtxt = new AuthenticationContext(null as ClaimsIdentity);
            var smagAuthCtxt = BuildSmagAuthenticationContext(authCtxt);

            return GetService<IService>(GetUnitOfWork(authCtxt, true), GetUnitOfWork(smagAuthCtxt, true));

        }


        public static IService GetService<IService>(AuthenticationContext authCtxt)
        {
            var smagAuthCtxt = BuildSmagAuthenticationContext(authCtxt);
            return GetService<IService>(GetUnitOfWork(authCtxt), GetUnitOfWork(smagAuthCtxt));
        }

        [Obsolete("Attention, cette méthode ne sera plutôt plus exposée au public. Utilisez plutôt les deux autres signatures fournies")]
        public static IService GetService<IService>(IUnitOfWork uow, IUnitOfWork smagUow = null) => GetServicesProvider().GetService<IService>(uow, smagUow);

        /// <summary>
        /// using current user information to build a SMAG authentication context
        /// The AuthenticationContext is used for determinating which implementations should be used for injection
        /// </summary>
        /// <param name="userIdentity"></param>
        /// <returns></returns>
        private static AuthenticationContext BuildSmagAuthenticationContext(IIdentity userIdentity)
            => BuildSmagAuthenticationContext(new AuthenticationContext(userIdentity as ClaimsIdentity));

        private static AuthenticationContext BuildSmagAuthenticationContext(AuthenticationContext authCtxt)
        {
            var smagAuthCtxt = new AuthenticationContext
            {
                ApplicationId = authCtxt.ApplicationId,
                UserId = authCtxt.UserId,
                AuthId = authCtxt.AuthId,
                Refresh_Token = authCtxt.Refresh_Token,
                Token = authCtxt.Token,
                Identities = authCtxt.Identities?
                    .Select(x => new Identity { application_type = x.application_type, Logins = x.Logins, application_id = x.application_id })
                    .ToArray()
            };

            if (smagAuthCtxt.Identities == null || !smagAuthCtxt.Identities.Any())
                smagAuthCtxt.Identities = new[] { new Identity() };

            smagAuthCtxt.Identities[0].application_type = SmagName;

            return smagAuthCtxt;
        }
    }
}