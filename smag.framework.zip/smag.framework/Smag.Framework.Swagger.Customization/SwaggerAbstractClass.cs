﻿using Smag.Framework.Swagger.Customization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http.Description;
using System.Web.Http;
using Swashbuckle.Application;
using static Smag.Framework.Swagger.Customization.SwaggerCustomUiConfig;
using Swashbuckle.Swagger;
using System.Reflection;
using System.Globalization;

namespace Smag.Framework.Swagger.Customization
{

    public abstract class SwaggerAbstractClass
    {

        private const string externalApi = "external";
        private static string currentVersion;
        private static List<string> exposedVersion = new List<string>();


        /// <summary>
        /// Get the name of the API according to the version displayed
        /// </summary>
        /// <param name="targetExposition"></param>
        /// <returns></returns>
        private static string getNameWithVersion(string targetExposition)
        {
            if (targetExposition == currentVersion)
                return externalApi;
            else
                return targetExposition.Replace($"{currentVersion}-","");

        }

        /// <summary>
        /// Convert the version displayed to an enum value of type (SwaggerAttributeVersion.expositionType)
        /// </summary>
        /// <param name="targetExposition"></param>
        /// <returns></returns>
        private static SwaggerAttributeVersion.expositionType getExposition(string targetExposition)
        {
            var stringExposition = targetExposition.Replace($"{currentVersion}-", "");
            foreach (string exposition in Enum.GetNames(typeof(SwaggerAttributeVersion.expositionType)))
            {
                if (exposition.ToLower() == stringExposition.ToLower())
                    return (SwaggerAttributeVersion.expositionType)Enum.Parse(typeof(SwaggerAttributeVersion.expositionType), exposition);
            }
            return SwaggerAttributeVersion.expositionType.Custom;
        }


        /// <summary>
        /// Resolves the version support by route constraint.
        /// </summary>
        /// <param name="apiDesc">The API desc.</param>
        /// <param name="targetApiVersion">The target API version.</param>
        /// <returns></returns>
        private static bool resolveVersionSupportByRouteConstraint(ApiDescription apiDesc, string targetExposition)
        {
            var attrs = apiDesc.ActionDescriptor.GetCustomAttributes<SwaggerAttributeVersion>().ToList();

            SwaggerAttributeVersion.expositionType expositionType = getExposition(targetExposition);

            if (expositionType == SwaggerAttributeVersion.expositionType.Extended)
                return true;
            if(expositionType == SwaggerAttributeVersion.expositionType.Restricted && attrs.First().ExpositionType != SwaggerAttributeVersion.expositionType.Extended && attrs.First().ExpositionType != SwaggerAttributeVersion.expositionType.Custom)
                return true;

            if (attrs.Count() > 0)
                return attrs.Exists(a => a.GetExpositionName() == getNameWithVersion(targetExposition));

            return false;
        }

        /// <summary>
        /// Register a new swagger configuration
        /// </summary>
        /// <param name="versionNumber">api's version</param>
        /// <param name="microServiceName">Micro service root name</param>
        public virtual void Register(Version versionNumber, string microServiceName)
        {
            currentVersion = "v" + versionNumber.Major.ToString();

            #region Search API methods with the SwaggerAttributeVersion attribute to retrieve the name to expose

            Assembly asm = base.GetType().Assembly;

            var allApiMethodsWithSwaggerAttributes = asm.GetTypes().Where(type => typeof(ApiController).IsAssignableFrom(type))
                .SelectMany(type => type.GetMethods())
                .Where(method => method.IsPublic && method.IsDefined(typeof(SwaggerAttributeVersion)));

            foreach (var apiMethod in allApiMethodsWithSwaggerAttributes)
            {
                foreach (var attribute in apiMethod.GetCustomAttributes<SwaggerAttributeVersion>())
                {
                    string expositionName = attribute.GetExpositionName();

                    if (!exposedVersion.Contains(expositionName))
                        exposedVersion.Add(expositionName);
                }
            }

            #endregion

            swaggerRegister(microServiceName);
        }
        
        /// <summary>
        /// Create and instanciate swagger configuration
        /// </summary>
        /// <param name="microServiceName"></param>
        private static void swaggerRegister(string microServiceName)
        {
            GlobalConfiguration.Configuration
                .EnableSwagger(c =>
                {
                    c.DescribeAllEnumsAsStrings(); // this will do the trick
                    c.OperationFilter<ApplySwaggerImplementationNotesFilterAttributes>();
                    c.OperationFilter<ApplySwaggerDescriptionFilterAttributes>();
                    c.OperationFilter<ApplySwaggerSummaryFilterAttributes>();
                    c.MapType<DateTime>(() => new Schema { type = "string", format = "date" });
                    c.OperationFilter<ApplySwaggerMultipleOperationsWithSameVerbFilter>();

                    c.MultipleApiVersions(
                         (apiDesc, targetApiVersion) => resolveVersionSupportByRouteConstraint(apiDesc, targetApiVersion),
                         (vc) =>
                         {
                             foreach (string version in exposedVersion)
                             {
                                 if(version == externalApi)
                                    vc.Version($"{currentVersion}", $"{microServiceName}");
                                 else
                                     vc.Version($"{currentVersion}-{version}", $"{microServiceName}.{CultureInfo.CurrentCulture.TextInfo.ToTitleCase(version)}");

                             }
                         });

                })
                  .EnableSwaggerUi(c =>
                  {
                      SwaggerCustomUiConfig.Config(c);
                      c.EnableDiscoveryUrlSelector();

                  });
        }
    }
}
