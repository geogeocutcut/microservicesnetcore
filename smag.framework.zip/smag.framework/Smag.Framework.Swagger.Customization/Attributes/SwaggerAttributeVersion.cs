﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Filters;

namespace Smag.Framework.Swagger.Customization.Attributes
{
    public class SwaggerAttributeVersion: ActionFilterAttribute
    {
        private string _expositionName = string.Empty;
        private expositionType __expositionType = expositionType.Custom;

        public expositionType ExpositionType
        {
            get
            {
                return __expositionType;
            }
        }
        public string GetExpositionName()
        {
            if (__expositionType == expositionType.Custom)
                return _expositionName;
            else
                return __expositionType.ToString().ToLower();

        }

        public SwaggerAttributeVersion(string expositionName)
        {
            __expositionType = expositionType.Custom;
            _expositionName = expositionName.ToLower();
        }

        public SwaggerAttributeVersion(expositionType expositionType)
        {
            __expositionType = expositionType;
        }

        public enum expositionType { Custom, External, Restricted, Extended};
    }
}
