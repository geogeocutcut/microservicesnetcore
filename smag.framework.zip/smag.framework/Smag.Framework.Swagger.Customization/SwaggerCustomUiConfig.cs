﻿using System;
using System.Linq;
using System.Web.Http.Description;
using Swashbuckle.Application;
using Swashbuckle.Swagger;

namespace Smag.Framework.Swagger.Customization
{

    

    public static class SwaggerCustomUiConfig
    {

      
        /// <summary>
        /// this method helps to configure a set of custom styles/pages/icons for swagger UI
        /// </summary>
        public static void Config(SwaggerUiConfig config)
        {
            var currentAssembly = typeof(SwaggerCustomUiConfig).Assembly;
            var currentAssemblyName = currentAssembly.GetName().Name;

            config.InjectStylesheet(currentAssembly, $"{currentAssemblyName}.resource.swagger-screen.css");
            config.CustomAsset("index", currentAssembly, $"{currentAssemblyName}.resource.index.html");
            config.CustomAsset("smagLogo", currentAssembly, $"{currentAssemblyName}.resource.SMAG_logo_RVB-blanc.png");
            config.CustomAsset("tabIcon", currentAssembly, $"{currentAssemblyName}.resource.G_Orange_small.png");
            
        }

      

        [AttributeUsage(AttributeTargets.Method)]
        public class SwaggerSummaryAttribute : Attribute
        {
            public string Summary { get; private set; }

            public SwaggerSummaryAttribute(string summary)
            {
                this.Summary = summary;
            }
        }

        public class ApplySwaggerSummaryFilterAttributes : IOperationFilter
        {
            public void Apply(Operation operation, SchemaRegistry schemaRegistry, ApiDescription apiDescription)
            {
                var attr = apiDescription.GetControllerAndActionAttributes<SwaggerSummaryAttribute>().FirstOrDefault();
                if (attr != null)
                {
                    operation.summary = attr.Summary;
                }
            }
        }


        public class ApplySwaggerMultipleOperationsWithSameVerbFilter : IOperationFilter
        {
            public void Apply(
                Operation operation,
                SchemaRegistry schemaRegistry,
                ApiDescription apiDescription)
            {
                if (operation.parameters != null)
                {
                    operation.operationId += "By";
                    foreach (var parm in operation.parameters)
                    {
                        operation.operationId += string.Format("{0}", parm.name);
                    }
                }
            }
        }

        public class AddAuthorizationHeaderParameterOperationFilter : IOperationFilter
        {
            public void Apply(Operation operation, SchemaRegistry schemaRegistry, ApiDescription apiDescription)
            {
                if (operation.parameters != null)
                {
                    operation.parameters.Add(new Parameter
                    {
                        name = "SmagAuthorization",
                        @in = "header",
                        description = "access token",
                        required = true,
                        type = "string",
                        pattern = "Bearer xxxxx"
                    });
                }
            }
        }

        public class AddApiKeyHeaderParameterOperationFilter : IOperationFilter
        {
            public void Apply(Operation operation, SchemaRegistry schemaRegistry, ApiDescription apiDescription)
            {
         
            }
        }


        [AttributeUsage(AttributeTargets.Method)]
        public class SwaggerImplementationNotesAttribute : Attribute
        {
            public string ImplementationNotes { get; private set; }

            public SwaggerImplementationNotesAttribute(string implementationNotes)
            {
                this.ImplementationNotes = implementationNotes;
            }
        }

        public class ApplySwaggerImplementationNotesFilterAttributes : IOperationFilter
        {
            public void Apply(Operation operation, SchemaRegistry schemaRegistry, ApiDescription apiDescription)
            {
                var attr = apiDescription.GetControllerAndActionAttributes<SwaggerImplementationNotesAttribute>().FirstOrDefault();
                if (attr != null)
                {
                    operation.description = attr.ImplementationNotes;
                }
            }
        }

        [AttributeUsage(AttributeTargets.Method)]
        public class SwaggerDescriptionAttribute : Attribute
        {
            public string Description { get; private set; }

            public SwaggerDescriptionAttribute(string description)
            {
                this.Description = description;
            }
        }

        public class ApplySwaggerDescriptionFilterAttributes : IOperationFilter
        {
            public void Apply(Operation operation, SchemaRegistry schemaRegistry, ApiDescription apiDescription)
            {
                var attr = apiDescription.GetControllerAndActionAttributes<SwaggerDescriptionAttribute>().FirstOrDefault();
                if (attr != null)
                {
                    operation.description = attr.Description;
                }
            }
        }

    }
}