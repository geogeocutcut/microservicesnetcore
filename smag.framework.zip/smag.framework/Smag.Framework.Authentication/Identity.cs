﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Smag.Framework.Authentication
{
    public class Identity
    {
        public string application_id { get; set; }
        public string application_type { get; set; }

        public string application_name { get; set; }
        public string application_code { get; set; }

        public List<string> Logins { get; set; }
    }
}
