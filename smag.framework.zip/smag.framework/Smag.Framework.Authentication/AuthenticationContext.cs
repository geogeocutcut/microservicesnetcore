﻿using Newtonsoft.Json;
using Smag.Framework.Authentication.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;

namespace Smag.Framework.Authentication
{
    /// <summary>
    /// Store information about the Jarvis user.
    /// </summary>
    public class AuthenticationContext
    {
        #region Properties

        /// <summary>
        /// Identifier of application.
        /// </summary>
        public virtual string ApplicationId { get; set; }

        /// <summary>
        /// Identifier of the Smag user.
        /// </summary>
        public virtual string UserId { get; set; }

        //todo : à revenir dessus pour voir le système de passage d'id utilisateur
        // Normalement, on doit ajouter UserId (id user smag) à travers des rules d'Auth0
        // mais l'utilisateur n'existe pas forcement quand on passe dans les rules.
        // du coup, pour l'instant, on ajoute également ce champs 'AuthId', qui représente l'identifiant d'un même utilisateur dans Authà
        // et tant que l'on a un token, cet id est toujours présent
        // Nous pouvons donc récupérer l'UserId par son AuthId si nécessiare
        /// <summary>
        /// Identifiant Auth0 de l'utilisateur
        /// </summary>
        public string AuthId { get; set; }

        /// <summary>
        /// Original "Json Web Token" sent by SMAG's authentication service.
        /// </summary>
        public string Token { get; set; }

        /// <summary>
        /// Original "Json Web Token" sent by SMAG's authentication service.
        /// </summary>
        public string Refresh_Token { get; set; }

        /// <summary>
        /// Legacy subscription grouped by application.
        /// </summary>
        public Identity Identity => Identities?.FirstOrDefault();

        public Identity[] Identities { get; set; }


        /// <summary>
        /// Key for Get access on the LegacyDatabase
        /// </summary>
        public string VaultKey { get; set; }

        #endregion Properties

        #region Constructors

        /// <summary>
        /// Default constructor.
        /// </summary>
        public AuthenticationContext()
        {
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="claims">Claims-based identity.</param>
        public AuthenticationContext(IEnumerable<Claim> claims)
        {
            if (claims == null)
                return;

            ApplicationId = claims.FirstOrDefault(x => x.Type == "https://smag.authentication.operational.com/application_id")?.Value;

            var identitiesClaimValues = claims.Where(x => x.Type == "https://smag.authentication.operational.com/identities").ToArray();

            Identities = identitiesClaimValues?.Select(x => JsonConvert.DeserializeObject<Identity>(x.Value)).ToArray();

            UserId = claims.FirstOrDefault(x => x.Type == "https://smag.authentication.operational.com/userId")?.Value;

            var token = claims.FirstOrDefault(x => x.Type == "Token")?.Value;
            Token = token;

            //sub est le nom dans JWT token qui représente l'id auth0
            AuthId = string.IsNullOrEmpty(token) ? string.Empty : JwtTokenHelper.GetClaimInfo(token, "sub");
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="identity">Claims-based identity.</param>
        public AuthenticationContext(ClaimsIdentity identity)
            : this(identity?.Claims)
        {
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="identity">User identity.</param>
        public AuthenticationContext(IIdentity identity)
            : this(identity as ClaimsIdentity)
        {
        }

        #endregion Constructors
    }
}