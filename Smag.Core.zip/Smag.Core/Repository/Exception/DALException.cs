﻿using System.Runtime.Serialization;

// ReSharper disable once CheckNamespace
namespace Smag.Core.Repository
{
    public class DalException : System.Exception, ISerializable
    {
        public DalException()
        { }

        public DalException(string message) : base(message)
        { }

        public DalException(string message, System.Exception innerException) : base(message, innerException)
        { }

        protected DalException(SerializationInfo info, StreamingContext context) : base(info, context)
        { }
    }
}