﻿using System;

namespace webapi
{
    public class Class1
    {
    }
}
